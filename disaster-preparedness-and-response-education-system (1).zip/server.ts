import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory simulated state
interface LiveAlert {
  id: string;
  title: string;
  message: string;
  severity: "low" | "medium" | "high";
  type: "drill" | "real_emergency" | "advisory";
  timestamp: string;
  isActive: boolean;
  sender: string;
}

const activeAlerts: LiveAlert[] = [
  {
    id: "alert-1",
    title: "Quarterly Fire Drill Scheduled",
    message: "Attention all students and faculty: A campus-wide fire evacuation drill will commence today at 2:00 PM. Please review your designated evacuation exit routes and assembly points.",
    severity: "medium",
    type: "drill",
    timestamp: new Date().toISOString(),
    isActive: true,
    sender: "Admin (Safety Coordinator)"
  },
  {
    id: "alert-2",
    title: "High Wind Advisory",
    message: "A meteorological high wind advisory has been issued for the area. Please secure any loose outdoor educational equipment and exercise caution near large trees on school pathways.",
    severity: "low",
    type: "advisory",
    timestamp: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
    isActive: true,
    sender: "National Weather Center"
  }
];

// Lazy-loaded Gemini AI client to prevent crash if key is missing on start
let aiClient: GoogleGenAI | null = null;

function getGeminiAI(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is not configured. Please add it to your secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        }
      }
    });
  }
  return aiClient;
}

// 1. API: Fetch active alerts
app.get("/api/alerts", (req, res) => {
  res.json({ success: true, alerts: activeAlerts });
});

// 2. API: Trigger a new alert (Teacher/Admin dashboard utility)
app.post("/api/alerts", (req, res) => {
  const { title, message, severity, type, sender } = req.body;
  if (!title || !message) {
    return res.status(400).json({ success: false, error: "Title and message are required." });
  }

  const newAlert: LiveAlert = {
    id: `alert-${Date.now()}`,
    title,
    message,
    severity: severity || "medium",
    type: type || "drill",
    timestamp: new Date().toISOString(),
    isActive: true,
    sender: sender || "Teacher Dashboard"
  };

  activeAlerts.unshift(newAlert);
  res.json({ success: true, alert: newAlert });
});

// 3. API: Clear/Deactivate alert
app.post("/api/alerts/:id/deactivate", (req, res) => {
  const { id } = req.params;
  const alertIndex = activeAlerts.findIndex(a => a.id === id);
  if (alertIndex !== -1) {
    activeAlerts[alertIndex].isActive = false;
    return res.json({ success: true, alert: activeAlerts[alertIndex] });
  }
  res.status(404).json({ success: false, error: "Alert not found." });
});

// 4. API: AI Chatbot Proxy using @google/genai
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message) {
      return res.status(400).json({ success: false, error: "Message prompt is required." });
    }

    const ai = getGeminiAI();

    // Construct a comprehensive system prompt explaining context and responsibilities
    const systemInstruction = 
      "You are the 'Disaster Preparedness and Emergency Response AI' for schools and colleges. " +
      "Your goal is to provide highly structured, safety-first, calm, and accurate advice to students, teachers, and admins. " +
      "Focus strictly on disaster preparedness, evacuation procedures, active drills (fire, earthquake, tornado, floods, active shooter), first aid kits, emergency supply checks, and campus safety audits. " +
      "If asked about unrelated topics, politely redirect back to disaster and safety preparedness. " +
      "Use clear bullet points, brief instructions, and action-oriented vocabulary. " +
      "Maintain a supportive, reassuring, and professional safety coordinator persona.";

    // Simple format for contents incorporating user's chat history
    let contents: any[] = [];
    if (history && Array.isArray(history)) {
      history.forEach((msg: any) => {
        contents.push({
          role: msg.role === "user" ? "user" : "model",
          parts: [{ text: msg.content || msg.text }]
        });
      });
    }
    
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const reply = response.text || "I was unable to formulate a response. Please double-check your safety query.";
    res.json({ success: true, response: reply });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ 
      success: false, 
      error: error.message || "Failed to communicate with AI Safety Expert.",
      details: process.env.GEMINI_API_KEY ? "Check logs for detailed information" : "GEMINI_API_KEY environment variable is missing"
    });
  }
});

// Setup Vite Dev server or Serve static files
async function init() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Disaster Preparedness System running at http://localhost:${PORT}`);
  });
}

init();
