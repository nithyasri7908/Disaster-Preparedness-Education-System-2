import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import Auth from './components/Auth';
import LearningModules from './components/LearningModules';
import DisasterSimulator from './components/DisasterSimulator';
import QuizComponent from './components/Quiz';
import StudentDashboard from './components/DashboardStudent';
import TeacherDashboard from './components/DashboardTeacher';
import AdminDashboard from './components/DashboardAdmin';
import EmergencyAlerts from './components/EmergencyAlerts';
import ResourceCenter from './components/ResourceCenter';
import RiskAssessment from './components/RiskAssessment';
import Certificate from './components/Certificate';
import AiChatbot from './components/AiChatbot';
import { UserProfile, EmergencyAlert, UserRole } from './types';
import { ShieldAlert, RefreshCw, Layers } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [alerts, setAlerts] = useState<EmergencyAlert[]>([]);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('responseed_dark_mode') === 'true';
  });

  useEffect(() => {
    localStorage.setItem('responseed_dark_mode', String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);
  
  // Pre-authenticate a mock student by default so the system is instantly readable and reviewable!
  const [user, setUser] = useState<UserProfile | null>({
    name: "Alex Rivera",
    email: "alex.rivera@lincolnu.edu",
    role: "student",
    school: "Lincoln University",
    gradeLevel: "Sophomore Year",
    progress: {
      completedModules: [],
      completedQuizzes: {},
      badgesEarned: ["Disaster Scholar"], // Started with a standard badge
      riskAssessmentsCompleted: 0
    }
  });

  // Poll alerts state from Express server to reflect real-time teacher warning broadcasts!
  const fetchAlerts = async () => {
    try {
      const res = await fetch('/api/alerts');
      const data = await res.json();
      if (data.success) {
        setAlerts(data.alerts);
      }
    } catch (err) {
      console.error("Failed to retrieve live broadcast alerts:", err);
    }
  };

  useEffect(() => {
    fetchAlerts();
    const interval = setInterval(fetchAlerts, 5000); // Sync warning notice board every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const handleModuleComplete = (moduleId: string) => {
    if (!user) return;
    
    const currentCompleted = [...user.progress.completedModules];
    if (!currentCompleted.includes(moduleId)) {
      currentCompleted.push(moduleId);
    }

    const updatedBadges = [...user.progress.badgesEarned];
    // If all modules are finished, unlock Disaster Scholar badge
    if (currentCompleted.length >= 4 && !updatedBadges.includes("Disaster Scholar")) {
      updatedBadges.push("Disaster Scholar");
    }

    setUser({
      ...user,
      progress: {
        ...user.progress,
        completedModules: currentCompleted,
        badgesEarned: updatedBadges
      }
    });
  };

  const handleQuizSubmit = (quizId: string, scorePercentage: number) => {
    if (!user) return;

    const updatedQuizzes = {
      ...user.progress.completedQuizzes,
      [quizId]: Math.max(scorePercentage, user.progress.completedQuizzes[quizId] || 0)
    };

    setUser({
      ...user,
      progress: {
        ...user.progress,
        completedQuizzes: updatedQuizzes
      }
    });
  };

  const handleUnlockBadge = (badgeId: string) => {
    if (!user) return;

    const currentBadges = [...user.progress.badgesEarned];
    if (!currentBadges.includes(badgeId)) {
      currentBadges.push(badgeId);
    }

    setUser({
      ...user,
      progress: {
        ...user.progress,
        badgesEarned: currentBadges
      }
    });
  };

  const handleAuditSubmit = () => {
    if (!user) return;

    setUser({
      ...user,
      progress: {
        ...user.progress,
        riskAssessmentsCompleted: user.progress.riskAssessmentsCompleted + 1
      }
    });
  };

  // Trigger POST /api/alerts to broadcast drill campus-wide
  const handleTriggerAlert = async (alertData: any) => {
    try {
      const response = await fetch('/api/alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(alertData)
      });
      const data = await response.json();
      if (data.success) {
        fetchAlerts(); // Refresh alerts
      }
    } catch (err) {
      console.error("Alert broadcast failed:", err);
    }
  };

  // Deactivate warning Notice
  const handleDeactivateAlert = async (alertId: string) => {
    try {
      const response = await fetch(`/api/alerts/${alertId}/deactivate`, {
        method: 'POST'
      });
      const data = await response.json();
      if (data.success) {
        fetchAlerts();
      }
    } catch (err) {
      console.error("Alert deactivation failed:", err);
    }
  };

  const handleAuthSuccess = (profile: UserProfile) => {
    setUser(profile);
    setActiveTab('home');
  };

  const handleLogout = () => {
    setUser(null);
    setActiveTab('home');
  };

  // Demo Switcher allows reviewer to test Student, Teacher & Admin views instantly with no register overhead!
  const handleDemoPreset = (role: UserRole) => {
    if (role === 'student') {
      setUser({
        name: "Alex Rivera",
        email: "alex.rivera@lincolnu.edu",
        role: "student",
        school: "Lincoln University",
        gradeLevel: "Sophomore Year",
        progress: {
          completedModules: ["earthquake"],
          completedQuizzes: { "earthquake_quiz": 100 },
          badgesEarned: ["Disaster Scholar", "Earthquake Rescuer"],
          riskAssessmentsCompleted: 0
        }
      });
      setActiveTab('student-dash');
    } else if (role === 'teacher') {
      setUser({
        name: "Professor Harold Vance",
        email: "h.vance@lincolnu.edu",
        role: "teacher",
        school: "Lincoln Geosciences Department",
        progress: { completedModules: [], completedQuizzes: {}, badgesEarned: [], riskAssessmentsCompleted: 0 }
      });
      setActiveTab('teacher-dash');
    } else {
      setUser({
        name: "Commander Sarah Jenkins",
        email: "s.jenkins@lincolnu.edu",
        role: "admin",
        school: "Lincoln Safety Operations Command",
        progress: { completedModules: [], completedQuizzes: {}, badgesEarned: [], riskAssessmentsCompleted: 0 }
      });
      setActiveTab('admin-dash');
    }
  };

  // Active Tab Rendering Router switch
  const renderTabContent = () => {
    switch (activeTab) {
      case 'home':
        return <Home user={user} alerts={alerts} onNavigate={setActiveTab} />;
      case 'about':
        return <About />;
      case 'contact':
        return <Contact />;
      case 'login':
      case 'register':
        return <Auth onAuthSuccess={handleAuthSuccess} />;
      case 'modules':
        return <LearningModules user={user} onModuleComplete={handleModuleComplete} onNavigate={setActiveTab} />;
      case 'simulator':
        return <DisasterSimulator user={user} onUnlockBadge={handleUnlockBadge} onNavigate={setActiveTab} />;
      case 'quiz':
        return <QuizComponent user={user} onQuizSubmit={handleQuizSubmit} onNavigate={setActiveTab} />;
      case 'chatbot':
        return <AiChatbot />;
      case 'alerts':
        return <EmergencyAlerts alerts={alerts} />;
      case 'resources':
        return <ResourceCenter />;
      case 'assessment':
        return (
          <RiskAssessment 
            user={user} 
            onAuditSubmit={handleAuditSubmit} 
            onUnlockBadge={handleUnlockBadge}
            onNavigate={setActiveTab} 
          />
        );
      case 'certificate':
        return <Certificate user={user} onNavigate={setActiveTab} />;
      case 'student-dash':
        return <StudentDashboard user={user} alerts={alerts} onNavigate={setActiveTab} />;
      case 'teacher-dash':
        return (
          <TeacherDashboard 
            user={user} 
            alerts={alerts} 
            onTriggerAlert={handleTriggerAlert} 
            onDeactivateAlert={handleDeactivateAlert}
            onNavigate={setActiveTab} 
          />
        );
      case 'admin-dash':
        return (
          <AdminDashboard 
            user={user} 
            alerts={alerts}
            onTriggerAlert={handleTriggerAlert}
            onDeactivateAlert={handleDeactivateAlert}
            onNavigate={setActiveTab} 
          />
        );
      default:
        return <Home user={user} alerts={alerts} onNavigate={setActiveTab} />;
    }
  };

  const activeAlerts = alerts.filter(a => a.isActive);

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-slate-50 dark:bg-slate-950 font-sans text-slate-800 dark:text-slate-100 antialiased overflow-x-hidden transition-colors duration-300">
      
      {/* Dynamic Flashing Banner for Urgent High-Severity Emergencies */}
      {activeAlerts.some(a => a.severity === 'high') && (
        <div className="w-full bg-red-600 border-b border-red-500 p-2 text-center text-xs font-black tracking-widest text-white uppercase flex items-center justify-center gap-2 animate-pulse fixed top-0 left-0 right-0 z-[100] lg:static">
          <ShieldAlert className="w-4 h-4 text-white shrink-0 animate-bounce" />
          <span>ALERT: Active High-Severity Transmissions Broadcasted! check Emergency Alerts tab.</span>
        </div>
      )}

      {/* Main Sidebar Navigation drawer */}
      <Navigation 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        user={user} 
        onLogout={handleLogout} 
        alerts={alerts} 
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Main Body Stage */}
      <main className={`flex-1 p-4 md:p-8 space-y-6 ${
        activeAlerts.some(a => a.severity === 'high') ? 'pt-16 lg:pt-8' : ''
      }`}>
        
        {/* Floating Developer Evaluation Toolbar preset */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs transition-colors duration-300">
          <div className="flex items-center gap-1.5 font-sans text-slate-600 dark:text-slate-300">
            <Layers className="w-4 h-4 text-blue-700 dark:text-blue-400" />
            <span className="font-bold">Sandbox Presets:</span>
          </div>
          <div className="flex flex-wrap gap-1.5 justify-center">
            <button 
              onClick={() => handleDemoPreset('student')}
              className={`px-3 py-1.5 rounded border text-[10px] font-bold uppercase transition-all cursor-pointer ${
                user?.role === 'student' 
                  ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-800' 
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-750 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-800 dark:hover:text-slate-100'
              }`}
            >
              🎓 Student Demo
            </button>
            <button 
              onClick={() => handleDemoPreset('teacher')}
              className={`px-3 py-1.5 rounded border text-[10px] font-bold uppercase transition-all cursor-pointer ${
                user?.role === 'teacher' 
                  ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-800' 
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-750 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-800 dark:hover:text-slate-100'
              }`}
            >
              👩‍🏫 Teacher Demo
            </button>
            <button 
              onClick={() => handleDemoPreset('admin')}
              className={`px-3 py-1.5 rounded border text-[10px] font-bold uppercase transition-all cursor-pointer ${
                user?.role === 'admin' 
                  ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-800' 
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-750 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-800 dark:hover:text-slate-100'
              }`}
            >
              🛠️ Admin Demo
            </button>
            {user && (
              <button 
                onClick={handleLogout}
                className="px-3 py-1.5 bg-red-50 dark:bg-red-950/20 hover:bg-red-100 dark:hover:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 rounded text-[10px] font-bold uppercase transition-all cursor-pointer"
              >
                Sign Out
              </button>
            )}
          </div>
        </div>

        {/* Dynamic Route View container */}
        <div className="min-h-[70vh]">
          {renderTabContent()}
        </div>

      </main>

    </div>
  );
}
