import { LearningModule, Quiz, DisasterSimulator, RiskAssessmentItem } from '../types';

export const LEARNING_MODULES: LearningModule[] = [
  {
    id: 'earthquake',
    title: 'Earthquake Evacuation & Survival',
    icon: 'ShieldAlert',
    category: 'natural',
    description: 'Master the "Drop, Cover, and Hold On" technique and learn how to safely evaluate and clear academic classrooms during high-magnitude seismic events.',
    difficulty: 'Beginner',
    timeToComplete: '10 mins',
    introduction: 'Earthquakes are sudden, rapid shakings of the earth caused by the breaking and shifting of subterranean rock layers. They strike without warning, making rapid-response training essential for classroom survival.',
    causes: [
      'Tectonic plate movements along active geological fault lines.',
      'Volcanic eruptions or subterranean magma displacement causing shifts.',
      'Man-made triggers such as deep-well fluid injection or mining activities.'
    ],
    beforeDisaster: [
      'Identify safe spaces in each classroom: under sturdy desks, heavy tables, or against interior walls away from glass windows.',
      'Secure heavy classroom fixtures: ensure computer monitors, projectors, and tall bookshelves are anchored securely.',
      'Maintain clear escape paths: keep all classroom doors, exits, and school hallways completely free of physical debris.'
    ],
    duringDisaster: [
      'DROP: Immediately drop to your knees to prevent you from falling and allow you to crawl if needed.',
      'COVER: Cover your head and neck with your arms. If possible, crawl under a sturdy school desk or table.',
      'HOLD ON: Hold on to your shelter securely with one hand, ready to move with it if it shifts.'
    ],
    afterDisaster: [
      'Listen carefully to administrative megaphones, campus public address systems, or fire sirens for evacuation directives.',
      'Evacuate using the stairs in single file, protecting your head with folders, books, or bags.',
      'Assemble at the designated campus muster point (usually the central sports field or parking area).',
      'Help teachers perform a headcount and report any missing classmates or injured students.'
    ],
    safetyTips: [
      'Never use campus elevators during or immediately after an earthquake.',
      'If outdoors on campus grounds, move away from brick buildings, power lines, and lampposts.',
      'Expect aftershocks and be prepared to Drop, Cover, and Hold On again if shaking restarts.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1594897030264-ab7d87efc473?auto=format&fit=crop&w=600&q=80',
    sections: [
      {
        title: 'Section 1: Before an Earthquake (Proactive Safeguarding)',
        content: [
          'Identify safe spaces in each classroom: under sturdy desks, heavy tables, or against interior walls away from glass windows and tall bookcases.',
          'Secure heavy classroom fixtures: ensure computer monitors, projectors, lab cabinets, and tall bookshelves are anchored securely to walls.',
          'Maintain clear escape paths: keep all classroom doors, exits, and school hallways completely free of bags, desks, or physical debris.'
        ],
        tips: [
          'Store chemical lab equipment on low shelves with protective lips to prevent toxic spills during shaking.',
          'Know where the school gas shutoff valve, main water valves, and electrical breakers are located.'
        ]
      },
      {
        title: 'Section 2: During an Earthquake (Active Evacuation Procedures)',
        content: [
          'DROP: Immediately drop to your knees. This prevents you from falling and allows you to move if needed.',
          'COVER: Cover your head and neck with your arms. If possible, crawl under a sturdy school desk or table.',
          'HOLD ON: Hold on to your shelter securely with one hand, ready to move with it if it shifts, keeping your other arm shielding your neck.',
          'AVOID HAZARDS: Stay clear of windows, mirrors, glass laboratory panels, exterior hanging lights, or high-capacity shelving units.'
        ],
        tips: [
          'Never use campus elevators during an earthquake. Electrical grids will likely shut down and trap occupants.',
          'If outdoors on campus grounds, move away from brick buildings, power lines, overhead utility grids, and concrete light poles.'
        ]
      },
      {
        title: 'Section 3: After an Earthquake (Post-Disaster Muster & Safety)',
        content: [
          'Listen carefully to administrative megaphones, campus public address (PA) systems, or fire sirens for evacuation directives.',
          'Evacuate using the stairs in single file, protecting your head with folders, books, or bags from falling ceiling tiles.',
          'Assemble at the designated campus muster point (usually the central playground, sports field, or parking area).',
          'Help teachers perform a head count. Report any missing classmates or injured students immediately to medical responders.'
        ],
        tips: [
          'Expect aftershocks. Be prepared to Drop, Cover, and Hold On again if shaking restarts.',
          'Do not enter any campus building until it has been inspected and cleared by civil structural engineers.'
        ]
      }
    ],
    drillSteps: [
      { step: 1, action: "Identify seismic hazard alert or feel active tremor.", rationale: "Initiates immediate survival mindset." },
      { step: 2, action: "Enact standard Drop, Cover, and Hold On underneath desks.", rationale: "Protects vital organs and head from falling plaster, fixtures, and glass." },
      { step: 3, action: "Await the end of severe shaking (usually 30 to 60 seconds).", rationale: "Moving during active shaking increases injury risk from falls or projectiles." },
      { step: 4, action: "Follow teacher evacuation orders in a quiet, orderly line.", rationale: "Ensures exit channels remain unclogged and warnings are heard." },
      { step: 5, action: "Muster at the designated sports field and conduct roll call.", rationale: "Verifies accountability and highlights survivors needing search-and-rescue." }
    ]
  },
  {
    id: 'flood',
    title: 'Severe Flooding & Flash Alerts',
    icon: 'Waves',
    category: 'natural',
    description: 'Learn to interpret civil warning tiers, establish safe higher-ground shelters on campus, and understand the extreme danger of moving through running floodwaters.',
    difficulty: 'Intermediate',
    timeToComplete: '15 mins',
    introduction: 'Floods are the most common and widespread of all natural disasters, caused by heavy rainfall, rapid snowmelt, or dam failures. Flash floods can develop within minutes, moving with immense force.',
    causes: [
      'Intense, localized precipitation (heavy rainstorms) overloading local drainage grids.',
      'Sustained rainfall over consecutive days causing rivers to overflow their banks.',
      'Rapid coastal storm surges triggered by cyclones, hurricanes, or tropical depressions.'
    ],
    beforeDisaster: [
      'Understand local flood hazard zones and locate designated high-altitude shelters.',
      'Keep emergency communication networks charged and maintain basic water/food stocks on upper levels.',
      'Elevate valuable equipment, student logs, and expensive lab gear above historical floodlines.'
    ],
    duringDisaster: [
      'Monitor weather alerts and evacuate vertically to upper floors immediately if water rises.',
      'NEVER attempt to walk, swim, or drive through flowing water—6 inches is enough to knock you down.',
      'Disconnect main power lines and electrical systems if directed by administrators.'
    ],
    afterDisaster: [
      'Wait for official clearance from civil emergency services before returning to lower ground.',
      'Avoid floodwaters, which are frequently contaminated with biological waste, chemicals, and sharp metal.',
      'Report downed power lines or visible structural wall cracking to response teams.'
    ],
    safetyTips: [
      'Turn Around, Don\'t Drown: Just two feet of running water can sweep away heavy vehicles.',
      'Be extremely alert for hidden sinkholes, missing sewer grates, or charged electrical cables in flood zones.',
      'Drink only bottled or boiled water to prevent severe gastrointestinal waterborne infections.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1547683905-f686c993aae5?auto=format&fit=crop&w=600&q=80',
    sections: [
      {
        title: 'Section 1: Flood Alerts & High-Ground Sheltering',
        content: [
          'Flood Watch: Conditions are favorable for flooding. Prepare emergency kits and monitor campus alert networks.',
          'Flood Warning: Active flooding is occurring or imminent. Take immediate shelter on the highest available campus structures.',
          'Vertical Evacuation: If flash floods strike, move students to secondary or tertiary floors. Never attempt to evacuate outdoors into deep waters.'
        ],
        tips: [
          'Keep emergency radios and communication equipment on battery backup in higher classroom locations.'
        ]
      },
      {
        title: 'Section 2: Flash Flood Hazards and Walking Safety',
        content: [
          'NEVER walk through running water: just 6 inches of moving water can knock an adult off their feet.',
          'Turn Around, Don\'t Drown: Do not attempt to drive, ride, or walk through waterlogged streets surrounding campus.',
          'Be aware of hidden electrical grids: floodwaters can be charged by downed high-voltage lines or building electrical meters.'
        ],
        tips: [
          'Flooded streets hide open sewer manholes, sharp debris, and biological contaminants.'
        ]
      }
    ],
    drillSteps: [
      { step: 1, action: "Monitor extreme weather alerts indicating rapid flooding.", rationale: "Gives precious lead time to move occupants before roads become impassable." },
      { step: 2, action: "Activate Vertical Evacuation protocols to upper floors.", rationale: "Keeps students safely out of rapid ground-level currents and rising basement levels." },
      { step: 3, action: "Cut main electrical breakers if instructed by civil administrators.", rationale: "Eliminates shock risks if water infiltrates building infrastructure." },
      { step: 4, action: "Muster on the highest level with fresh drinking water supplies.", rationale: "Protects from contamination and ensures sustenance during prolonged isolation." },
      { step: 5, action: "Await state rescue agencies or official clear notification.", rationale: "Prevents premature exits into active washouts." }
    ]
  },
  {
    id: 'fire',
    title: 'Fire Safety & Smoke Evacuation',
    icon: 'Flame',
    category: 'manmade',
    description: 'Learn rapid response protocols during academic building fires, correct fire extinguisher utilization, and how to safely navigate smoke-filled corridors.',
    difficulty: 'Beginner',
    timeToComplete: '12 mins',
    introduction: 'Fire emergencies in educational settings require lightning-fast, structured evacuation. Knowing how to operate fire extinguishers and filter toxic smoke will preserve physical safety.',
    causes: [
      'Electrical short circuits in laboratories, computing facilities, or older structures.',
      'Improper chemical handling or chemical reactions in chemistry lab suites.',
      'Combustible material accumulations combined with direct heat or ignition sources.'
    ],
    beforeDisaster: [
      'Locate fire extinguishers, manual alarms, and emergency fire escapes on your floor.',
      'Participate actively in regular, unannounced fire drills.',
      'Report frayed cables, overloaded sockets, or blocked exits to administrators.'
    ],
    duringDisaster: [
      'Pull the nearest fire alarm station immediately and call emergency services.',
      'Crawl low on hands and knees to bypass toxic, rising hot carbon monoxide clouds.',
      'Feel doors with the back of your hand before grabbing handles to check for active heat.'
    ],
    afterDisaster: [
      'Assemble at the designated outdoor sports field or open space immediately.',
      'Report missing colleagues, room numbers, or injuries to fire wardens.',
      'Do not re-enter any building until fire marshals declare it safe.'
    ],
    safetyTips: [
      'If your clothes catch fire, remember: STOP, DROP, AND ROLL immediately.',
      'Remember P.A.S.S. for fire extinguishers: Pull pin, Aim at base, Squeeze trigger, Sweep side-to-side.',
      'Never open doors that feel hot to the touch—they block active flame zones.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1508873696983-2df519f0397e?auto=format&fit=crop&w=600&q=80',
    sections: [
      {
        title: 'Section 1: Fire Mitigation and Alerting',
        content: [
          'If you spot smoke or fire, pull the nearest manual fire alarm station immediately. Do not attempt to confirm the fire size first.',
          'Notify school staff, administrators, or dial emergency services (911) once you are safe from immediate flame hazards.',
          'Keep electrical sockets clear: never daisy-chain surge protectors or power strips in computer labs or classrooms.'
        ],
        tips: [
          'Fires double in size every minute. Prompt alert pull-stations save lives.'
        ]
      },
      {
        title: 'Section 2: Smoke Evacuation Protocol',
        content: [
          'STAY LOW: Smoke, toxic gases, and heat rise to the ceiling. Crawl on your hands and knees where the air is coolest and cleanest.',
          'CHECK DOORS: Touch wooden doors or handles with the back of your hand before opening. If hot, do not open—use an alternate exit.',
          'CLOSE DOORS: As you escape, close doors behind you to compartmentalize the fire and restrict oxygen flow.'
        ],
        tips: [
          'If your clothes catch fire, remember: STOP, DROP, AND ROLL. Cover your face with your hands to protect your airways.'
        ]
      },
      {
        title: 'Section 3: Using a Fire Extinguisher (P.A.S.S. Method)',
        content: [
          'PULL: Pull the safety pin on the fire extinguisher handle to break the tamper seal.',
          'AIM: Aim the nozzle at the BASE of the fire. Aiming at the top of the flames is ineffective.',
          'SQUEEZE: Squeeze the trigger lever slowly to discharge the chemical extinguishing agent.',
          'SWEEP: Sweep the nozzle side to side at the base of the fire until the flame is completely extinguished.'
        ],
        tips: [
          'Only attempt to fight small, localized fires (e.g., trash can size). If the fire is larger, evacuate immediately.'
        ]
      }
    ],
    drillSteps: [
      { step: 1, action: "Sound fire alarm system immediately.", rationale: "Alerts entire campus community to begin immediate exit sequence." },
      { step: 2, action: "Stop active tasks, leave belongings, and crawl low under smoke.", rationale: "Minimizes inhalation of toxic carbon monoxide and hydrogen cyanide gases." },
      { step: 3, action: "Test doors with the back of the hand before entering hallways.", rationale: "Prevents opening into active fire zones." },
      { step: 4, action: "Exit structure and meet at the sports field or parking lot.", rationale: "Regroups occupants safely away from structural collapse or heat." },
      { step: 5, action: "Perform visual roll calls and report status to fire marshals.", rationale: "Assists emergency responders in targeted search and rescue." }
    ]
  },
  {
    id: 'cyclone',
    title: 'Cyclone & High Wind Readiness',
    icon: 'Wind',
    category: 'natural',
    description: 'Understand cyclone warning categories, learn to secure classroom portals, and master shelter-in-place safety guidelines during destructive windstorms.',
    difficulty: 'Intermediate',
    timeToComplete: '15 mins',
    introduction: 'Cyclones, hurricanes, and typhoons are rotating, organized systems of clouds and thunderstorms that originate over tropical waters. They carry intense rainfall and winds exceeding 74 mph, capable of causing devastating structural damage.',
    causes: [
      'Rapid condensation of warm ocean moisture over tropical seas.',
      'Low-pressure weather systems combined with Earth\'s rotational Coriolis force.',
      'High atmospheric instability driving warm, upward convection currents.'
    ],
    beforeDisaster: [
      'Identify designated cyclone shelters or reinforced interior concrete rooms on campus.',
      'Secure loose outdoor items such as trash bins, benches, and athletic gear.',
      'Board up or close high-impact glass windows and doors securely.',
      'Stock up on emergency flashlights, fresh water, and backup communication batteries.'
    ],
    duringDisaster: [
      'Shelter indoors on lower levels away from windows, skylights, and glass panes.',
      'Listen continuously to official weather reports and administrative alerts.',
      'If the "eye" of the storm passes, stay indoors; destructive winds will restart abruptly.',
      'Disconnect electrical appliances to avoid high-voltage power surges.'
    ],
    afterDisaster: [
      'Remain inside until emergency responders confirm the storm has officially cleared.',
      'Inspect structures for structural cracking, gas leaks, and chemical spills before moving.',
      'Avoid walking or driving through standing water, which may hide downed electrical cables.',
      'Boil drinking water or use water purification tablets to prevent waterborne diseases.'
    ],
    safetyTips: [
      'Never go outside during the brief calm of the cyclone eye.',
      'Always wear heavy shoes to protect your feet from nails, glass, and sharp metallic storm debris.',
      'Report downed utility poles and power lines immediately to campus safety wardens.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1527482797697-8795b05a13fe?auto=format&fit=crop&w=600&q=80',
    sections: [
      {
        title: 'Section 1: Understanding Cyclones & Warning Categories',
        content: [
          'Tropical storms are classified by wind speeds. Category 1 starts at 74 mph, and Category 5 wind speeds exceed 157 mph.',
          'Cyclone Watch: Coastal threat within 48 hours. Secure campus grounds and review shelter plans.',
          'Cyclone Warning: Imminent impact expected within 24 hours. Execute immediate lockdown or evacuation orders.'
        ],
        tips: [
          'A watch means prep is starting. A warning means active protective actions are mandatory.'
        ]
      },
      {
        title: 'Section 2: Latching Portals & Sheltering In Place',
        content: [
          'Close, latch, and lock all structural storm shutters. Move desks away from structural outer glass.',
          'Evacuate to interior classrooms, gymnasiums, or designated concrete shelter rooms.',
          'Never use rooms containing high-span roofs (like cafeterias or auditoriums) as active shelters.'
        ],
        tips: [
          'High winds create aerodynamic pressure differentials that can easily rip wide, flat roofs off buildings.'
        ]
      }
    ],
    drillSteps: [
      { step: 1, action: "Acknowledge tropical cyclone warning broadcast.", rationale: "Initiates pre-storm containment steps before wind speed increases." },
      { step: 2, action: "Secure loose schoolyard equipment and latch heavy shutters.", rationale: "Eliminates high-speed projectiles that shatter windows." },
      { step: 3, action: "Retreat to the reinforced central gymnasium or concrete shelter.", rationale: "Provides structural stability against heavy wind loads and flying debris." },
      { step: 4, action: "Disconnect non-essential electronic systems.", rationale: "Protects hardware from lightning surges and high-voltage grid spikes." },
      { step: 5, action: "Remain sheltered until local civil safety wardens sound the clear signal.", rationale: "Prevents exposure to sudden, severe wind changes on the back-end of the cyclone." }
    ]
  },
  {
    id: 'tsunami',
    title: 'Tsunami Waves & Coastal Evacuation',
    icon: 'Waves',
    category: 'natural',
    description: 'Learn how earthquakes trigger coastal super-waves, recognize natural tsunami indicators like receding tide lines, and master rapid high-altitude evacuation.',
    difficulty: 'Advanced',
    timeToComplete: '15 mins',
    introduction: 'A tsunami is a series of giant ocean waves caused by sudden disturbances under the ocean, primarily underwater earthquakes, volcanic eruptions, or coastal landslides. They travel at jet-liner speeds and carry immense, destructive energy.',
    causes: [
      'Undersea tectonic earthquakes causing abrupt vertical sea-floor displacement.',
      'Submarine volcanic caldera collapses or explosive aquatic eruptions.',
      'Large underwater landslides displacing vast columns of ocean water.'
    ],
    beforeDisaster: [
      'Map out high-altitude escape routes at least 100 feet (30 meters) above sea level.',
      'Learn to recognize natural warning signs: extreme ground shaking and ocean water receding rapidly.',
      'Familiarize yourself with designated local tsunami evacuation road markers.',
      'Participate in coastal community evacuation drill practices.'
    ],
    duringDisaster: [
      'If near the coast and you feel an earthquake, run immediately inland and to high ground.',
      'Do not wait for official tsunami sirens or alerts if you observe natural signs.',
      'Move on foot to keep evacuation roads clear for emergency vehicle responses.',
      'Never go to the beach to watch a tsunami wave arrive; once visible, it is too late to escape.'
    ],
    afterDisaster: [
      'Stay on high ground; tsunami waves are a series that can continue for many hours.',
      'Listen to emergency broadcasts and do not return to low-lying areas until cleared.',
      'Check for fires, gas leaks, and structural damage before attempting rescue.',
      'Avoid contact with tsunami mud and water, which is highly contaminated with sewage and debris.'
    ],
    safetyTips: [
      'If trapped and unable to reach high ground, climb to the upper floors of a sturdy concrete building.',
      'A tsunami wave is not a single wave, but a series of waves—often the third or fourth is the largest.',
      'Always prioritize climbing higher over traveling longer distances horizontally.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?auto=format&fit=crop&w=600&q=80',
    sections: [
      {
        title: 'Section 1: Tsunami Physics & Receding Shorelines',
        content: [
          'Undersea thrust faults displace water columns upward. In deep oceans, waves are low, but speed up to 500 mph.',
          'As waves reach shallow shores, they slow down and compress, growing into vertical walls up to 100 feet high.',
          'Natural warning: If the sea pulls back dramatically, exposing sea beds, a wave is coming immediately.'
        ],
        tips: [
          'Receding water is a physical vacuum pulling seawater out before the main surge hits. Never collect shells during this time.'
        ]
      },
      {
        title: 'Section 2: High Ground Escapes & Vertical Shelter',
        content: [
          'Run immediately inland or uphill. The minimum safe altitude is 100 feet (30m) or 2 miles inland.',
          'Avoid taking cars, which cause severe gridlocks. Escape on foot or bicycle if possible.',
          'If trapped, seek out reinforced concrete structures with 4 or more floors.'
        ],
        tips: [
          'Steel-reinforced concrete buildings are engineered to withstand horizontal hydraulic loads.'
        ]
      }
    ],
    drillSteps: [
      { step: 1, action: "Identify strong coastal tremors or witness ocean waters receding abruptly.", rationale: "Provides immediate warning that a tsunami is displacing and returning." },
      { step: 2, action: "Abandon seaside locations and run inland on foot.", rationale: "Secures distance from high-velocity impact waves before coastal arrival." },
      { step: 3, action: "Climb to a minimum altitude of 100 feet or the 4th floor of a concrete building.", rationale: "Safeguards against deep marine inundation and high hydraulic forces." },
      { step: 4, action: "Maintain high-ground shelter for at least 3-4 hours.", rationale: "Tsunami waves arrive in a dangerous series, often hours apart." },
      { step: 5, action: "Re-group at a medical triage center and coordinate roll-call.", rationale: "Ensures missing individuals are logged and medical assistance is allocated." }
    ]
  },
  {
    id: 'landslide',
    title: 'Landslides & Mudflow Survival',
    icon: 'Compass',
    category: 'natural',
    description: 'Recognize early warnings of geological slope failures, identify high-hazard zones, and learn defensive maneuvering during sudden debris flows.',
    difficulty: 'Intermediate',
    timeToComplete: '12 mins',
    introduction: 'Landslides involve the downward movement of a mass of rock, earth, or debris on slopes. Often triggered by heavy rains, earthquakes, or volcanic activity, landslides can bury entire structures in seconds.',
    causes: [
      'Prolonged saturation of hillside soil by intense rainstorms or rapid snowmelt.',
      'Seismic tremors fracturing rock formations and destabilizing steep slopes.',
      'Erosion from rivers, human development, or deforestation removing vegetation root anchors.'
    ],
    beforeDisaster: [
      'Identify landslide-prone zones near steep slopes, drainage channels, or cliffs.',
      'Monitor changes on slopes: tilting trees, cracked driveways, or trickling mud.',
      'Avoid building or camping near steep slopes, narrow valleys, and canyon floors.',
      'Develop a school emergency geological hazard plan.'
    ],
    duringDisaster: [
      'If inside a landslide path, evacuate immediately to high, stable ground if possible.',
      'If evacuation is impossible, curl into a tight ball and cover your head with your arms.',
      'Listen for strange sounds like trees cracking, rocks knocking, or a low rumbling hum.'
    ],
    afterDisaster: [
      'Stay away from the slide area; secondary slope failures and mudflows can follow.',
      'Check for trapped or injured victims near the slide margins without entering active hazard zones.',
      'Watch for broken gas, water, and power lines and report them to authorities.'
    ],
    safetyTips: [
      'Rumbling sounds and cracking trees indicate a landslide is moving and imminent.',
      'If trapped inside, shelter under heavy furniture on the side of the room opposite the slide.',
      'Mudflows can flow faster than a person can run; vertical escape or horizontal sidestepping is critical.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=600&q=80',
    sections: [
      {
        title: 'Section 1: Hillside Soil Dynamics & Warning Flags',
        content: [
          'High water saturation increases soil mass and reduces internal friction, triggering gravity slips.',
          'Early warning flags: Cracks in plaster or concrete walls, stuck window frames, tilting trees or phone poles.',
          'Rumbling or rattling sounds indicate boulders hitting or soil shifting uphill.'
        ],
        tips: [
          'Trees that lean in opposite directions (called "crazy trees") indicate the underlying slope soil is shifting.'
        ]
      },
      {
        title: 'Section 2: Evasive Actions & Survival Positions',
        content: [
          'If outdoors, run perpendicular to the landslide path. Do not try to outrun a slide downslope.',
          'If trapped inside, move to upper floors and shelter under a sturdy table on the opposite wall.',
          'If caught in mudflow debris, protect your head, curl into a ball, and try to keep your nose above mud.'
        ],
        tips: [
          'Moving perpendicular (sideways) gets you out of the concentrated canyon flow lines.'
        ]
      }
    ],
    drillSteps: [
      { step: 1, action: "Identify slide warning cues, like sudden trickling mud or cracking trees.", rationale: "Offers early indicators that hillside soil has lost shear strength." },
      { step: 2, action: "Evacuate the slide path by moving perpendicular (sideways) to the flow.", rationale: "Escaping the narrow central debris path is the only way to avoid burial." },
      { step: 3, action: "If trapped indoors, move to the top-most floor and shelter under solid furniture.", rationale: "Creates a protective void if mud breaches the ground floor walls." },
      { step: 4, action: "Alert emergency responders to the location of slide breaches.", rationale: "Enables targeted heavy equipment deployment for trapped victims." },
      { step: 5, action: "Avoid slide zones until certified stable by geological engineers.", rationale: "Saturated slopes frequently experience secondary collapses." }
    ]
  },
  {
    id: 'first_aid',
    title: 'First Aid & Emergency Response',
    icon: 'Activity',
    category: 'health',
    description: 'Master essential medical triage skills, learn the recovery position, and acquire techniques for bleeding control, CPR, and treating thermal burns.',
    difficulty: 'Beginner',
    timeToComplete: '15 mins',
    introduction: 'First aid is the immediate assistance given to any person suffering from a sudden illness or injury. Having these skills on campus saves lives during the critical minutes before professional paramedics arrive.',
    causes: [
      'Accidental physical trauma from falls, collapsing debris, or sharp objects.',
      'Inhalation of smoke or chemicals during active fire outbreaks.',
      'Shock, severe bleeding, or cardiac arrest caused by high-stress disaster situations.'
    ],
    beforeDisaster: [
      'Equip every classroom with a certified, fully-stocked first aid kit.',
      'Keep emergency contact cards and medical alert sheets easily accessible.',
      'Acquire training in Cardiopulmonary Resuscitation (CPR) and AED usage.'
    ],
    duringDisaster: [
      'Assess the scene for safety before approaching any injured person.',
      'Protect yourself by wearing gloves to prevent contact with blood or fluids.',
      'Perform CPR (30 compressions to 2 breaths) if the victim is unresponsive and not breathing.',
      'Apply direct, firm pressure on bleeding wounds using sterile gauze or clean cloths.'
    ],
    afterDisaster: [
      'Place unconscious, breathing victims in the Recovery Position to keep airways clear.',
      'Treat burns by flushing with cool running water for at least 10 minutes.',
      'Monitor victims for signs of shock: pale skin, rapid pulse, and shallow breathing.'
    ],
    safetyTips: [
      'Always verify scene safety first; do not become a second victim.',
      'Never apply butter, ice, or ointments to severe, open thermal burns.',
      'To control bleeding, keep firm pressure applied continuously—do not lift the gauze to check.'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1603398938378-e54eab446dde?auto=format&fit=crop&w=600&q=80',
    sections: [
      {
        title: 'Section 1: Bleeding Control & Wound Care',
        content: [
          'Locate first aid boxes immediately. Put on nitrile protective gloves before contact.',
          'Apply direct, firm pressure on the wound with sterile gauze or a clean shirt.',
          'Elevate the injured limb above heart level to reduce hydraulic flow if bones are intact.',
          'Apply a tight pressure bandage. If bleeding penetrates, add more gauze on top—do not peel off the base.'
        ],
        tips: [
          'Peeling off the base gauze rips away clotting factors and restarts active bleeding.'
        ]
      },
      {
        title: 'Section 2: Cardiopulmonary Resuscitation (CPR) & AED',
        content: [
          'Verify consciousness: Tap the victim\'s shoulder and shout "Are you okay?". Check chest rises.',
          'Call 911 or call out for help. Request anyone nearby locate the school AED.',
          'Begin chest compressions: Interlock fingers, press in center of chest at a depth of 2 inches, at 100-120 compressions/min.',
          'Execute 30 compressions followed by 2 quick rescue breaths. Repeat until help arrives or AED instructions begin.'
        ],
        tips: [
          'If you don\'t want to do mouth-to-mouth, perform continuous "hands-only" chest compressions. It keeps blood oxygen moving.'
        ]
      }
    ],
    drillSteps: [
      { step: 1, action: "Scan the surrounding environment for active hazards (live wires, fires).", rationale: "Prevents the first aider from being injured or incapacitated." },
      { step: 2, action: "Assess victim responsiveness and check for breathing.", rationale: "Determines if immediate life-support interventions like CPR are needed." },
      { step: 3, action: "Call for professional emergency services and fetch the nearest AED.", rationale: "Ensures advanced cardiac care and professional transport are on the way." },
      { step: 4, action: "Apply continuous direct pressure to heavy bleeding areas.", rationale: "Stops rapid exsanguination and prevents systemic shock." },
      { step: 5, action: "Place breathing, unconscious victims in the stable side recovery position.", rationale: "Keeps the tongue and fluids from obstructing the airway." }
    ]
  }
];

export const QUIZZES: Quiz[] = [
  {
    id: 'earthquake_quiz',
    title: 'Earthquake Preparedness Quiz',
    moduleReference: 'earthquake',
    questions: [
      {
        id: 'eq-q1',
        text: 'During active seismic shaking inside a classroom, what is the best immediate action to take?',
        options: [
          'Run out of the building down the nearest stairwell.',
          'Drop, Cover, and Hold On underneath a sturdy desk.',
          'Stand in the doorway for structural support.',
          'Crawl towards the window to call for rescue.'
        ],
        correctAnswer: 1,
        explanation: 'Drop, Cover, and Hold On underneath a sturdy desk is the globally recognized gold standard. Running during shaking is a major cause of falls, fractures, and injuries from flying tiles.'
      },
      {
        id: 'eq-q2',
        text: 'Why are school elevators strictly prohibited during and immediately after an earthquake?',
        options: [
          'Elevators require higher electrical priority needed for emergency lighting.',
          'Elevator shafts can warp, and electrical grid failures will likely trap occupants inside.',
          'Elevators are reserved exclusively for school administrators.',
          'Elevators can trigger chemical fire suppression systems.'
        ],
        correctAnswer: 1,
        explanation: 'Elevator shafts are highly susceptible to mechanical warping during shifts, and building power outages will instantly leave occupants stranded.'
      },
      {
        id: 'eq-q3',
        text: 'What should you do before an earthquake to minimize injuries in a school science laboratory?',
        options: [
          'Store all water and chemicals on high shelves for easy viewing.',
          'Keep all gas valves open to relieve systemic pressure.',
          'Anchor tall shelves and secure chemical agents on low shelves with protective lips.',
          'Close all ventilation ducts to trap fumes.'
        ],
        correctAnswer: 2,
        explanation: 'Anchoring shelves and placing toxic chemicals on low, lipped shelves prevents toxic spills, fires, and broken glassware during shaking.'
      },
      {
        id: 'eq-q4',
        text: 'Where is the safest muster point on a school or college campus following an evacuation?',
        options: [
          'A covered breezeway or building patio.',
          'An open playground, sports field, or parking area away from power lines and brick walls.',
          'Directly next to the main building entrance for ease of accountability.',
          'Inside the indoor gymnasium.'
        ],
        correctAnswer: 1,
        explanation: 'Open spaces away from glass facade, loose brick walls, and high-voltage power lines offer protection from structural collapses and falling debris.'
      },
      {
        id: 'eq-q5',
        text: 'If you are outdoors on campus when an earthquake strikes, what is the safest procedure?',
        options: [
          'Run inside the nearest concrete building.',
          'Stand underneath a tall tree or concrete lamppost.',
          'Move to an open area away from structures, streetlights, and utilities, then drop to the ground.',
          'Lie down next to a brick perimeter wall.'
        ],
        correctAnswer: 2,
        explanation: 'Moving to open ground away from facades, windows, trees, and power lines protects you from falling objects, which pose the greatest hazard outdoors.'
      }
    ]
  },
  {
    id: 'fire_quiz',
    title: 'Fire Safety & Extinguisher Quiz',
    moduleReference: 'fire',
    questions: [
      {
        id: 'fi-q1',
        text: 'What does the abbreviation "P.A.S.S." stand for in fire extinguisher operation?',
        options: [
          'Push, Aim, Shake, Sweep',
          'Pull, Aim, Squeeze, Sweep',
          'Plan, Alert, Secure, Shelter',
          'Point, Activate, Squeeze, Stand'
        ],
        correctAnswer: 1,
        explanation: 'P.A.S.S. stands for Pull (the pin), Aim (at the base of the fire), Squeeze (the handle), and Sweep (side to side).'
      },
      {
        id: 'fi-q2',
        text: 'When evacuating a room filled with thick, toxic smoke, what is the safest way to travel?',
        options: [
          'Walk quickly while holding a dry paper towel over your face.',
          'Crawl low on your hands and knees where the air is cooler and cleaner.',
          'Sprint as fast as possible to minimize contact with smoke.',
          'Walk backwards to prevent inhaling smoke particles directly.'
        ],
        correctAnswer: 1,
        explanation: 'Because heat and toxic smoke rise, the safest, coolest, and most oxygen-rich air is always found close to the floor.'
      },
      {
        id: 'fi-q3',
        text: 'What should you do before opening a closed classroom door during a fire alarm?',
        options: [
          'Open it slightly and peek through to check for flames.',
          'Touch the handle and door with the back of your hand to check for radiant heat.',
          'Kick the door hard to check if it has been structurally weakened.',
          'Wait for a firefighter to open the door.'
        ],
        correctAnswer: 1,
        explanation: 'Checking the door with the back of your hand prevents you from opening it into an active flashover/fire zone, which would flood your room with flame and toxic draft.'
      },
      {
        id: 'fi-q4',
        text: 'If your clothing catches fire, what is the correct emergency reaction sequence?',
        options: [
          'Sprint to the nearest shower or water tap.',
          'Stop, Drop, and Roll on the ground, covering your face with your hands.',
          'Fan the flames with a book or folder to blow them out.',
          'Take off the burning item immediately regardless of injuries.'
        ],
        correctAnswer: 1,
        explanation: 'Stop, Drop, and Roll smothers the fire. Covering your face protects your airways and facial tissue from thermal burns.'
      },
      {
        id: 'fi-q5',
        text: 'What is the very first action you should take upon discovering a fire in a school building?',
        options: [
          'Run to find a teacher or administrator.',
          'Attempt to extinguish the fire entirely on your own.',
          'Pull the nearest manual fire alarm station to alert the campus.',
          'Pack all your personal textbooks and computer gear.'
        ],
        correctAnswer: 2,
        explanation: 'Pulling the fire alarm alert is the top priority, ensuring the entire school triggers their safety drill, and emergency responders are summoned.'
      }
    ]
  },
  {
    id: 'flood_quiz',
    title: 'Severe Flooding & Water Safety Quiz',
    moduleReference: 'flood',
    questions: [
      {
        id: 'fl-q1',
        text: 'If flash floodwaters begin rising around your campus and reach a depth of 6 inches, what is the safest immediate action?',
        options: [
          'Walk or wade home before it gets deeper.',
          'Drive home in a regular passenger vehicle.',
          'Move vertically to the school building\'s second floor or higher.',
          'Swim in the school courtyard to test water currents.'
        ],
        correctAnswer: 2,
        explanation: 'Just 6 inches of moving water can sweep an adult off their feet. Moving up to upper levels inside a sturdy building is the safest action.'
      },
      {
        id: 'fl-q2',
        text: 'What is the main danger of wading or walking through muddy standing floodwater?',
        options: [
          'It can ruin your shoes.',
          'It can conceal open manholes, sharp debris, sinkholes, and charged electrical cables.',
          'It might affect cellular signal strength.',
          'It is too cold for outdoor play.'
        ],
        correctAnswer: 1,
        explanation: 'Floodwaters are highly contaminated and mask extreme hidden physical hazards like open sewers, jagged materials, or high-voltage electric currents.'
      },
      {
        id: 'fl-q3',
        text: 'How much rushing water is typically required to float or wash away most passenger cars and SUVs?',
        options: [
          '6 inches',
          '12 inches',
          '24 inches (2 feet)',
          '48 inches (4 feet)'
        ],
        correctAnswer: 2,
        explanation: 'While 6 inches can knock down a walker, just 2 feet of rushing water can lift and sweep away heavy SUVs or passenger cars. Turn Around, Don\'t Drown!'
      },
      {
        id: 'fl-q4',
        text: 'Why should you avoid non-essential phone calls and social media streaming during a flood evacuation?',
        options: [
          'To preserve vital battery life for emergency 911 or coordinator contact.',
          'To avoid cellular wave noise in rescue systems.',
          'It is illegal to use screens in wet environments.',
          'Water splashes will deactivate the touch sensor.'
        ],
        correctAnswer: 0,
        explanation: 'Conserving battery is a critical survival action. You must keep your phone functional so you can call for help or coordinate with rescuers if isolated.'
      },
      {
        id: 'fl-q5',
        text: 'When boarding rescue boats during evacuation, what should you do with heavy packs and backpacks?',
        options: [
          'Bring all items to safeguard school records and personal gear.',
          'Leave non-essential heavy bags behind, don a life jacket, and prioritize human safety.',
          'Attach heavy weights to the bags to sink them.',
          'Wait for a second boat to carry only luggage.'
        ],
        correctAnswer: 1,
        explanation: 'Leaving heavy, bulky bags behind ensures rescue boats stay balanced and uncluttered, maximizing space and safety for all evacuees.'
      }
    ]
  }
];

export const DISASTER_SIMULATORS: DisasterSimulator[] = [
  {
    id: 'sim_earthquake',
    title: 'Earthquake in Classroom',
    description: 'You are attending a lecture inside Room 102 when a major earthquake strikes. Shelves are swaying, and ceiling tiles are starting to fall. Quick choices will save your health and score!',
    suggestedItems: ['Emergency Whistle', 'Heavy Flashlight', 'Safety Goggles', 'Protective Helmet'],
    steps: {
      1: {
        text: "The ground begins to shake violently. Tall cabinets are wobbling, and heavy books are flying off the shelves. What is your first move?",
        choices: [
          {
            text: "Sprint towards the doorway and run out to the hallway stairs.",
            impactHealth: -40,
            impactScore: -20,
            feedback: "Dangerous decision! During active shaking, falling tiles, lights, and debris pose the greatest danger. The shaking makes you fall and bruise your knee.",
            isCorrect: false,
            nextStep: 2
          },
          {
            text: "Dive underneath a sturdy steel-frame desk, cover your head/neck with your arms, and grab a desk leg.",
            impactHealth: 0,
            impactScore: 40,
            feedback: "Excellent! 'Drop, Cover, and Hold On' is the gold standard response. A heavy light fixture falls right where you were standing, but the desk shields you completely.",
            isCorrect: true,
            nextStep: 2
          }
        ]
      },
      2: {
        text: "The initial severe shaking subsides, but you smell gas and see dust filling the room. The power has failed, and the building alarm is blaring. What is your action?",
        choices: [
          {
            text: "Calmly instruct classmates to protect their heads with books and exit down the designated evacuation stairs.",
            impactHealth: 0,
            impactScore: 50,
            feedback: "Superb leadership! Staying calm and directing an orderly evacuation on foot via the stairwell ensures safety and prevents crowd panic.",
            isCorrect: true,
            nextStep: 3
          },
          {
            text: "Push past others to get out of the door first, running as fast as you can.",
            impactHealth: -15,
            impactScore: -10,
            feedback: "Bad response. Panic and running down corridors creates crowd crush hazards. You scrape your shoulder and elbow against the doorframe.",
            isCorrect: false,
            nextStep: 3
          }
        ]
      },
      3: {
        text: "You reach the main staircase. The emergency lights are flickering. Some students are crowding around the elevator doors since the elevator seems to be on a backup generator. What do you do?",
        choices: [
          {
            text: "Take the elevator to descend to the ground floor as fast as possible.",
            impactHealth: -50,
            impactScore: -30,
            feedback: "Disastrous choice! Elevators can lose power instantly during aftershocks, or their shafts can warp. You get trapped inside a dark, stalled elevator for hours.",
            isCorrect: false,
            nextStep: 4
          },
          {
            text: "Bypass the elevator and stick to the stairwell, descending in single file.",
            impactHealth: 0,
            impactScore: 45,
            feedback: "Perfect choice! Staying off elevators is key during earthquakes. You make your way down the stairwell safely.",
            isCorrect: true,
            nextStep: 4
          }
        ]
      },
      4: {
        text: "You exit the building onto the campus lawn. On your left is the library's decorative brick wall, and overhead are power lines. Where do you assemble?",
        choices: [
          {
            text: "Stand near the library facade to rest in the shade.",
            impactHealth: -25,
            impactScore: -15,
            feedback: "An aftershock strikes! Unsecured masonry and loose bricks from the library facade crumble, striking you and causing injury.",
            isCorrect: false,
            nextStep: 5
          },
          {
            text: "Walk to the middle of the open sports field, far away from buildings, streetlights, and overhead lines.",
            impactHealth: 0,
            impactScore: 50,
            feedback: "Superb positioning! You are in clear space. When the aftershock hits, you stay completely safe and help the teacher coordinate roll call.",
            isCorrect: true,
            nextStep: 5
          }
        ]
      },
      5: {
        text: "The drill is completed! Emergency personnel have arrived. You are safe in the muster zone. Use your whistle or confirm your safety with the safety warden.",
        choices: [
          {
            text: "Complete Simulation",
            impactHealth: 0,
            impactScore: 0,
            feedback: "Classroom Earthquake simulation completed successfully.",
            isCorrect: true
          }
        ]
      }
    }
  },
  {
    id: 'sim_flood',
    title: 'Flood Near School',
    description: 'Heavy, continuous rainfall has caused a nearby river to breach its banks. Flash flood waters are rising rapidly and surrounding the campus. Master your hydrological survival instincts!',
    suggestedItems: ['High-Water Boots', 'Life Vest', 'Emergency Radio', 'Waterproof Backpack'],
    steps: {
      1: {
        text: "The school yard is quickly filling with muddy water, already 6 inches deep. The principal announces a flash flood warning. What is your first action?",
        choices: [
          {
            text: "Wade through the water immediately to try and walk home before it gets deeper.",
            impactHealth: -35,
            impactScore: -25,
            feedback: "Extremely dangerous! Just 6 inches of moving floodwater can sweep an adult off their feet. Muddy water also hides open manholes, glass, and electrical hazards.",
            isCorrect: false,
            nextStep: 2
          },
          {
            text: "Move up to the school building's second floor with your dry supplies.",
            impactHealth: 0,
            impactScore: 40,
            feedback: "Excellent! Moving vertically to high ground inside a sturdy concrete school structure is the safest action when flash floods surround the area.",
            isCorrect: true,
            nextStep: 2
          }
        ]
      },
      2: {
        text: "The floodwaters continue to rise, fully submerging the ground floor classrooms. The main power grid fails. You need to keep up-to-date with emergency directives. How do you check for info?",
        choices: [
          {
            text: "Turn on your battery-powered Emergency Radio to listen for local rescue broadcasts.",
            impactHealth: 0,
            impactScore: 50,
            feedback: "Perfect! Monitoring official emergency radio channels keeps you informed on active rescue efforts, water purity notices, and regional coordinates.",
            isCorrect: true,
            nextStep: 3
          },
          {
            text: "Repeatedly call your friends and stream social media to see live updates.",
            impactHealth: -10,
            impactScore: -10,
            feedback: "Calling repeatedly and streaming video quickly drains your cell phone battery, which should be strictly conserved for emergency 911/safety lines.",
            isCorrect: false,
            nextStep: 3
          }
        ]
      },
      3: {
        text: "You spot a student stuck on an outdoor electrical cabinet, surrounded by 3 feet of fast-flowing water. What do you do?",
        choices: [
          {
            text: "Jump into the current and swim out to pull them to safety.",
            impactHealth: -45,
            impactScore: -20,
            feedback: "Highly perilous! Fast-flowing water is incredibly strong. You get swept into a metal fence, fracturing a rib and requiring rescue yourself.",
            isCorrect: false,
            nextStep: 4
          },
          {
            text: "Throw them a safety rope, look for a long stick, and yell instructions to stay put while notifying teachers.",
            impactHealth: 0,
            impactScore: 55,
            feedback: "Brilliant rescue technique! 'Throw, don't go'. You safely secure them to the building edge without endangering your own life.",
            isCorrect: true,
            nextStep: 4
          }
        ]
      },
      4: {
        text: "Emergency responders arrive on rescue boats to evacuate the school. They instruct you to board. You have a heavy backpack with laptop and textbooks. What is your move?",
        choices: [
          {
            text: "Leave non-essential heavy bags behind, don a Life Vest, and board the rescue boat.",
            impactHealth: 0,
            impactScore: 50,
            feedback: "Correct! Your physical safety is the absolute priority. Leaving heavy bags makes the boat lighter, less crowded, and safer for all evacuees.",
            isCorrect: true,
            nextStep: 5
          },
          {
            text: "Insist on carrying all your heavy backpacks and gear onto the boat.",
            impactHealth: -15,
            impactScore: -15,
            feedback: "Heavy bags clutter the small boat, slowing down boarding and posing tripping or tipping hazards if you slip.",
            isCorrect: false,
            nextStep: 5
          }
        ]
      },
      5: {
        text: "You have successfully reached high ground! Check in with safety workers and get clean drinking water.",
        choices: [
          {
            text: "Complete Simulation",
            impactHealth: 0,
            impactScore: 0,
            feedback: "Flood Near School simulation completed successfully.",
            isCorrect: true
          }
        ]
      }
    }
  },
  {
    id: 'sim_fire',
    title: 'Fire in Laboratory',
    description: 'An electrical experiment sparks in the chemistry lab, igniting a bottle of flammable ethanol. The smoke alarm is roaring, and fire is spreading. Act swiftly!',
    suggestedItems: ['Fire Extinguisher', 'Fire Blanket', 'Safety Goggles', 'Wet Towel'],
    steps: {
      1: {
        text: "An ethanol bottle ignites, spreading active flames across the wooden countertop. What is your first action?",
        choices: [
          {
            text: "Throw a beaker of water directly onto the chemical ethanol fire.",
            impactHealth: -35,
            impactScore: -25,
            feedback: "Dangerous mistake! Water splits and splashes burning flammable liquid, spreading the chemical fire instantly and risking face burns.",
            isCorrect: false,
            nextStep: 2
          },
          {
            text: "Grab the Class B Fire Extinguisher, pull the pin, and use the P.A.S.S. technique to sweep the base of the fire.",
            impactHealth: 0,
            impactScore: 45,
            feedback: "Excellent response! Class B extinguishers are rated for flammable liquids. You suppress the primary counter fire safely.",
            isCorrect: true,
            nextStep: 2
          }
        ]
      },
      2: {
        text: "The main counter fire is suppressed, but toxic black smoke has reached the ceiling and is descending. What do you do next?",
        choices: [
          {
            text: "Drop to your knees, cover your mouth with a Wet Towel, and crawl low to the exit.",
            impactHealth: 0,
            impactScore: 50,
            feedback: "Perfect! Heat and toxic smoke rise, so the safest, clearest air is close to the floor. The wet towel filters out soot.",
            isCorrect: true,
            nextStep: 3
          },
          {
            text: "Stand up straight and run through the smoke toward the door.",
            impactHealth: -40,
            impactScore: -15,
            feedback: "You inhale hot toxic gases, burning your airway and making you extremely dizzy, which severely hinders your egress.",
            isCorrect: false,
            nextStep: 3
          }
        ]
      },
      3: {
        text: "You reach the lab exit door. The metal handle looks dark and clean, but you need to check if there is fire in the corridor outside. How do you open it?",
        choices: [
          {
            text: "Grab the handle firmly with your palm and pull the door open quickly.",
            impactHealth: -30,
            impactScore: -10,
            feedback: "Ouch! The handle is extremely hot, causing severe burns to your palm. Pulling the door open quickly also feeds oxygen to the fire.",
            isCorrect: false,
            nextStep: 4
          },
          {
            text: "Touch the door and handle with the back of your hand to test the temperature.",
            impactHealth: 0,
            impactScore: 50,
            feedback: "Perfect! The back of your hand is highly heat-sensitive and protects your palm, which you need for crawling and climbing. Finding it hot, you use the alternate exit.",
            isCorrect: true,
            nextStep: 4
          }
        ]
      },
      4: {
        text: "You exit the room, but a classmate's sleeve has caught fire! They are starting to panic and run. How do you help?",
        choices: [
          {
            text: "Shout 'Stop, Drop, and Roll!' and throw a Fire Blanket over them to smother the flames.",
            impactHealth: 0,
            impactScore: 60,
            feedback: "Amazing quick thinking! Stopping, dropping, rolling, and wrapping in a fire blanket cuts off oxygen, extinguishing the flames immediately.",
            isCorrect: true,
            nextStep: 5
          },
          {
            text: "Tell them to run as fast as possible to the emergency eyewash station.",
            impactHealth: -25,
            impactScore: -20,
            feedback: "Running fans the flames, supplying more oxygen and making the fire burn faster and hotter. This worsens their injuries.",
            isCorrect: false,
            nextStep: 5
          }
        ]
      },
      5: {
        text: "You have safely evacuated to the outdoor muster point! Check in with teachers for headcount.",
        choices: [
          {
            text: "Complete Simulation",
            impactHealth: 0,
            impactScore: 0,
            feedback: "Fire in Laboratory simulation completed successfully.",
            isCorrect: true
          }
        ]
      }
    }
  }
];

export const RISK_ASSESSMENT_ITEMS: RiskAssessmentItem[] = [
  {
    id: 'risk-1',
    category: 'Structural',
    question: 'Are tall classroom bookshelves, filing cabinets, and heavy display boards bolted securely to structural studs/walls?',
    hazardDescription: 'Unsecured tall furniture will topple instantly during seismic shaking, causing severe crushing injuries and blocking egress corridors.',
    mitigationTip: 'Install heavy-duty L-brackets or nylon straps on all cabinets exceeding 4 feet in height.',
    score: 15
  },
  {
    id: 'risk-2',
    category: 'Non-Structural',
    question: 'Are all exit doors, corridors, and fire stairs entirely clear of furniture, backpacks, or student storage crates?',
    hazardDescription: 'Obstructed evacuation routes cause high-density bottlenecking, trips, and severe delays when exiting a darkened, smoke-filled structure.',
    mitigationTip: 'Establish a strict campus-wide hallway clearance policy; provide designated locker bays for heavy bags.',
    score: 20
  },
  {
    id: 'risk-3',
    category: 'Operational',
    question: 'Are campus fire extinguishers inspected monthly, fully charged (indicator pin in the green zone), and easily accessible?',
    hazardDescription: 'Uncharged or blocked fire extinguishers prevent staff from suppressing small trash can or laboratory electrical fires before they spread.',
    mitigationTip: 'Appoint floor safety wardens to log monthly audits on physical inspection tags hanging on each extinguisher.',
    score: 15
  },
  {
    id: 'risk-4',
    category: 'Operational',
    question: 'Does the school display clear emergency exit floorplan maps and assembly instructions next to every room\'s exit door?',
    hazardDescription: 'Without maps, substitute teachers, guests, or panicked students will lose orientation and move in the wrong direction during high-stress alerts.',
    mitigationTip: 'Laminate and bolt high-contrast map visual sheets exactly at eye level near every classroom door latch.',
    score: 15
  },
  {
    id: 'risk-5',
    category: 'Environmental',
    question: 'Are chemical reactants in science laboratories stored on low, secure cabinets containing raised edge guards or lips?',
    hazardDescription: 'Shattered laboratory glass on high open shelves leads to hazardous toxic vapor mixtures, acid burns, and rapid ignition sources during earthquakes.',
    mitigationTip: 'Use plastic secondary storage containment trays and lock chemical cabinets with child-proof safety latches.',
    score: 20
  },
  {
    id: 'risk-6',
    category: 'Environmental',
    question: 'Is the campus main power grid and computer servers supported by operational surge protectors and emergency generator supplies?',
    hazardDescription: 'Immediate power cuts leave crucial hallways, emergency exits, and intercom PA grids dark and non-communicative.',
    mitigationTip: 'Perform bi-monthly testing of the automatic diesel generators and verify backup battery systems on emergency PA horns.',
    score: 15
  }
];
