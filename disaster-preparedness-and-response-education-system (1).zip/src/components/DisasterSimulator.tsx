import React, { useState } from 'react';
import { DISASTER_SIMULATORS } from '../data/safetyData';
import { DisasterSimulator as SimType, UserProfile } from '../types';
import { 
  Flame, ShieldAlert, Waves, Heart, Trophy, RefreshCw, 
  CheckCircle, XCircle, ChevronRight, HelpCircle, AlertCircle, ArrowRight
} from 'lucide-react';

interface DisasterSimulatorProps {
  user: UserProfile | null;
  onUnlockBadge: (badgeId: string) => void;
  onNavigate: (tab: string) => void;
}

export default function DisasterSimulator({ user, onUnlockBadge, onNavigate }: DisasterSimulatorProps) {
  const [selectedSim, setSelectedSim] = useState<SimType>(DISASTER_SIMULATORS[0]);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentStepId, setCurrentStepId] = useState<number>(1);
  
  // Gameplay states
  const [inventory, setInventory] = useState<string[]>([]);
  const [health, setHealth] = useState<number>(100);
  const [score, setScore] = useState<number>(0);
  const [feedback, setFeedback] = useState<string>('');
  const [feedbackIsCorrect, setFeedbackIsCorrect] = useState<boolean>(true);
  const [showFeedback, setShowFeedback] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [gameWon, setGameWon] = useState<boolean>(false);
  
  // Navigation transition state
  const [pendingNextStep, setPendingNextStep] = useState<number | undefined>(undefined);

  const startSimulation = () => {
    setIsPlaying(true);
    setCurrentStepId(1);
    setHealth(100);
    setScore(0);
    setFeedback('');
    setShowFeedback(false);
    setIsGameOver(false);
    setGameWon(false);
    setPendingNextStep(undefined);
  };

  const handleToggleInventory = (item: string) => {
    if (inventory.includes(item)) {
      setInventory(inventory.filter(i => i !== item));
    } else {
      if (inventory.length < 2) {
        setInventory([...inventory, item]);
      }
    }
  };

  const handleChoice = (choice: any) => {
    // Process impact
    const calculatedHealth = Math.max(0, health + choice.impactHealth);
    const calculatedScore = Math.max(0, score + choice.impactScore);
    
    setHealth(calculatedHealth);
    setScore(calculatedScore);
    setFeedback(choice.feedback);
    setFeedbackIsCorrect(choice.isCorrect);
    setShowFeedback(true);

    if (calculatedHealth <= 0) {
      setPendingNextStep(-1); // death game over flag
      return;
    }

    if (choice.nextStep) {
      setPendingNextStep(choice.nextStep);
    } else {
      setPendingNextStep(0); // victory game won flag
    }
  };

  const handleConfirmFeedback = () => {
    setShowFeedback(false);
    
    if (pendingNextStep === -1) {
      setIsGameOver(true);
      setGameWon(false);
    } else if (pendingNextStep === 0) {
      setIsGameOver(true);
      setGameWon(true);
      
      // Trigger badge unlock in parent
      if (selectedSim.id === 'sim_earthquake') {
        onUnlockBadge('Earthquake Rescuer');
      } else if (selectedSim.id === 'sim_flood') {
        onUnlockBadge('Flood Specialist');
      } else if (selectedSim.id === 'sim_fire') {
        onUnlockBadge('Fire Warden');
      }
    } else if (pendingNextStep !== undefined) {
      setCurrentStepId(pendingNextStep);
    }
    
    setPendingNextStep(undefined);
  };

  const getSimulatorIcon = (id: string, className: string) => {
    switch(id) {
      case 'sim_earthquake':
        return <ShieldAlert className={className} />;
      case 'sim_flood':
        return <Waves className={className} />;
      case 'sim_fire':
        return <Flame className={className} />;
      default:
        return <ShieldAlert className={className} />;
    }
  };

  const getBadgeName = (id: string) => {
    if (id === 'sim_earthquake') return 'Earthquake Rescuer';
    if (id === 'sim_flood') return 'Flood Specialist';
    return 'Fire Warden';
  };

  const currentStep = selectedSim.steps[currentStepId];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Info */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-56 h-56 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-2xl space-y-3 z-10 relative">
          <span className="text-[10px] font-mono font-extrabold tracking-wider bg-amber-500/10 text-amber-500 px-2.5 py-1 rounded border border-amber-500/20 uppercase">
            Active Roleplay Arena
          </span>
          <h1 className="text-2xl md:text-3xl font-black text-slate-100 tracking-tight flex items-center gap-2">
            <ShieldAlert className="w-7 h-7 text-amber-500" />
            Interactive Disaster Simulator
          </h1>
          <p className="text-xs text-slate-400 leading-relaxed">
            Put your theoretical disaster safety knowledge to the test in our high-stakes situational sandbox. Equip your safety backpack, choose your tactical actions, and survive multiple hazard scenarios with peak health and score.
          </p>
        </div>
      </div>

      {!isPlaying ? (
        /* Scenario Selection Screen */
        <div className="grid md:grid-cols-3 gap-6">
          {DISASTER_SIMULATORS.map((sim) => (
            <div key={sim.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4 shadow-lg hover:border-slate-750 transition-all">
              <div className="space-y-3">
                <div className={`p-3 bg-slate-950 border border-slate-800 rounded-xl w-fit ${
                  sim.id === 'sim_earthquake' ? 'text-amber-500' : sim.id === 'sim_flood' ? 'text-blue-500' : 'text-red-500'
                }`}>
                  {getSimulatorIcon(sim.id, "w-6 h-6 animate-pulse")}
                </div>
                
                <div>
                  <h3 className="font-extrabold text-slate-100 text-sm tracking-tight">{sim.title}</h3>
                  <p className="text-[11px] text-slate-400 leading-relaxed mt-1">{sim.description}</p>
                </div>
                
                {/* Equipment Picker */}
                <div className="space-y-2 pt-2 border-t border-slate-850">
                  <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase block">
                    Select Prep Gear (Max 2 items)
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {sim.suggestedItems.map((item) => {
                      const isPicked = inventory.includes(item);
                      return (
                        <button
                          key={item}
                          onClick={() => handleToggleInventory(item)}
                          className={`text-[10px] font-semibold px-2 py-1.5 rounded border transition-all cursor-pointer ${
                            isPicked 
                              ? 'bg-amber-500 text-slate-950 border-amber-500' 
                              : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          {item}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  setSelectedSim(sim);
                  startSimulation();
                }}
                className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2.5 rounded text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow"
              >
                Launch Simulation <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      ) : (
        /* Active Game Arena */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl max-w-3xl mx-auto">
          
          {/* Dashboard Status Header */}
          <div className="bg-slate-950 border-b border-slate-800 p-4 md:px-6 flex items-center justify-between gap-4 text-xs">
            {/* Health Monitor */}
            <div className="flex items-center gap-2 flex-1 max-w-xs">
              <Heart className={`w-5 h-5 shrink-0 ${health > 30 ? 'text-red-500' : 'text-red-600 animate-pulse'}`} />
              <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-slate-800">
                <div 
                  className={`h-full transition-all duration-300 ${
                    health > 60 ? 'bg-emerald-500' : health > 30 ? 'bg-amber-500' : 'bg-red-600'
                  }`}
                  style={{ width: `${health}%` }}
                />
              </div>
              <span className="font-mono font-bold text-slate-300 shrink-0">{health}% HP</span>
            </div>

            {/* Score and Gear */}
            <div className="flex items-center gap-4 shrink-0">
              <div className="flex items-center gap-1.5 font-mono text-amber-500 font-bold">
                <Trophy className="w-4 h-4 text-amber-500" />
                <span>{score} PTS</span>
              </div>
              <div className="hidden sm:flex items-center gap-1">
                <span className="text-[10px] text-slate-500 uppercase mr-1">Active Gear:</span>
                {inventory.length === 0 ? (
                  <span className="text-[10px] text-slate-600 font-mono">None Selected</span>
                ) : (
                  inventory.map(item => (
                    <span key={item} className="text-[9px] bg-slate-900 px-2 py-0.5 rounded border border-slate-850 text-slate-300 font-medium">
                      {item}
                    </span>
                  ))
                )}
              </div>
            </div>
          </div>

          <div className="p-6 md:p-8 space-y-6">
            {isGameOver ? (
              /* End Game screens */
              <div className="text-center p-6 space-y-6">
                {gameWon ? (
                  <div className="space-y-4">
                    <Trophy className="w-16 h-16 text-amber-500 mx-auto animate-bounce" />
                    <h2 className="text-xl font-black text-slate-100 tracking-tight uppercase">Simulation Succeeded!</h2>
                    <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                      Outstanding performance! You successfully navigated all the hazardous choices in the "{selectedSim.title}" scenario.
                    </p>
                    <div className="bg-emerald-500/10 border border-emerald-500/20 p-4 rounded-xl max-w-sm mx-auto space-y-1">
                      <span className="text-[10px] text-emerald-400 font-mono uppercase font-bold tracking-widest">Safety Reward Acquired</span>
                      <h4 className="font-bold text-slate-100 text-sm">🎖️ {getBadgeName(selectedSim.id)} Badge</h4>
                      <p className="text-[10px] text-slate-500 font-mono">Your credential is synced with your student files</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <AlertCircle className="w-16 h-16 text-red-500 mx-auto animate-pulse" />
                    <h2 className="text-xl font-black text-slate-100 tracking-tight uppercase text-red-500">Casualty Avoidance Failure</h2>
                    <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                      Your health dropped to 0%. In a physical catastrophe, this combination of choices would lead to immediate casualty. Read up on your drills and retry!
                    </p>
                  </div>
                )}

                <div className="pt-4 flex justify-center gap-3">
                  <button
                    onClick={() => setIsPlaying(false)}
                    className="bg-slate-950 hover:bg-slate-850 border border-slate-850 text-slate-300 px-5 py-2.5 rounded text-xs font-bold transition-all cursor-pointer"
                  >
                    Exit Simulator
                  </button>
                  <button
                    onClick={startSimulation}
                    className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-5 py-2.5 rounded text-xs transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Restart Scenario
                  </button>
                </div>
              </div>
            ) : showFeedback ? (
              /* Choice Feedback Overlay Screen */
              <div className="bg-slate-950 border border-slate-850 rounded-xl p-6 text-center space-y-4 animate-scale-in">
                <div className="flex justify-center">
                  {feedbackIsCorrect ? (
                    <CheckCircle className="w-14 h-14 text-emerald-500 animate-pulse" />
                  ) : (
                    <XCircle className="w-14 h-14 text-red-500 animate-pulse" />
                  )}
                </div>
                <h3 className={`font-black text-sm uppercase ${feedbackIsCorrect ? 'text-emerald-500' : 'text-red-500'}`}>
                  {feedbackIsCorrect ? 'Correct Safety Action' : 'Incorrect Safety Action'}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto">
                  {feedback}
                </p>

                <div className="pt-4 border-t border-slate-850 flex flex-col items-center gap-2">
                  <button
                    onClick={handleConfirmFeedback}
                    className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-6 py-2.5 rounded-lg text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow"
                  >
                    Continue to Next Phase <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              /* Active Step Choice Question screen */
              <div className="space-y-6">
                {/* Visual Description Panel */}
                <div className="p-5 bg-slate-950 border border-slate-850 rounded-xl space-y-3 relative">
                  <span className="absolute top-0 right-0 m-3 px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] font-mono text-slate-500 uppercase tracking-widest">
                    Phase Step {currentStepId}
                  </span>
                  <div className="flex gap-3">
                    <HelpCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                    <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-medium">
                      {currentStep.text}
                    </p>
                  </div>
                </div>

                {/* Branching choices list */}
                <div className="space-y-3 pt-2">
                  <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase pl-1">
                    Select Your Tactical Escape Decision
                  </span>
                  <div className="grid gap-3">
                    {currentStep.choices.map((choice, cIdx) => (
                      <button
                        key={cIdx}
                        onClick={() => handleChoice(choice)}
                        className="w-full text-left p-4 bg-slate-950 hover:bg-slate-850 border border-slate-850 hover:border-slate-750 text-slate-100 rounded-xl transition-all focus:outline-none focus:ring-1 focus:ring-amber-500 text-xs font-semibold leading-relaxed cursor-pointer"
                      >
                        {choice.text}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
