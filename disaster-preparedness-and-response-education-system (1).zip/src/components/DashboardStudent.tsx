import React, { useState } from 'react';
import { UserProfile, EmergencyAlert, LearningModule } from '../types';
import { LEARNING_MODULES, QUIZZES } from '../data/safetyData';
import { 
  User, Award, GraduationCap, CheckCircle, Clock, 
  ChevronRight, Heart, Trophy, FileBadge, Info, Calendar, Lock, Unlock,
  Bell, ShieldAlert, Sparkles, AlertTriangle, BookOpen, RefreshCw, FileText, ArrowRight,
  ListChecks, CheckCircle2, Check, ExternalLink
} from 'lucide-react';

interface StudentDashboardProps {
  user: UserProfile | null;
  alerts?: EmergencyAlert[];
  onNavigate: (tab: string) => void;
}

export default function StudentDashboard({ user, alerts = [], onNavigate }: StudentDashboardProps) {
  const [notifFilter, setNotifFilter] = useState<'all' | 'alerts' | 'actions' | 'milestones'>('all');

  if (!user) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center space-y-4 max-w-md mx-auto shadow-2xl">
        <User className="w-12 h-12 text-slate-500 mx-auto animate-pulse" />
        <h3 className="font-black text-slate-100 text-sm uppercase tracking-tight">Student Session Inactive</h3>
        <p className="text-xs text-slate-400 leading-relaxed">
          Please login to view active safety course status, badge achievements, and completion credentials.
        </p>
        <button
          onClick={() => onNavigate('login')}
          className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2.5 px-6 rounded-lg text-xs transition-colors cursor-pointer"
        >
          Open Portal Login
        </button>
      </div>
    );
  }

  const completedModulesCount = user.progress.completedModules.length;
  const totalModulesCount = LEARNING_MODULES.length;
  const completionPercentage = totalModulesCount > 0 
    ? Math.round((completedModulesCount / totalModulesCount) * 100) 
    : 0;

  // Badge cabinet configuration
  const allBadges = [
    { id: "Disaster Scholar", name: "Disaster Scholar", desc: "Read and marked all learning modules complete.", icon: "📚", color: "from-blue-500/20 to-indigo-500/10 border-blue-500/30 text-blue-400" },
    { id: "Earthquake Rescuer", name: "Earthquake Rescuer", desc: "Completed the earthquake in classroom simulation.", icon: "🌋", color: "from-amber-500/20 to-orange-500/10 border-amber-500/30 text-amber-400" },
    { id: "Flood Specialist", name: "Flood Specialist", desc: "Completed the flood near school evacuation simulation.", icon: "🌊", color: "from-blue-500/20 to-sky-500/10 border-blue-500/30 text-blue-400" },
    { id: "Fire Warden", name: "Fire Warden", desc: "Successfully navigated the chemistry laboratory fire scenario.", icon: "🔥", color: "from-red-500/20 to-orange-500/10 border-red-500/30 text-red-400" },
    { id: "Audit Champion", name: "Audit Champion", desc: "Submitted a classroom hazard risk self-assessment.", icon: "📝", color: "from-emerald-500/20 to-teal-500/10 border-emerald-500/30 text-emerald-400" }
  ];

  // Certification requirements check
  const quizScores = Object.entries(user.progress.completedQuizzes);
  const passedQuizzesCount = quizScores.filter(([_, score]) => score >= 80).length;
  const totalQuizzesCount = QUIZZES.length;
  const isCertEligible = passedQuizzesCount > 0;

  // Calculate average exam grade percentage
  const avgExamScore = quizScores.length > 0 
    ? Math.round(quizScores.reduce((sum, [_, s]) => sum + s, 0) / quizScores.length) 
    : null;

  // Dynamic notifications compilation
  const dynamicNotifications: Array<{
    id: string;
    category: 'alerts' | 'actions' | 'milestones';
    type: 'info' | 'warning' | 'danger' | 'success';
    icon: React.ReactNode;
    title: string;
    message: string;
    timestamp: string;
    actionTab?: string;
    actionLabel?: string;
  }> = [];

  // 1. Live broadcast alerts
  const activeAlerts = alerts.filter(a => a.isActive);
  activeAlerts.forEach(alert => {
    dynamicNotifications.push({
      id: `alert-${alert.id}`,
      category: 'alerts',
      type: alert.severity === 'high' ? 'danger' : alert.severity === 'medium' ? 'warning' : 'info',
      icon: <ShieldAlert className={`w-4 h-4 ${alert.severity === 'high' ? 'text-red-500 animate-pulse' : 'text-amber-500'}`} />,
      title: `🚨 Broadcast Alert: ${alert.title}`,
      message: `${alert.message} (${alert.sender})`,
      timestamp: alert.timestamp || 'Active Now',
      actionTab: 'alerts',
      actionLabel: 'View Notice'
    });
  });

  // 2. Achievements / Badges Milestones
  user.progress.badgesEarned.forEach(badgeId => {
    const badge = allBadges.find(b => b.id === badgeId);
    if (badge) {
      dynamicNotifications.push({
        id: `badge-unlocked-${badgeId}`,
        category: 'milestones',
        type: 'success',
        icon: <Sparkles className="w-4 h-4 text-emerald-400 animate-bounce" />,
        title: `Badge Unlocked: ${badge.name}`,
        message: `Outstanding work! You earned the "${badge.name}" badge. ${badge.desc}`,
        timestamp: 'Verified'
      });
    }
  });

  // 3. Syllabus tasks & warnings
  if (user.progress.completedModules.length < totalModulesCount) {
    const incompleteModules = LEARNING_MODULES.filter(mod => !user.progress.completedModules.includes(mod.id));
    if (incompleteModules.length > 0) {
      const targetMod = incompleteModules[0];
      dynamicNotifications.push({
        id: `notif-read-mod-${targetMod.id}`,
        category: 'actions',
        type: 'info',
        icon: <BookOpen className="w-4 h-4 text-blue-400" />,
        title: 'Prerequisite Safety Study',
        message: `Advance your campus preparedness by reading and completing the "${targetMod.title}" module.`,
        timestamp: 'Due soon',
        actionTab: 'modules',
        actionLabel: 'Study Now'
      });
    }
  }

  // 4. Quizzes recommendations
  const attemptedQuizIds = Object.keys(user.progress.completedQuizzes);
  const unattemptedQuizzes = QUIZZES.filter(q => !attemptedQuizIds.includes(q.id));
  
  if (unattemptedQuizzes.length > 0) {
    const targetQuiz = unattemptedQuizzes[0];
    dynamicNotifications.push({
      id: `notif-quiz-attempt-${targetQuiz.id}`,
      category: 'actions',
      type: 'warning',
      icon: <FileText className="w-4 h-4 text-amber-500" />,
      title: 'Pending Competency Exam',
      message: `Test your emergency training! Take the comprehensive exam on "${targetQuiz.title}".`,
      timestamp: 'Action recommended',
      actionTab: 'quiz',
      actionLabel: 'Launch Test'
    });
  }

  // 5. Exam Retry Alert (if any score is below 80)
  Object.entries(user.progress.completedQuizzes).forEach(([quizId, score]) => {
    if (score < 80) {
      const quizName = QUIZZES.find(q => q.id === quizId)?.title || 'Safety Exam';
      dynamicNotifications.push({
        id: `retry-exam-${quizId}`,
        category: 'actions',
        type: 'danger',
        icon: <AlertTriangle className="w-4 h-4 text-red-400 animate-pulse" />,
        title: 'Review Needed: Low Test Score',
        message: `You scored ${score}% on the "${quizName}". High recommendation: re-take the exam and score 80%+ to unlock credentials.`,
        timestamp: 'Incomplete',
        actionTab: 'quiz',
        actionLabel: 'Retry Exam'
      });
    }
  });

  // 6. Risk Assessment check
  if (user.progress.riskAssessmentsCompleted === 0) {
    dynamicNotifications.push({
      id: 'audit-reminder',
      category: 'actions',
      type: 'warning',
      icon: <ListChecks className="w-4 h-4 text-yellow-500" />,
      title: 'Action Item: Classroom Safety Audit',
      message: 'Perform your first classroom hazard risk self-assessment to identify local structurally vulnerable elements.',
      timestamp: 'Overdue',
      actionTab: 'assessment',
      actionLabel: 'Audit Now'
    });
  } else {
    dynamicNotifications.push({
      id: 'audit-completed-milestone',
      category: 'milestones',
      type: 'success',
      icon: <CheckCircle2 className="w-4 h-4 text-emerald-400" />,
      title: 'Safety Audit Completed',
      message: `You submitted ${user.progress.riskAssessmentsCompleted} classroom risk assessment audits to departments.`,
      timestamp: 'Completed'
    });
  }

  // Fallback if list is empty
  if (dynamicNotifications.length === 0) {
    dynamicNotifications.push({
      id: 'notif-empty-bulletin',
      category: 'alerts',
      type: 'success',
      icon: <Check className="w-4 h-4 text-emerald-500" />,
      title: 'Syllabus Cleared',
      message: 'All drills, modules, and quizzes are fully completed! Your safety records are in pristine standing.',
      timestamp: 'Status green'
    });
  }

  // Filter list
  const filteredNotifications = dynamicNotifications.filter(notif => {
    if (notifFilter === 'all') return true;
    return notif.category === notifFilter;
  });

  return (
    <div className="space-y-6 animate-fade-in text-slate-800 dark:text-slate-100 transition-colors duration-300">
      
      {/* Profile Welcome Block */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
          <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
            <div className="w-16 h-16 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-black text-2xl shadow-xl shadow-amber-500/10 shrink-0 select-none">
              {user.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div className="space-y-1">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <h2 className="text-xl md:text-2xl font-black text-slate-100 tracking-tight">{user.name}</h2>
                <span className="px-2.5 py-0.5 bg-amber-500/10 border border-amber-500/20 rounded text-[9px] font-mono text-amber-500 font-extrabold uppercase tracking-widest">
                  Academic Portal
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">
                StudentID: <span className="font-mono text-slate-300">STU-{user.studentId || '2026-9481'}</span> • {user.gradeLevel || 'Secondary Student'}
              </p>
              <p className="text-[11px] text-slate-500 font-medium font-mono leading-none">
                {user.email} • {user.school}
              </p>
            </div>
          </div>
          
          <div className="flex gap-4 text-center shrink-0 w-full sm:w-auto">
            <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl flex-1 sm:flex-none">
              <div className="text-xl font-bold text-amber-500 font-mono">
                {completionPercentage}%
              </div>
              <div className="text-[9px] font-mono tracking-widest text-slate-500 uppercase font-semibold">
                Syllabus Progress
              </div>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl flex-1 sm:flex-none">
              <div className="text-xl font-bold text-emerald-500 font-mono">
                {user.progress.badgesEarned.length}
              </div>
              <div className="text-[9px] font-mono tracking-widest text-slate-500 uppercase font-semibold">
                Earned Badges
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Competency Exam Performance SVG Chart */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm transition-colors duration-300">
        <h3 className="text-xs font-mono text-slate-400 dark:text-slate-500 uppercase tracking-widest font-extrabold flex items-center gap-2 mb-4">
          <Award className="w-4 h-4 text-amber-500 animate-pulse" />
          Preparedness Competency Exam Analysis
        </h3>
        <div className="grid md:grid-cols-3 gap-6 items-center">
          {/* Custom SVG Bar Chart */}
          <div className="md:col-span-2">
            <svg viewBox="0 0 500 160" className="w-full overflow-visible">
              {/* Grid Lines */}
              <line x1="80" y1="20" x2="480" y2="20" stroke="#94a3b8" strokeOpacity="0.15" strokeDasharray="3 3" />
              <line x1="80" y1="55" x2="480" y2="55" stroke="#94a3b8" strokeOpacity="0.15" strokeDasharray="3 3" />
              <line x1="80" y1="90" x2="480" y2="90" stroke="#94a3b8" strokeOpacity="0.15" strokeDasharray="3 3" />
              <line x1="80" y1="125" x2="480" y2="125" stroke="#94a3b8" strokeOpacity="0.15" strokeDasharray="3 3" />
              <line x1="80" y1="140" x2="480" y2="140" stroke="#94a3b8" strokeOpacity="0.3" />

              {/* Y Axis Labels */}
              <text x="70" y="24" textAnchor="end" className="text-[9px] fill-slate-400 font-mono">100%</text>
              <text x="70" y="59" textAnchor="end" className="text-[9px] fill-slate-400 font-mono">75%</text>
              <text x="70" y="94" textAnchor="end" className="text-[9px] fill-slate-400 font-mono">50%</text>
              <text x="70" y="129" textAnchor="end" className="text-[9px] fill-slate-400 font-mono">25%</text>

              {/* Bar 1: Earthquake */}
              {(() => {
                const eqScore = user.progress.completedQuizzes["earthquake_quiz"] || 0;
                const eqHeight = (eqScore / 100) * 120;
                const eqY = 140 - eqHeight;
                return (
                  <g className="group">
                    <rect x="110" y="20" width="30" height="120" fill="currentColor" className="text-slate-100 dark:text-slate-800/20" rx="3" />
                    <rect x="110" y={eqY} width="30" height={eqHeight} fill="url(#amberGradient)" className="transition-all duration-1000 ease-out" rx="3" />
                    <text x="125" y={eqY > 20 ? eqY - 6 : 24} textAnchor="middle" className="text-[10px] font-mono font-bold fill-amber-500">{`${eqScore}%`}</text>
                    <text x="125" y="153" textAnchor="middle" className="text-[9px] font-mono font-semibold fill-slate-500 dark:fill-slate-400">Earthquake</text>
                  </g>
                );
              })()}

              {/* Bar 2: Flood */}
              {(() => {
                const flScore = user.progress.completedQuizzes["flood_quiz"] || 0;
                const flHeight = (flScore / 100) * 120;
                const flY = 140 - flHeight;
                return (
                  <g className="group">
                    <rect x="200" y="20" width="30" height="120" fill="currentColor" className="text-slate-100 dark:text-slate-800/20" rx="3" />
                    <rect x="200" y={flY} width="30" height={flHeight} fill="url(#blueGradient)" className="transition-all duration-1000 ease-out" rx="3" />
                    <text x="215" y={flY > 20 ? flY - 6 : 24} textAnchor="middle" className="text-[10px] font-mono font-bold fill-blue-500">{`${flScore}%`}</text>
                    <text x="215" y="153" textAnchor="middle" className="text-[9px] font-mono font-semibold fill-slate-500 dark:fill-slate-400">Flood</text>
                  </g>
                );
              })()}

              {/* Bar 3: Fire */}
              {(() => {
                const fiScore = user.progress.completedQuizzes["fire_quiz"] || 0;
                const fiHeight = (fiScore / 100) * 120;
                const fiY = 140 - fiHeight;
                return (
                  <g className="group">
                    <rect x="290" y="20" width="30" height="120" fill="currentColor" className="text-slate-100 dark:text-slate-800/20" rx="3" />
                    <rect x="290" y={fiY} width="30" height={fiHeight} fill="url(#redGradient)" className="transition-all duration-1000 ease-out" rx="3" />
                    <text x="305" y={fiY > 20 ? fiY - 6 : 24} textAnchor="middle" className="text-[10px] font-mono font-bold fill-red-500">{`${fiScore}%`}</text>
                    <text x="305" y="153" textAnchor="middle" className="text-[9px] font-mono font-semibold fill-slate-500 dark:fill-slate-400">Fire Lab</text>
                  </g>
                );
              })()}

              {/* Bar 4: Active Threat */}
              {(() => {
                const shScore = user.progress.completedQuizzes["shooter_quiz"] || 0;
                const shHeight = (shScore / 100) * 120;
                const shY = 140 - shHeight;
                return (
                  <g className="group">
                    <rect x="380" y="20" width="30" height="120" fill="currentColor" className="text-slate-100 dark:text-slate-800/20" rx="3" />
                    <rect x="380" y={shY} width="30" height={shHeight} fill="url(#roseGradient)" className="transition-all duration-1000 ease-out" rx="3" />
                    <text x="395" y={shY > 20 ? shY - 6 : 24} textAnchor="middle" className="text-[10px] font-mono font-bold fill-rose-500">{`${shScore}%`}</text>
                    <text x="395" y="153" textAnchor="middle" className="text-[9px] font-mono font-semibold fill-slate-500 dark:fill-slate-400">Lockdown</text>
                  </g>
                );
              })()}

              {/* Gradient Grids Definition */}
              <defs>
                <linearGradient id="amberGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity="1" />
                  <stop offset="100%" stopColor="#d97706" stopOpacity="0.8" />
                </linearGradient>
                <linearGradient id="blueGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="1" />
                  <stop offset="100%" stopColor="#1d4ed8" stopOpacity="0.8" />
                </linearGradient>
                <linearGradient id="redGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#ef4444" stopOpacity="1" />
                  <stop offset="100%" stopColor="#b91c1c" stopOpacity="0.8" />
                </linearGradient>
                <linearGradient id="roseGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f43f5e" stopOpacity="1" />
                  <stop offset="100%" stopColor="#be123c" stopOpacity="0.8" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          
          {/* Circular overall safety score percentage gauge */}
          <div className="flex flex-col items-center justify-center p-4 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-850 rounded-xl text-center">
            <h4 className="text-[10px] font-mono tracking-widest text-slate-400 dark:text-slate-500 uppercase font-black">Overall Score Index</h4>
            <div className="relative w-24 h-24 flex items-center justify-center mt-3">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="8" className="text-slate-200 dark:text-slate-800" fill="none" />
                <circle cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="8" className="text-blue-600 dark:text-blue-500 transition-all duration-1000" strokeDasharray="251.2" strokeDashoffset={251.2 - (251.2 * (avgExamScore || 0)) / 100} strokeLinecap="round" fill="none" />
              </svg>
              <div className="absolute flex flex-col items-center justify-center">
                <span className="text-xl font-black text-slate-800 dark:text-slate-100 font-mono">{avgExamScore !== null ? `${avgExamScore}%` : '0%'}</span>
                <span className="text-[8px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">Average</span>
              </div>
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-3 font-semibold leading-relaxed">
              Earn 80%+ on all quizzes to qualify for standard certification download.
            </p>
          </div>
        </div>
      </div>

      {/* Mini Bento Stats Indicators Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm transition-colors duration-300">
          <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 uppercase tracking-widest font-bold">Completed Modules</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-slate-800 dark:text-slate-100">{completedModulesCount}</span>
            <span className="text-xs font-semibold text-slate-400 dark:text-slate-500">/ {totalModulesCount}</span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
            <div className="bg-amber-500 h-full transition-all" style={{ width: `${completionPercentage}%` }} />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm transition-colors duration-300">
          <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 uppercase tracking-widest font-bold">Exam Performance</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-slate-800 dark:text-slate-100">
              {avgExamScore !== null ? `${avgExamScore}%` : 'N/A'}
            </span>
            <span className="text-xs font-semibold text-slate-400 dark:text-slate-500">Avg Grade</span>
          </div>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-2 font-mono truncate">
            {passedQuizzesCount} of {totalQuizzesCount} Passed
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm transition-colors duration-300">
          <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 uppercase tracking-widest font-bold">Disaster Simulations</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-slate-800 dark:text-slate-100">
              {user.progress.badgesEarned.filter(b => b.includes('Rescuer') || b.includes('Specialist') || b.includes('Warden')).length}
            </span>
            <span className="text-xs font-semibold text-slate-400 dark:text-slate-500">Arenas</span>
          </div>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-2 font-mono truncate">
            High-stakes drills survived
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm transition-colors duration-300">
          <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 uppercase tracking-widest font-bold">Safety Risk Audits</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-slate-800 dark:text-slate-100">{user.progress.riskAssessmentsCompleted}</span>
            <span className="text-xs font-semibold text-slate-400 dark:text-slate-500">Submitted</span>
          </div>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-2 font-mono truncate">
            Campus hazards documented
          </p>
        </div>
      </div>

      {/* Main Grid: Syllabus tracker + Notifications Board */}
      <div className="grid lg:grid-cols-3 gap-6">
        
        {/* Active Syllabus Progress Tracker */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 space-y-6 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-amber-500" />
                Safety Study Progress Tracker
              </h3>
              <p className="text-[11px] text-slate-400 mt-1">
                Read core materials, pass quizzes with 80%+, and secure certificates.
              </p>
            </div>
            <span className="text-xs font-mono text-amber-400 font-extrabold bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
              {completedModulesCount}/{totalModulesCount} Completed
            </span>
          </div>

          <div className="divide-y divide-slate-850 text-xs">
            {LEARNING_MODULES.map((mod) => {
              const isCompleted = user.progress.completedModules.includes(mod.id);
              const quizScore = user.progress.completedQuizzes[`${mod.id}_quiz`];

              return (
                <div key={mod.id} className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1 min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      {isCompleted ? (
                        <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                      ) : (
                        <Clock className="w-4 h-4 text-slate-500 shrink-0" />
                      )}
                      <h4 className="font-extrabold text-slate-200 truncate text-sm">{mod.title}</h4>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-normal pl-6">
                      Est. Time: {mod.timeToComplete} • Difficulty: <span className={`font-semibold ${
                        mod.difficulty === 'Beginner' ? 'text-emerald-400' : mod.difficulty === 'Intermediate' ? 'text-amber-500' : 'text-red-400'
                      }`}>{mod.difficulty}</span>
                    </p>
                  </div>
                  
                  {/* Performance Indicators */}
                  <div className="flex items-center justify-end gap-3 shrink-0 pl-6 sm:pl-0">
                    {quizScore !== undefined ? (
                      <span className={`px-2.5 py-1 rounded-md text-[10px] font-mono border font-extrabold flex items-center gap-1.5 ${
                        quizScore >= 80 
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                          : 'bg-red-500/10 text-red-400 border-red-500/20 animate-pulse'
                      }`}>
                        {quizScore >= 80 ? '✓' : '✗'} Exam: {quizScore}%
                      </span>
                    ) : (
                      <button 
                        onClick={() => onNavigate('quiz')}
                        className="text-[11px] text-amber-500 hover:text-amber-400 font-extrabold font-mono uppercase underline decoration-amber-500/30 transition-all hover:decoration-amber-400 cursor-pointer"
                      >
                        Start Exam
                      </button>
                    )}

                    {isCompleted ? (
                      <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/5 border border-emerald-500/15 px-2.5 py-1 rounded-md">
                        Done
                      </span>
                    ) : (
                      <button
                        onClick={() => onNavigate('modules')}
                        className="bg-slate-950 hover:bg-slate-850 text-slate-200 px-3 py-1 rounded-md text-[10px] font-bold border border-slate-800 transition-colors cursor-pointer flex items-center gap-1"
                      >
                        Study <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Notifications & Safety bulletins Command Board */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between shadow-xl space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-500 animate-pulse" />
                Safety Notifications
              </h3>
              {filteredNotifications.length > 0 && (
                <span className="text-[10px] bg-amber-500 text-slate-950 font-bold px-1.5 py-0.5 rounded-full">
                  {filteredNotifications.length}
                </span>
              )}
            </div>

            {/* Selector Filter chips */}
            <div className="flex flex-wrap gap-1 border-b border-slate-850 pb-3">
              <button
                onClick={() => setNotifFilter('all')}
                className={`text-[9px] font-bold px-2 py-1 rounded transition-colors cursor-pointer ${
                  notifFilter === 'all' 
                    ? 'bg-amber-500 text-slate-950' 
                    : 'bg-slate-950 text-slate-400 border border-slate-850 hover:border-slate-700'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setNotifFilter('alerts')}
                className={`text-[9px] font-bold px-2 py-1 rounded transition-colors cursor-pointer ${
                  notifFilter === 'alerts' 
                    ? 'bg-amber-500 text-slate-950' 
                    : 'bg-slate-950 text-slate-400 border border-slate-850 hover:border-slate-700'
                }`}
              >
                Alerts
              </button>
              <button
                onClick={() => setNotifFilter('actions')}
                className={`text-[9px] font-bold px-2 py-1 rounded transition-colors cursor-pointer ${
                  notifFilter === 'actions' 
                    ? 'bg-amber-500 text-slate-950' 
                    : 'bg-slate-950 text-slate-400 border border-slate-850 hover:border-slate-700'
                }`}
              >
                To-Do
              </button>
              <button
                onClick={() => setNotifFilter('milestones')}
                className={`text-[9px] font-bold px-2 py-1 rounded transition-colors cursor-pointer ${
                  notifFilter === 'milestones' 
                    ? 'bg-amber-500 text-slate-950' 
                    : 'bg-slate-950 text-slate-400 border border-slate-850 hover:border-slate-700'
                }`}
              >
                Milestones
              </button>
            </div>

            {/* Notifications Feed */}
            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {filteredNotifications.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-xs font-mono space-y-1">
                  <p>No reports found in this category.</p>
                </div>
              ) : (
                filteredNotifications.map((notif) => {
                  let alertThemeClass = 'border-slate-850 bg-slate-950/60';
                  if (notif.type === 'danger') {
                    alertThemeClass = 'bg-red-500/10 border-red-500/25 text-red-300';
                  } else if (notif.type === 'warning') {
                    alertThemeClass = 'bg-amber-500/10 border-amber-500/20 text-amber-300';
                  } else if (notif.type === 'success') {
                    alertThemeClass = 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300';
                  }

                  return (
                    <div 
                      key={notif.id} 
                      className={`p-3 rounded-xl border text-xs flex gap-2.5 items-start ${alertThemeClass}`}
                    >
                      <div className="shrink-0 mt-0.5">{notif.icon}</div>
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex justify-between items-center gap-2">
                          <h4 className="font-extrabold text-slate-200 truncate tracking-tight">{notif.title}</h4>
                          <span className="text-[9px] font-mono text-slate-500 shrink-0 font-bold uppercase">{notif.timestamp}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed font-medium">
                          {notif.message}
                        </p>
                        {notif.actionTab && (
                          <button
                            onClick={() => onNavigate(notif.actionTab!)}
                            className="mt-1.5 flex items-center gap-1 text-[10px] text-amber-500 font-extrabold font-mono uppercase tracking-wider hover:text-amber-400 cursor-pointer"
                          >
                            {notif.actionLabel || 'Execute'} <ArrowRight className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span className="flex items-center gap-1">
              <Info className="w-3.5 h-3.5 text-amber-500" />
              Real-time synchronization
            </span>
            <span className="font-bold text-emerald-400">● Live Active</span>
          </div>
        </div>

      </div>

      {/* Badges Cabinet & Certification Preview Box */}
      <div className="grid lg:grid-cols-3 gap-6">
        
        {/* Badge Cabinet */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 space-y-4 shadow-xl">
          <div className="border-b border-slate-850 pb-3">
            <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-500" />
              Safety Badges Locker
            </h3>
            <p className="text-[11px] text-slate-400 mt-1">
              Test safety behaviors in roleplay arenas to unlock credentials.
            </p>
          </div>

          <div className="grid gap-3">
            {allBadges.map((badge) => {
              const isEarned = user.progress.badgesEarned.includes(badge.id);

              return (
                <div 
                  key={badge.id} 
                  className={`p-3 rounded-xl border flex gap-3 items-start transition-all ${
                    isEarned 
                      ? `bg-slate-950 ${badge.color}` 
                      : 'bg-slate-950/40 border-slate-900 opacity-40 hover:opacity-55'
                  }`}
                >
                  <span className="text-2xl shrink-0 mt-0.5">{badge.icon}</span>
                  <div className="space-y-0.5">
                    <h4 className="text-xs font-extrabold text-slate-100">
                      {badge.name}
                    </h4>
                    <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                      {badge.desc}
                    </p>
                    {isEarned ? (
                      <span className="inline-flex items-center gap-1 text-[8px] font-mono text-emerald-400 uppercase font-bold mt-1 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded">
                        ✓ Authenticated
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[8px] font-mono text-slate-500 uppercase mt-1 bg-slate-900 px-1.5 py-0.5 rounded">
                        🔒 Not Earned
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Certificate Display Center */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 space-y-6 shadow-xl flex flex-col justify-between">
          <div className="border-b border-slate-850 pb-4">
            <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider flex items-center gap-2">
              <FileBadge className="w-5 h-5 text-amber-500" />
              Official Safety Certification Center
            </h3>
            <p className="text-[11px] text-slate-400 mt-1">
              Acquire first responder clearance credentials valid across campuses.
            </p>
          </div>

          {/* Certificate State Panel */}
          <div className="p-5 rounded-2xl border bg-slate-950 border-slate-850 relative overflow-hidden flex-1 flex flex-col justify-center min-h-[16rem]">
            <div className="absolute top-0 right-0 -mt-10 -mr-10 w-44 h-44 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
            
            {isCertEligible ? (
              <div className="space-y-4 text-center max-w-md mx-auto">
                <div className="inline-flex items-center justify-center p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-emerald-400 mb-1">
                  <FileBadge className="w-8 h-8 text-emerald-400 animate-pulse" />
                </div>
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded font-black tracking-widest">
                    Approved Clearance
                  </span>
                  <h4 className="text-md font-black text-slate-100 tracking-tight">
                    Campus Safety Certification is Unlocked!
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed font-medium">
                    Congratulations, <span className="text-amber-500 font-extrabold">{user.name}</span>! You successfully qualified by passing academic disaster competency exams. Your printable student file is generated.
                  </p>
                </div>
                
                <div className="pt-2">
                  <button
                    onClick={() => onNavigate('certificate')}
                    className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2.5 px-6 rounded-lg text-xs transition-all cursor-pointer shadow-lg shadow-amber-500/15"
                  >
                    Launch Certificate Printout <ExternalLink className="w-4 h-4 text-slate-950" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4 text-center max-w-sm mx-auto">
                <div className="inline-flex items-center justify-center p-3.5 bg-slate-900 border border-slate-850 rounded-full text-slate-500 mb-1">
                  <Lock className="w-8 h-8 text-slate-500" />
                </div>
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase bg-slate-900 border border-slate-850 px-2 py-0.5 rounded text-slate-500 font-bold tracking-widest">
                    Prerequisites Pending
                  </span>
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">
                    Safety Certification Locked
                  </h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
                    To authorize your first responder student clearance, you must achieve a passing grade of 80% or greater on at least one safety competency exam.
                  </p>
                </div>
                
                <div className="pt-2">
                  <button
                    onClick={() => onNavigate('quiz')}
                    className="bg-slate-900 hover:bg-slate-850 border border-slate-800 text-amber-500 hover:text-amber-400 font-bold py-2 px-4 rounded-lg text-[10px] transition-colors cursor-pointer"
                  >
                    Go Attempt Exam
                  </button>
                </div>
              </div>
            )}
          </div>

          <p className="text-[10px] text-slate-500 text-center font-mono">
            Issued by Lincoln University emergency operations branch under compliance code SEC-2026.
          </p>
        </div>

      </div>

    </div>
  );
}

