import React, { useState, useEffect } from 'react';
import { QUIZZES } from '../data/safetyData';
import { Quiz, QuizQuestion, UserProfile } from '../types';
import { 
  Award, HelpCircle, Check, X, RefreshCw, 
  ChevronRight, ArrowRight, BookOpen, AlertCircle, 
  Timer, Clock, ArrowLeft, ShieldCheck, ThumbsUp
} from 'lucide-react';

interface QuizProps {
  user: UserProfile | null;
  onQuizSubmit: (quizId: string, scorePercentage: number) => void;
  onNavigate: (tab: string) => void;
}

export default function QuizComponent({ user, onQuizSubmit, onNavigate }: QuizProps) {
  const [quizzes] = useState<Quiz[]>(() => {
    const saved = localStorage.getItem('responseed_quizzes');
    return saved ? JSON.parse(saved) : QUIZZES;
  });
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [correctAnswersCount, setCorrectAnswersCount] = useState<number>(0);
  const [quizCompleted, setQuizCompleted] = useState<boolean>(false);
  
  // Timer and review states
  const [timeLeft, setTimeLeft] = useState<number>(20);
  const [userAnswers, setUserAnswers] = useState<Record<string, number | null>>({});
  const [isReviewMode, setIsReviewMode] = useState<boolean>(false);

  // Constants
  const QUESTION_TIME_LIMIT = 20; // 20 seconds per question

  const startQuiz = (quiz: Quiz) => {
    setSelectedQuiz(quiz);
    setCurrentQuestionIdx(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setCorrectAnswersCount(0);
    setQuizCompleted(false);
    setTimeLeft(QUESTION_TIME_LIMIT);
    setUserAnswers({});
    setIsReviewMode(false);
  };

  // Timer Effect
  useEffect(() => {
    if (!selectedQuiz || isAnswered || quizCompleted) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          // Time is up! Register answer as incorrect (null selected)
          setIsAnswered(true);
          setSelectedOption(null);
          
          const currentQuestion = selectedQuiz.questions[currentQuestionIdx];
          setUserAnswers(prevAnswers => ({
            ...prevAnswers,
            [currentQuestion.id]: null
          }));
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [selectedQuiz, currentQuestionIdx, isAnswered, quizCompleted]);

  const handleOptionClick = (optIdx: number) => {
    if (isAnswered) return;
    setSelectedOption(optIdx);
  };

  const handleVerifyAnswer = () => {
    if (selectedOption === null || isAnswered || !selectedQuiz) return;
    
    const currentQuestion = selectedQuiz.questions[currentQuestionIdx];
    const isCorrect = selectedOption === currentQuestion.correctAnswer;
    
    if (isCorrect) {
      setCorrectAnswersCount(prev => prev + 1);
    }
    
    setIsAnswered(true);
    setUserAnswers(prev => ({
      ...prev,
      [currentQuestion.id]: selectedOption
    }));
  };

  const handleNextQuestion = () => {
    if (!selectedQuiz) return;

    if (currentQuestionIdx + 1 < selectedQuiz.questions.length) {
      setCurrentQuestionIdx(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
      setTimeLeft(QUESTION_TIME_LIMIT);
    } else {
      // Completed! Calculate percentage
      const finalPercentage = Math.round((correctAnswersCount / selectedQuiz.questions.length) * 100);
      setQuizCompleted(true);
      // Trigger parent handler to persist progress
      onQuizSubmit(selectedQuiz.id, finalPercentage);
    }
  };

  const currentQuestion: QuizQuestion | null = selectedQuiz ? selectedQuiz.questions[currentQuestionIdx] : null;

  // Visual helper computations
  const quizProgressPercent = selectedQuiz
    ? ((currentQuestionIdx + (isAnswered ? 1 : 0)) / selectedQuiz.questions.length) * 100
    : 0;

  const timerPercent = (timeLeft / QUESTION_TIME_LIMIT) * 100;
  const getTimerColorClass = () => {
    if (timeLeft > 10) return 'bg-emerald-500';
    if (timeLeft > 5) return 'bg-amber-500';
    return 'bg-red-500 animate-pulse';
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-56 h-56 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-2xl space-y-3 z-10 relative">
          <span className="text-[10px] font-mono font-extrabold tracking-wider bg-amber-500/10 text-amber-500 px-2.5 py-1 rounded border border-amber-500/20 uppercase">
            Official Certification Center
          </span>
          <h1 className="text-2xl md:text-3xl font-black text-slate-100 tracking-tight flex items-center gap-2">
            <Award className="w-7 h-7 text-amber-500" />
            Safety Competency <span className="text-amber-500">Exams</span>
          </h1>
          <p className="text-xs text-slate-400 leading-relaxed">
            Validate your situational readiness with certified multiple-choice exams. Beat the ticking countdown, score 80% or greater, and earn student badges verifying your campus survival records.
          </p>
        </div>
      </div>

      {!selectedQuiz ? (
        /* Quiz list */
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizzes.map((quiz) => {
            const historyScore = user?.progress.completedQuizzes[quiz.id];
            const isPassed = historyScore !== undefined && historyScore >= 80;

            return (
              <div key={quiz.id} className="bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all rounded-xl p-5 flex flex-col justify-between space-y-5 shadow-lg">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-mono uppercase bg-slate-950 border border-slate-850 px-2.5 py-1 rounded text-slate-400">
                      ⏱️ {quiz.questions.length * QUESTION_TIME_LIMIT}s Total
                    </span>
                    {historyScore !== undefined && (
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                        isPassed 
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                          : 'bg-red-500/10 text-red-400 border-red-500/20'
                      }`}>
                        Best: {historyScore}% {isPassed ? 'Passed' : 'Failed'}
                      </span>
                    )}
                  </div>
                  <h3 className="font-extrabold text-slate-100 text-sm tracking-tight leading-snug">{quiz.title}</h3>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Evaluates safety behaviors during hazardous situations. Features strict timers, comprehensive rationales, and live progress calculations.
                  </p>
                </div>

                <button
                  onClick={() => startQuiz(quiz)}
                  className="w-full bg-slate-950 hover:bg-slate-850 border border-slate-800 text-amber-500 hover:text-amber-400 font-bold py-2.5 rounded-lg text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  Start Exam <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      ) : (
        /* Active Quiz Arena / Result Page */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl mx-auto overflow-hidden shadow-2xl">
          
          {/* Progress Header */}
          <div className="bg-slate-950 px-6 py-4 border-b border-slate-850 flex items-center justify-between text-xs">
            <button
              onClick={() => setSelectedQuiz(null)}
              className="text-slate-400 hover:text-slate-200 transition-colors flex items-center gap-1 font-bold cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-amber-500" /> Quit Exam
            </button>
            <span className="font-mono text-slate-500 uppercase">
              {quizCompleted ? 'Exam Completed' : `Question ${currentQuestionIdx + 1} of ${selectedQuiz.questions.length}`}
            </span>
          </div>

          {/* Core Overall Quiz Progress Bar */}
          {!quizCompleted && (
            <div className="w-full h-1.5 bg-slate-950">
              <div 
                className="h-full bg-gradient-to-r from-amber-600 to-amber-400 transition-all duration-300" 
                style={{ width: `${quizProgressPercent}%` }}
              />
            </div>
          )}

          <div className="p-6 md:p-8 space-y-6">
            {quizCompleted ? (
              /* Score report screen */
              <div className="space-y-6">
                
                {/* Visual Grade Badge */}
                <div className="text-center p-4 space-y-4">
                  <Award className="w-16 h-16 text-amber-500 mx-auto animate-bounce" />
                  <div className="space-y-2">
                    <h2 className="text-xl font-black text-slate-100 uppercase tracking-tight">Exam Evaluation Finished</h2>
                    <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                      Your answers have been checked and synchronized with your personal study logs. Below is your performance dashboard.
                    </p>
                  </div>
                </div>

                {/* Score gauge */}
                <div className="p-5 bg-slate-950 border border-slate-850 rounded-xl max-w-sm mx-auto space-y-3 text-center">
                  <div className="text-4xl font-black text-amber-500 tracking-tight">
                    {Math.round((correctAnswersCount / selectedQuiz.questions.length) * 100)}%
                  </div>
                  <div className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-semibold">
                    Calculated Score ({correctAnswersCount} / {selectedQuiz.questions.length} Correct)
                  </div>
                  <div className="pt-2 border-t border-slate-900">
                    {Math.round((correctAnswersCount / selectedQuiz.questions.length) * 100) >= 80 ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-xs font-mono text-emerald-400 font-bold">
                        <ShieldCheck className="w-4 h-4 text-emerald-400" /> EXAM PASSED (CERTIFICATION UNLOCKED)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-500/10 border border-red-500/20 rounded-full text-xs font-mono text-red-400 font-bold">
                        <AlertCircle className="w-4 h-4 text-red-400" /> EXAM FAILED (REQUIRES 80% TO PASS)
                      </span>
                    )}
                  </div>
                </div>

                {/* Review Mode Toggle Section */}
                <div className="border-t border-slate-800 pt-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                      <BookOpen className="w-4 h-4 text-amber-500" /> Report Card Review
                    </h3>
                    <button
                      onClick={() => setIsReviewMode(!isReviewMode)}
                      className="text-[11px] font-bold text-amber-500 hover:text-amber-400 transition-colors border border-amber-500/20 px-2.5 py-1 rounded bg-amber-500/5 cursor-pointer"
                    >
                      {isReviewMode ? 'Collapse Review' : 'Expand Detailed Review'}
                    </button>
                  </div>

                  {isReviewMode && (
                    <div className="space-y-4 animate-scale-in max-h-96 overflow-y-auto pr-1">
                      {selectedQuiz.questions.map((q, idx) => {
                        const answerOption = userAnswers[q.id];
                        const isCorrect = answerOption === q.correctAnswer;
                        const isTimeout = answerOption === null;

                        return (
                          <div key={q.id} className="bg-slate-950 border border-slate-850 rounded-xl p-4 space-y-3">
                            <div className="flex items-start justify-between gap-2 border-b border-slate-900 pb-2">
                              <span className="text-xs font-extrabold text-slate-200">
                                Question {idx + 1}: {q.text}
                              </span>
                              {isTimeout ? (
                                <span className="shrink-0 text-[9px] font-mono uppercase bg-red-500/15 border border-red-500/30 text-red-400 px-2 py-0.5 rounded-full font-bold">
                                  ⏱️ Timeout
                                </span>
                              ) : isCorrect ? (
                                <span className="shrink-0 text-[9px] font-mono uppercase bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 px-2 py-0.5 rounded-full font-bold">
                                  ✓ Correct
                                </span>
                              ) : (
                                <span className="shrink-0 text-[9px] font-mono uppercase bg-red-500/15 border border-red-500/30 text-red-400 px-2 py-0.5 rounded-full font-bold">
                                  ✗ Incorrect
                                </span>
                              )}
                            </div>

                            {/* Options Review */}
                            <div className="grid gap-1.5 text-[11px]">
                              {q.options.map((opt, oIdx) => {
                                const selected = answerOption === oIdx;
                                const isCorrectOpt = oIdx === q.correctAnswer;
                                
                                let styleClass = "text-slate-500 border border-slate-900 px-2.5 py-1.5 rounded";
                                if (isCorrectOpt) {
                                  styleClass = "bg-emerald-500/10 border-emerald-500/25 text-emerald-400 font-semibold px-2.5 py-1.5 rounded";
                                } else if (selected) {
                                  styleClass = "bg-red-500/10 border-red-500/25 text-red-400 px-2.5 py-1.5 rounded";
                                }

                                return (
                                  <div key={oIdx} className={styleClass}>
                                    {opt} {selected && " (Your Choice)"} {isCorrectOpt && " (Correct)"}
                                  </div>
                                );
                              })}
                            </div>

                            {/* Explanation */}
                            <div className="p-3 bg-slate-900/60 rounded text-[10px] text-slate-400 leading-relaxed border-l-2 border-amber-500">
                              <span className="font-extrabold text-slate-300 block uppercase tracking-wider mb-0.5 text-[9px]">Explanation Rationale</span>
                              {q.explanation}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Footer buttons */}
                <div className="pt-4 border-t border-slate-800 flex flex-wrap justify-center gap-3">
                  <button
                    onClick={() => setSelectedQuiz(null)}
                    className="bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 px-5 py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer"
                  >
                    Go Back to Exam List
                  </button>
                  <button
                    onClick={() => startQuiz(selectedQuiz)}
                    className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 px-5 py-2.5 rounded-lg text-xs transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-amber-500" /> Re-take Exam
                  </button>
                  {Math.round((correctAnswersCount / selectedQuiz.questions.length) * 100) >= 80 && (
                    <button
                      onClick={() => onNavigate('certificate')}
                      className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-5 py-2.5 rounded-lg text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-amber-500/10"
                    >
                      🎓 View & Download Certificate
                    </button>
                  )}
                </div>
              </div>
            ) : currentQuestion ? (
              /* Quiz active Question screen */
              <div className="space-y-6">
                
                {/* Countdown Timer Visuals */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400 flex items-center gap-1">
                      <Clock className="w-4 h-4 text-amber-500" />
                      Timer Countdown:
                    </span>
                    <span className={`font-mono font-black ${
                      timeLeft > 10 ? 'text-emerald-400' : timeLeft > 5 ? 'text-amber-500 animate-pulse' : 'text-red-500 animate-bounce font-bold'
                    }`}>
                      {timeLeft} seconds
                    </span>
                  </div>
                  {/* Shrinking progress bar */}
                  <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-850">
                    <div 
                      className={`h-full transition-all duration-1000 ${getTimerColorClass()}`}
                      style={{ width: `${timerPercent}%` }}
                    />
                  </div>
                </div>

                {/* Text prompt */}
                <div className="p-5 bg-slate-950 border border-slate-850 rounded-xl flex gap-3 items-start shadow-inner">
                  <HelpCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                  <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-semibold">
                    {currentQuestion.text}
                  </p>
                </div>

                {/* Options list */}
                <div className="space-y-2.5">
                  {currentQuestion.options.map((opt, oIdx) => {
                    const isSelected = selectedOption === oIdx;
                    
                    let bgBorderClass = 'bg-slate-950 border-slate-850 hover:border-slate-750 text-slate-300 hover:text-slate-100';
                    if (isSelected) {
                      bgBorderClass = 'bg-amber-500/5 border-amber-500 text-amber-500';
                    }

                    if (isAnswered) {
                      const isCorrect = oIdx === currentQuestion.correctAnswer;
                      if (isCorrect) {
                        bgBorderClass = 'bg-emerald-500/10 border-emerald-500 text-emerald-400 font-semibold';
                      } else if (isSelected) {
                        bgBorderClass = 'bg-red-500/10 border-red-500 text-red-400';
                      } else {
                        bgBorderClass = 'bg-slate-950/40 border-slate-900 text-slate-600';
                      }
                    }

                    return (
                      <button
                        key={oIdx}
                        disabled={isAnswered}
                        onClick={() => handleOptionClick(oIdx)}
                        className={`w-full text-left p-4 border rounded-xl transition-all focus:outline-none flex justify-between items-center text-xs font-semibold leading-normal ${bgBorderClass} ${
                          !isAnswered ? 'cursor-pointer' : 'cursor-default'
                        }`}
                      >
                        <span>{opt}</span>
                        {isAnswered && oIdx === currentQuestion.correctAnswer && (
                          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                        )}
                        {isAnswered && isSelected && oIdx !== currentQuestion.correctAnswer && (
                          <X className="w-4 h-4 text-red-400 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Explanations & Next panel */}
                {isAnswered ? (
                  <div className="space-y-4 animate-scale-in">
                    
                    {/* Time-out Indicator if no option was chosen */}
                    {selectedOption === null && (
                      <div className="flex items-center gap-2 text-xs font-bold text-red-400 bg-red-500/10 border border-red-500/20 p-3 rounded-xl justify-center uppercase tracking-wider font-mono">
                        <Timer className="w-4 h-4 animate-bounce" /> Assessment Time Limit Expired!
                      </div>
                    )}

                    <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl space-y-2 text-[11px] leading-relaxed shadow-inner">
                      <h4 className="font-extrabold text-slate-200 uppercase tracking-widest text-[10px] flex items-center gap-1.5 text-amber-500">
                        <AlertCircle className="w-4 h-4 text-amber-500" /> Lesson Rationale & Safety Science
                      </h4>
                      <p className="text-slate-400 leading-normal">{currentQuestion.explanation}</p>
                    </div>

                    <button
                      onClick={handleNextQuestion}
                      className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2.5 rounded-lg text-xs transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-lg shadow-amber-500/10"
                    >
                      {currentQuestionIdx + 1 === selectedQuiz.questions.length ? 'Submit Final Exam' : 'Next Question'}
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    disabled={selectedOption === null}
                    onClick={handleVerifyAnswer}
                    className={`w-full py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      selectedOption !== null 
                        ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 cursor-pointer shadow-lg shadow-amber-500/10' 
                        : 'bg-slate-800 text-slate-600 cursor-not-allowed border border-slate-850'
                    }`}
                  >
                    Verify Assessment Answer
                  </button>
                )}

              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
}
