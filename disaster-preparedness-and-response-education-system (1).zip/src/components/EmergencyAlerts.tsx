import React, { useState, useEffect, useRef } from 'react';
import { EmergencyAlert } from '../types';
import { 
  BellRing, Megaphone, Volume2, VolumeX, ShieldAlert, 
  HelpCircle, AlertTriangle, Play, CheckCircle, Info,
  Phone, Copy, Check, Search, Flame, Waves, Compass, 
  Skull, Shield, HeartPulse, Plus, X, ExternalLink, 
  ArrowRight, LifeBuoy, FileText, CheckSquare, Square,
  Clock, MapPin, Send, RefreshCw, Activity, ChevronRight, PhoneCall, Volume1, Wind
} from 'lucide-react';

interface EmergencyAlertsProps {
  alerts: EmergencyAlert[];
}

interface ContactItem {
  id: string;
  name: string;
  number: string;
  description: string;
  category: 'primary' | 'medical' | 'hazmat' | 'support' | 'facilities';
  notes: string;
  dispatcherGreeting: string;
  sampleResponses: string[];
  dispatcherResponses: { [key: string]: string };
}

export default function EmergencyAlerts({ alerts }: EmergencyAlertsProps) {
  // Navigation & General State
  const [activeSubTab, setActiveSubTab] = useState<'warnings' | 'contacts' | 'playbooks'>('warnings');
  const [localAlerts, setLocalAlerts] = useState<EmergencyAlert[]>(alerts);
  const [isLoadingAlerts, setIsLoadingAlerts] = useState<boolean>(false);
  
  // Warning Alerts Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Broadcast Form State
  const [showBroadcastForm, setShowBroadcastForm] = useState<boolean>(false);
  const [formTitle, setFormTitle] = useState<string>('');
  const [formMessage, setFormMessage] = useState<string>('');
  const [formSeverity, setFormSeverity] = useState<'low' | 'medium' | 'high'>('medium');
  const [formType, setFormType] = useState<'drill' | 'real_emergency' | 'advisory'>('drill');
  const [formSender, setFormSender] = useState<string>('Safety Desk');
  const [broadcastSuccess, setBroadcastSuccess] = useState<boolean>(false);
  const [broadcastError, setBroadcastError] = useState<string>('');

  // Siren/Alarm Synthesizer State
  const [sirenActive, setSirenActive] = useState<boolean>(false);
  const [sirenType, setSirenType] = useState<'ambulance' | 'fire' | 'tornado'>('ambulance');
  const [sirenVolume, setSirenVolume] = useState<number>(0.05); // low volume safe defaults
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Contacts State
  const [contactSearch, setContactSearch] = useState<string>('');
  const [selectedContactCategory, setSelectedContactCategory] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  // Call Simulator State
  const [activeCall, setActiveCall] = useState<ContactItem | null>(null);
  const [callStatus, setCallStatus] = useState<'ringing' | 'connected' | 'ended'>('ringing');
  const [callTimer, setCallTimer] = useState<number>(0);
  const [callLog, setCallLog] = useState<{ sender: 'dispatcher' | 'user'; text: string }[]>([]);
  const [hasAnswered, setHasAnswered] = useState<boolean>(false);

  // Playbooks State
  const [selectedPlaybookId, setSelectedPlaybookId] = useState<string>('earthquake');
  const [completedSteps, setCompletedSteps] = useState<{ [key: string]: boolean }>({});

  // Sync alerts when props change
  useEffect(() => {
    setLocalAlerts(alerts);
  }, [alerts]);

  // Fetch alerts from the Express server API
  const fetchLocalAlerts = async () => {
    setIsLoadingAlerts(true);
    try {
      const res = await fetch('/api/alerts');
      const data = await res.json();
      if (data.success) {
        setLocalAlerts(data.alerts);
      }
    } catch (err) {
      console.error("Failed to fetch fresh alerts:", err);
    } finally {
      setIsLoadingAlerts(false);
    }
  };

  // Standard siren synthesizer
  const handleToggleSiren = () => {
    if (sirenActive) {
      cleanupSiren();
    } else {
      startSiren();
    }
  };

  const cleanupSiren = () => {
    if (oscillatorRef.current) {
      try {
        oscillatorRef.current.stop();
      } catch (e) {}
      oscillatorRef.current.disconnect();
      oscillatorRef.current = null;
    }
    if (gainNodeRef.current) {
      gainNodeRef.current.disconnect();
      gainNodeRef.current = null;
    }
    if (audioCtxRef.current) {
      try {
        audioCtxRef.current.close();
      } catch (e) {}
      audioCtxRef.current = null;
    }
    setSirenActive(false);
  };

  const startSiren = () => {
    try {
      cleanupSiren();

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) {
        alert("Web Audio API is not supported in this browser.");
        return;
      }
      
      const ctx = new AudioCtx();
      audioCtxRef.current = ctx;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      // Configure frequencies based on Siren Type
      if (sirenType === 'ambulance') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        let time = ctx.currentTime;
        // Modulate up and down ambulance style
        for (let i = 0; i < 40; i++) {
          osc.frequency.linearRampToValueAtTime(750, time + 0.4);
          osc.frequency.linearRampToValueAtTime(440, time + 0.8);
          time += 0.8;
        }
      } else if (sirenType === 'fire') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(300, ctx.currentTime);
        let time = ctx.currentTime;
        // Sweeps upward then quick drop fire-engine style
        for (let i = 0; i < 40; i++) {
          osc.frequency.exponentialRampToValueAtTime(900, time + 0.9);
          osc.frequency.setValueAtTime(300, time + 1.0);
          time += 1.0;
        }
      } else {
        // Tornado / Air Raid pulsed signal
        osc.type = 'sine';
        osc.frequency.setValueAtTime(520, ctx.currentTime);
        let time = ctx.currentTime;
        // Pulsating amplitude
        for (let i = 0; i < 40; i++) {
          gain.gain.setValueAtTime(sirenVolume, time);
          gain.gain.linearRampToValueAtTime(0.001, time + 0.5);
          gain.gain.linearRampToValueAtTime(sirenVolume, time + 1.0);
          time += 1.0;
        }
      }

      // Establish safe baseline volume using user-controlled slider
      gain.gain.setValueAtTime(sirenVolume, ctx.currentTime);
      
      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      
      oscillatorRef.current = osc;
      gainNodeRef.current = gain;
      setSirenActive(true);
    } catch (err) {
      console.error("Failed to synthesize sirens:", err);
    }
  };

  // Adjust volume dynamically
  useEffect(() => {
    if (gainNodeRef.current && audioCtxRef.current) {
      gainNodeRef.current.gain.setValueAtTime(sirenVolume, audioCtxRef.current.currentTime);
    }
  }, [sirenVolume]);

  // Restart siren on type change if already active
  useEffect(() => {
    if (sirenActive) {
      startSiren();
    }
  }, [sirenType]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cleanupSiren();
    };
  }, []);

  // Post new Simulated Broadcast Emergency Alert to API
  const handleBroadcastSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBroadcastError('');
    setBroadcastSuccess(false);

    if (!formTitle.trim() || !formMessage.trim()) {
      setBroadcastError('Please provide both a brief warning title and message.');
      return;
    }

    try {
      const response = await fetch('/api/alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formTitle,
          message: formMessage,
          severity: formSeverity,
          type: formType,
          sender: formSender || 'Emergency Command Desk'
        })
      });
      
      const data = await response.json();
      if (data.success) {
        setBroadcastSuccess(true);
        setFormTitle('');
        setFormMessage('');
        // Instantly reload
        await fetchLocalAlerts();
        // Collapse form after brief delay
        setTimeout(() => {
          setShowBroadcastForm(false);
          setBroadcastSuccess(false);
        }, 2500);
      } else {
        setBroadcastError(data.error || 'Failed to dispatch alert to server.');
      }
    } catch (err) {
      setBroadcastError('Connection error: could not transmit broadcast.');
      console.error(err);
    }
  };

  const handleDeactivateAlert = async (id: string) => {
    try {
      const response = await fetch(`/api/alerts/${id}/deactivate`, {
        method: 'POST'
      });
      const data = await response.json();
      if (data.success) {
        fetchLocalAlerts();
      }
    } catch (err) {
      console.error("Failed to deactivate alert:", err);
    }
  };

  // Copy Contact to Clipboard
  const handleCopyNumber = (id: string, num: string) => {
    navigator.clipboard.writeText(num);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Emergency Contacts Predefined List with Interactive Call simulation metadata
  const contacts: ContactItem[] = [
    {
      id: 'campus-police',
      name: 'Campus Police & Safety Command',
      number: '+1 (555) 911-1000',
      description: 'Primary campus defense and tactical safety dispatch. Contact for active threats, severe fires, or urgent trespassing.',
      category: 'primary',
      notes: 'Available 24/7. Standard tactical dispatch response time: <2 minutes.',
      dispatcherGreeting: 'Lincoln University Safety Command. Officer Vance speaking. State the nature of your emergency and your building name immediately.',
      sampleResponses: [
        'Active gas or electrical fire in the Library basement.',
        'A medical emergency—someone has fainted and is unresponsive.',
        'I need to report an suspicious individual trying to force door locks.'
      ],
      dispatcherResponses: {
        'Active gas or electrical fire in the Library basement.': 'Understood. We are activating campus-wide alarm sirens and dispatching Fire Response Teams to the Library. Evacuate immediately! Do not pull light switches.',
        'A medical emergency—someone has fainted and is unresponsive.': 'Copy that. Paramedics are being routed to your location. Keep the airway clear. Is the victim breathing? Place them on their side if safe.',
        'I need to report an suspicious individual trying to force door locks.': 'Safety unit is en route. Do not engage. Stay in a well-lit room or locking office. Keep your eyes on their direction.'
      }
    },
    {
      id: 'local-fire',
      name: 'County Fire & Evacuation Rescue',
      number: '+1 (555) 911-2000',
      description: 'Local fire station response. Call for structural alarms, heavy hazardous smoke, chemical combustions, or stuck elevator rescues.',
      category: 'facilities',
      notes: 'Direct municipal line. Integrated with automatic safety sensors.',
      dispatcherGreeting: 'Emergency Fire & Rescue Dispatch. What is burning and are there occupants trapped inside?',
      sampleResponses: [
        'There is thick chemical smoke pouring from Science Hall Lab 40B.',
        'An elevator is stuck between floors in the Dormitory Tower.',
        'A vehicle is leaking gasoline near the campus entrance yard.'
      ],
      dispatcherResponses: {
        'There is thick chemical smoke pouring from Science Hall Lab 40B.': 'Alert received. Hazardous Material Fire trucks are dispatching. Pull the fire alarm to start immediate building evacuation. Stay low to the ground and get out.',
        'An elevator is stuck between floors in the Dormitory Tower.': 'Copy. Facilities rescue crew is rolling. Instruct passengers inside to remain calm and stay away from the doors.',
        'A vehicle is leaking gasoline near the campus entrance yard.': 'Understood. Sending a chemical unit. Keep all bystanders back, and enforce a strict no-smoking barrier within 100 feet.'
      }
    },
    {
      id: 'medical-paramedics',
      name: 'Emergency Medical Services & Paramedics',
      number: '+1 (555) 911-3000',
      description: 'Ambulance dispatch. Call for severe physical trauma, cardiac arrests, toxic chemical inhalation, or sudden loss of consciousness.',
      category: 'medical',
      notes: 'Main clinic response vehicle stationed on-site behind Student Union.',
      dispatcherGreeting: 'EMS Medical Dispatch. Tell me exactly what happened, and if the patient is currently conscious and breathing.',
      sampleResponses: [
        'A student slipped on stairs and has a deep head laceration.',
        'Someone is having an extreme asthma attack and has lost consciousness.',
        'We have a laboratory chemical splash on a student\'s arms and face.'
      ],
      dispatcherResponses: {
        'A student slipped on stairs and has a deep head laceration.': 'Ambulance is dispatching. Put firm, continuous pressure on the wound using clean cloth. Do not move their neck if they fell.',
        'Someone is having an extreme asthma attack and has lost consciousness.': 'Paramedics are en route. Lay them flat on their back, tilt their head slightly back to clear the airway. Monitor breathing.',
        'We have a laboratory chemical splash on a student\'s arms and face.': 'Hazard medical unit is coming. Lead them to the safety eyewash/shower immediately! Flush with continuous clean water for at least 15 minutes.'
      }
    },
    {
      id: 'hazmat-spill',
      name: 'Chemical Hazard & Toxic Spill Response',
      number: '+1 (555) 911-4000',
      description: 'Specialized chemical response team. Call for radioactive containment, toxic gas plumes, laboratory chemical accidents, or severe spills.',
      category: 'hazmat',
      notes: 'Adheres to OSHA level-A containment and mitigation standards.',
      dispatcherGreeting: 'Hazmat Incident Control. Identify the compound name if known, and indicate if there are active vapor clouds.',
      sampleResponses: [
        'We spilled concentrated hydrochloric acid in Chemistry Room 12.',
        'There is a persistent sulfur/rotten-egg smell in the Biology Annex.',
        'Unlabelled storage barrels are leaking dense yellow sludge in the basement.'
      ],
      dispatcherResponses: {
        'We spilled concentrated hydrochloric acid in Chemistry Room 12.': 'Evacuate and lock the room immediately to prevent vapor inhalation. Do not attempt to wipe it up. We are deploying chemical neutralizing teams.',
        'There is a persistent sulfur/rotten-egg smell in the Biology Annex.': 'Warning: This indicates a possible toxic gas leak. Instruct everyone to exit the building upwind. Do not flip electrical switches!',
        'Unlabelled storage barrels are leaking dense yellow sludge in the basement.': 'Hazmat team is dispatching. Seal off basement vents. Do not touch or get close to the substance.'
      }
    },
    {
      id: 'crisis-counseling',
      name: 'Student Mental Health & Crisis Hotline',
      number: '+1 (555) 911-5000',
      description: 'Psychological first aid and acute panic response. Call during disasters for students experiencing intense panic, shock, or severe distress.',
      category: 'support',
      notes: 'Run by certified trauma-informed clinical safety counselors.',
      dispatcherGreeting: 'Crisis Support Helpline. This is a safe space. If you or someone near you is in distress, I am here to help you breathe.',
      sampleResponses: [
        'I am trapped under a desk in a drill lockdown and having a major panic attack.',
        'My classmate is in shock after the earthquake tremors and cannot speak.',
        'I am overwhelmed and terrified of upcoming severe weather forecasts.'
      ],
      dispatcherResponses: {
        'I am trapped under a desk in a drill lockdown and having a major panic attack.': 'Take a deep breath with me. Inhale for 4 seconds... hold for 4... exhale for 4. You are safe, the lockdown is a drill. Keep focusing on my voice.',
        'My classmate is in shock after the earthquake tremors and cannot speak.': 'Stay right there with them. Hold their hand if they let you. Speak in quiet, slow, reassuring tones. Assure them that the shaking has stopped.',
        'I am overwhelmed and terrified of upcoming severe weather forecasts.': 'It is completely normal to feel afraid. Preparedness is our superpower. Let\'s outline 3 simple steps you can take today to feel completely ready.'
      }
    },
    {
      id: 'facilities-outage',
      name: 'Facilities Maintenance & Utility Outages',
      number: '+1 (555) 911-6000',
      description: 'Call for downed electrical poles, ruptured water mains, gas odors, broken exterior glass panels, or flooding corridors.',
      category: 'facilities',
      notes: 'Handles campus-wide power, heating, elevator shafts, and structural integrity.',
      dispatcherGreeting: 'Campus Facilities Urgent Maintenance desk. What structural or utility failure are you reporting?',
      sampleResponses: [
        'A massive tree branch fell and snapped a powerline near the West Quad.',
        'Water is bursting from a pipe and flooding the second floor hallway.',
        'Steam is screaming out of a heater vent in Academic Hall.'
      ],
      dispatcherResponses: {
        'A massive tree branch fell and snapped a powerline near the West Quad.': 'Urgent facility crew is heading there now. Keep everyone at least 30 feet away from the line. Assume it is fully live and deadly!',
        'Water is bursting from a pipe and flooding the second floor hallway.': 'Understood. We are shutting off the main floor water valves immediately. Move any computer gear or valuables away from the floor.',
        'Steam is screaming out of a heater vent in Academic Hall.': 'We are shutting down the steam boilers for that quadrant. Do not approach the vent to avoid severe heat scalding.'
      }
    },
    {
      id: 'poison-control',
      name: 'National Poison Control Center',
      number: '+1 (800) 222-1222',
      description: 'National standard line for chemical ingestions, toxic fluid splashes on skin/eyes, or poison inhalation guides.',
      category: 'hazmat',
      notes: 'Integrated national database with toxicology professionals on call.',
      dispatcherGreeting: 'Poison Control Command. Has the substance been ingested, inhaled, or splashed, and is the victim conscious?',
      sampleResponses: [
        'A student accidentally swallowed a small amount of liquid solvent in lab.',
        'A student got battery acid splashed directly into their eyes.',
        'I inhaled strong pesticide vapors in the greenhouse and feel extremely dizzy.'
      ],
      dispatcherResponses: {
        'A student accidentally swallowed a small amount of liquid solvent in lab.': 'Do NOT induce vomiting unless instructed. Give them small sips of water. Have the bottle label ready and read me the chemical ingredients.',
        'A student got battery acid splashed directly into their eyes.': 'Begin flushing the eye immediately with lukewarm water for 15 minutes. Have them blink continuously. EMS paramedics are being notified.',
        'I inhaled strong pesticide vapors in the greenhouse and feel extremely dizzy.': 'Get into fresh outdoor air immediately! Sit down so you do not fall if dizzy. Loosen any tight clothing around your neck.'
      }
    }
  ];

  // Call simulator effects
  useEffect(() => {
    let interval: any;
    if (activeCall && callStatus === 'ringing') {
      interval = setInterval(() => {
        setCallStatus('connected');
        setHasAnswered(true);
        setCallLog([{ sender: 'dispatcher', text: activeCall.dispatcherGreeting }]);
      }, 2500); // 2.5 seconds ring simulation
    } else if (activeCall && callStatus === 'connected') {
      interval = setInterval(() => {
        setCallTimer(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [activeCall, callStatus]);

  const handleStartCall = (contact: ContactItem) => {
    setActiveCall(contact);
    setCallStatus('ringing');
    setCallTimer(0);
    setHasAnswered(false);
    setCallLog([]);
  };

  const handleEndCall = () => {
    setActiveCall(null);
    setCallStatus('ended');
    setCallTimer(0);
    setCallLog([]);
  };

  const handleUserReply = (responseOption: string) => {
    if (!activeCall) return;

    // Append user response
    setCallLog(prev => [...prev, { sender: 'user', text: responseOption }]);

    // Fetch dispatcher response
    const dispatcherReply = activeCall.dispatcherResponses[responseOption] || 
      "Copy that. Rescue personnel are being coordinated. Stay calm, seek shelter, and wait for emergency units.";

    // Append dispatcher response after a slight delay
    setTimeout(() => {
      setCallLog(prev => [...prev, { sender: 'dispatcher', text: dispatcherReply }]);
    }, 1200);
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Disaster playbooks data
  const playbooks = [
    {
      id: 'earthquake',
      title: 'Earthquake Action Guide',
      icon: Compass,
      color: 'border-amber-500 text-amber-600 bg-amber-500/5',
      accent: 'amber',
      tagline: 'Drop, Cover, and Hold On.',
      description: 'Seismic events strike with zero warning. Your rapid response within the first 3 seconds dictates your safety index.',
      before: [
        'Secure heavy laboratory cabinets, libraries, and chemical racks to structural studs.',
        'Maintain a 3-day emergency bag containing water, emergency blankets, and a battery radio.',
        'Locate load-bearing structural columns in your classrooms.'
      ],
      during: [
        'DROP immediately to your hands and knees. This posture keeps you stable.',
        'COVER your head and neck entirely under a heavy, sturdy desk or classroom table.',
        'HOLD ON to the desk leg firmly. Be prepared for your cover to slide with the floor waves.',
        'STAY indoors. Do not run outside during shaking, as falling masonry glass is a major hazard.'
      ],
      after: [
        'EVACUATE using structural stairways once shaking stops completely. Never trust elevators.',
        'CHECK classmates for arterial bleeding or injuries; apply tourniquets and call Clinic Paramedics.',
        'ANTICIPATE severe aftershocks. Stay in wide open grass quadrangles, clear of power grids.'
      ]
    },
    {
      id: 'fire',
      title: 'Active Fire Evacuation',
      icon: Flame,
      color: 'border-red-500 text-red-600 bg-red-500/5',
      accent: 'red',
      tagline: 'Crawl low under smoke. Gather at muster fields.',
      description: 'Thermal threats and carbon monoxide gases spread within minutes. Always assume any fire alarm is real.',
      before: [
        'Map out two independent evacuation routes from every dorm floor and academic hall.',
        'Learn the PASS technique for operating standard dry-chemical extinguishers.'
      ],
      during: [
        'STAY LOW to the floor to bypass dense clouds of toxic carbon monoxide and smoke.',
        'TEST door panels and handles with the back of your hand. If hot, seek alternate windows/routes.',
        'ACTIVATE the nearest manual fire alarm pull station as you exit.',
        'WALK, do not run, to keep evacuation stairwells clear of falling bottlenecks.'
      ],
      after: [
        'ASSEMBLE immediately at your department\'s designated muster yard.',
        'REPORT any unaccounted students or classroom peers to safety coordinators immediately.'
      ]
    },
    {
      id: 'flood',
      title: 'Flash Flood Readiness',
      icon: Waves,
      color: 'border-blue-500 text-blue-600 bg-blue-500/5',
      accent: 'blue',
      tagline: 'Turn around, don\'t drown. Ascend to upper floors.',
      description: 'Intense rainstorms or ruptured infrastructure lines can flood classrooms in minutes.',
      before: [
        'Familiarize yourself with local weather bulletins and campus drainage warnings.',
        'Identify low-elevation basement study halls and avoid storing valuable items there.'
      ],
      during: [
        'ASCEND immediately to the 2nd or 3rd floors of concrete academic structures.',
        'NEVER walk, wade, or drive through flowing water. 6 inches of water can easily sweep you off balance.',
        'SHUT DOWN high-voltage electrical equipment in affected zones if safe.'
      ],
      after: [
        'AVOID contacting standing water; it may be charged by downed cables or contaminated with toxics.',
        'DRINK only verified bottled water. Campus taps may be breached by stormwater infiltration.'
      ]
    },
    {
      id: 'lockdown',
      title: 'Active Threat Lockdown',
      icon: Shield,
      color: 'border-rose-500 text-rose-600 bg-rose-500/5',
      accent: 'rose',
      tagline: 'Run, Hide, Fight. Complete digital and physical silence.',
      description: 'Critical physical security threat requiring immediate tactical self-preservation.',
      before: [
        'Ensure your contact details are linked to the campus SMS emergency alert broadcast system.',
        'Identify secure classrooms with thick door barricades and internal lock bolts.'
      ],
      during: [
        'RUN: Evacuate instantly if there is a safe, clear, physically open escape path. Leave bags behind.',
        'HIDE: Barricade door panels with heavy teacher desks. Turn off lights, close blinds, and silence phones completely.',
        'FIGHT: As an absolute last resort if cornered. Act collectively with maximum force to disarm.'
      ],
      after: [
        'KEEP your hands open, fully visible, and empty above your head as response forces enter.',
        'REMAIN calm and follow all tactical safety commands of security personnel.'
      ]
    },
    {
      id: 'chemical',
      title: 'Chemical Spill & Gas Leak',
      icon: Skull,
      color: 'border-purple-500 text-purple-600 bg-purple-500/5',
      accent: 'purple',
      tagline: 'Evacuate upwind. Seal ventilation channels.',
      description: 'Volatile lab solvent leaks, natural gas main breaks, or toxic vapor threats.',
      before: [
        'Keep MSDS (Material Safety Data Sheets) near laboratory entrance doors.',
        'Locate eyewash fountains and body chemical showers in all research wings.'
      ],
      during: [
        'EVACUATE upwind of the spill immediately. Gas and heavy chemical fumes follow wind currents.',
        'AVOID flipping light switches or calling on radios inside contaminated zones to prevent ignition sparks.',
        'SHELTER-IN-PLACE if told: Close all windows, disable HVAC vents, and pack wet towels under doors.'
      ],
      after: [
        'FLUSH any skin or eyes exposed to chemicals immediately with water for 15 minutes.',
        'DO NOT enter sealed zones until chemical response monitors certify atmospheric safety.'
      ]
    },
    {
      id: 'tornado',
      title: 'Severe Storm & Tornado',
      icon: Wind,
      color: 'border-teal-500 text-teal-600 bg-teal-500/5',
      accent: 'teal',
      tagline: 'Locate windowless rooms on the lowest floor.',
      description: 'Tornadic funnel clouds and violent storm fronts with damaging flying debris.',
      before: [
        'Establish the difference between a Tornado Watch (conditions exist) and Warning (funnel spotted).',
        'Map the nearest designated shelter or reinforced interior basement corridor.'
      ],
      during: [
        'SEEK shelter instantly on the lowest level, in a windowless room or interior restroom.',
        'COVER your neck and skull with mattresses, heavy coats, or by crawling under sturdy tables.',
        'STAY away from large-span ceilings (auditoriums, gymnasiums) which are vulnerable to collapse.'
      ],
      after: [
        'WATCH for sharp glass, collapsing ceiling plaster, and exposed electrical sockets.',
        'STAY with your department group. Alert authorities to any structural collapses.'
      ]
    }
  ];

  // Playbook checklist helper
  const toggleStepCompleted = (playbookId: string, type: string, index: number) => {
    const key = `${playbookId}-${type}-${index}`;
    setCompletedSteps(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const getPlaybookCompletionRate = (playbookId: string) => {
    const pb = playbooks.find(p => p.id === playbookId);
    if (!pb) return 0;
    const total = pb.before.length + pb.during.length + pb.after.length;
    let completed = 0;
    pb.before.forEach((_, i) => { if (completedSteps[`${playbookId}-before-${i}`]) completed++; });
    pb.during.forEach((_, i) => { if (completedSteps[`${playbookId}-during-${i}`]) completed++; });
    pb.after.forEach((_, i) => { if (completedSteps[`${playbookId}-after-${i}`]) completed++; });
    return Math.round((completed / total) * 100);
  };

  // Filtered Alert Warnings
  const filteredAlerts = localAlerts.filter(alert => {
    const matchesSearch = alert.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          alert.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          alert.sender.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesSeverity = severityFilter === 'all' || alert.severity === severityFilter;
    const matchesType = typeFilter === 'all' || alert.type === typeFilter;

    return matchesSearch && matchesSeverity && matchesType;
  });

  // Filtered Contacts
  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = contact.name.toLowerCase().includes(contactSearch.toLowerCase()) || 
                          contact.description.toLowerCase().includes(contactSearch.toLowerCase()) ||
                          contact.number.includes(contactSearch);
    
    const matchesCategory = selectedContactCategory === 'all' || contact.category === selectedContactCategory;

    return matchesSearch && matchesCategory;
  });

  const getSeverityBadgeClass = (sev: string) => {
    switch(sev) {
      case 'high': return 'bg-red-50 text-red-700 border-red-200';
      case 'medium': return 'bg-amber-50 text-amber-700 border-amber-200';
      default: return 'bg-blue-50 text-blue-700 border-blue-200';
    }
  };

  const currentPlaybook = playbooks.find(p => p.id === selectedPlaybookId) || playbooks[0];
  const PlaybookIcon = currentPlaybook.icon;

  return (
    <div className="space-y-8 animate-fade-in max-w-7xl mx-auto px-1 md:px-4">
      
      {/* 1. BROADCAST ROOM HEADER */}
      <div id="broadcast-header" className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 relative overflow-hidden flex flex-col lg:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="absolute inset-0 bg-red-600/[0.015] animate-pulse pointer-events-none" />
        
        <div className="space-y-4 max-w-2xl text-center lg:text-left z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-500/10 border border-red-500/20 rounded-full text-[10px] md:text-xs font-bold text-red-400">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
            CRITICAL CAMPUS OPERATIONS CENTRAL
          </div>
          <h1 className="text-2xl md:text-4xl font-black text-white tracking-tight leading-none">
            Emergency Alert & <span className="text-amber-500">Crisis Broadcasts</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-lg leading-relaxed">
            Monitor disaster warning feeds, simulate audio siren drills, communicate instantly with emergency response operators, and study safety playbooks.
          </p>
        </div>

        {/* SIREN PANEL */}
        <div id="siren-control-panel" className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 md:p-5 flex flex-col md:flex-row items-center gap-6 shrink-0 w-full lg:w-auto z-10">
          <div className="space-y-3 w-full md:w-44 text-center md:text-left">
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block">Siren Sound Profile</label>
            <div className="grid grid-cols-3 gap-1">
              {(['ambulance', 'fire', 'tornado'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setSirenType(type)}
                  className={`px-1.5 py-1 rounded text-[9px] font-mono font-bold capitalize border transition-all ${
                    sirenType === type 
                      ? 'bg-amber-500 text-slate-950 border-amber-400' 
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
            
            {/* Volume control */}
            <div className="pt-1 space-y-1">
              <div className="flex justify-between items-center text-[8px] font-mono text-slate-500">
                <span>VOLUME</span>
                <span>{Math.round(sirenVolume * 1000)}%</span>
              </div>
              <input 
                type="range" 
                min="0.005" 
                max="0.15" 
                step="0.005" 
                value={sirenVolume} 
                onChange={(e) => setSirenVolume(parseFloat(e.target.value))}
                className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500" 
              />
            </div>
          </div>

          <div className="shrink-0">
            <button
              onClick={handleToggleSiren}
              className={`w-32 h-32 md:w-36 md:h-36 rounded-full border-4 flex flex-col items-center justify-center gap-1 cursor-pointer transition-all duration-300 shadow-2xl ${
                sirenActive 
                  ? 'bg-red-600 border-red-500 text-slate-100 animate-pulse scale-105 shadow-red-600/30' 
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              {sirenActive ? (
                <>
                  <VolumeX className="w-7 h-7 animate-bounce text-white" />
                  <span className="text-[9px] font-mono font-black uppercase tracking-widest text-white">Siren Active</span>
                  <span className="text-[8px] text-red-200">Click to Mute</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-7 h-7 text-amber-500" />
                  <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-slate-200">Test Sirens</span>
                  <span className="text-[8px] text-slate-500">Click to Buzz</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 2. SUB-TAB DESK SELECTOR */}
      <div id="sub-tabs" className="bg-white border border-slate-200 rounded-2xl p-1.5 flex gap-1 shadow-sm">
        <button
          onClick={() => setActiveSubTab('warnings')}
          className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeSubTab === 'warnings' 
              ? 'bg-blue-700 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          Disaster Warnings & Alerts
          {localAlerts.filter(a => a.isActive).length > 0 && (
            <span className={`px-1.5 py-0.5 text-[9px] rounded-full font-extrabold ${activeSubTab === 'warnings' ? 'bg-white text-blue-700' : 'bg-red-500 text-white animate-pulse'}`}>
              {localAlerts.filter(a => a.isActive).length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveSubTab('contacts')}
          className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeSubTab === 'contacts' 
              ? 'bg-blue-700 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <PhoneCall className="w-4 h-4" />
          Emergency Hotline Contacts
        </button>
        <button
          onClick={() => setActiveSubTab('playbooks')}
          className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            activeSubTab === 'playbooks' 
              ? 'bg-blue-700 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          Safety Prep Playbooks
        </button>
      </div>

      {/* 3. SUB-TAB CONTENT RENDERER */}
      
      {/* ======================= TAB 1: WARNING FEED & DRILLS ======================= */}
      {activeSubTab === 'warnings' && (
        <div className="space-y-6 animate-fade-in">
          
          {/* Controls Bar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 md:p-6 flex flex-col md:flex-row gap-4 items-center justify-between shadow-sm">
            
            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search alert broadcasts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-2 w-full text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/25 focus:border-blue-500 bg-slate-50"
              />
            </div>

            {/* Severity and Type Filters */}
            <div className="flex flex-wrap gap-2 w-full md:w-auto">
              {/* Severity Dropdown */}
              <div className="flex items-center gap-1 text-xs text-slate-500">
                <span className="hidden sm:inline">Severity:</span>
                <select
                  value={severityFilter}
                  onChange={(e) => setSeverityFilter(e.target.value)}
                  className="p-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/25"
                >
                  <option value="all">All Severities</option>
                  <option value="high">High Threat</option>
                  <option value="medium">Medium Threat</option>
                  <option value="low">Low Advisory</option>
                </select>
              </div>

              {/* Type Dropdown */}
              <div className="flex items-center gap-1 text-xs text-slate-500">
                <span className="hidden sm:inline">Type:</span>
                <select
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value)}
                  className="p-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/25"
                >
                  <option value="all">All Broadcasts</option>
                  <option value="real_emergency">Real Emergencies</option>
                  <option value="drill">Safety Drills</option>
                  <option value="advisory">System Advisories</option>
                </select>
              </div>

              {/* Reload Button */}
              <button
                onClick={fetchLocalAlerts}
                disabled={isLoadingAlerts}
                className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-slate-200 flex items-center justify-center gap-1"
                title="Sync warning desk feed"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingAlerts ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {/* Simulated Trigger Broadcast trigger */}
            <button
              onClick={() => setShowBroadcastForm(!showBroadcastForm)}
              className="w-full md:w-auto py-2.5 px-4 bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-md shadow-amber-500/10 cursor-pointer shrink-0"
            >
              {showBroadcastForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              {showBroadcastForm ? "Cancel Simulation" : "Simulate Broadcast"}
            </button>
          </div>

          {/* SIMULATED BROADCAST FORM */}
          {showBroadcastForm && (
            <div className="bg-amber-50 border-2 border-dashed border-amber-300 rounded-2xl p-6 space-y-4 animate-slide-down">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-amber-500 text-slate-950 rounded-xl">
                  <Megaphone className="w-5 h-5 animate-bounce" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">Broadcast Simulation Desk</h3>
                  <p className="text-[11px] text-slate-600">
                    Use this form to transmit a real safety warning. Doing so sends an HTTP request to the Express server API, broadcasting it instantaneously across any open student or teacher dashboards in this sandbox!
                  </p>
                </div>
              </div>

              <form onSubmit={handleBroadcastSubmit} className="grid md:grid-cols-2 gap-4 pt-2">
                <div className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block">Warning Title</label>
                    <input
                      type="text"
                      placeholder="e.g. Hazardous chemical solvent leak in Room 12"
                      value={formTitle}
                      onChange={(e) => setFormTitle(e.target.value)}
                      className="w-full p-2.5 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 bg-white font-medium"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block">Severity Level</label>
                      <select
                        value={formSeverity}
                        onChange={(e: any) => setFormSeverity(e.target.value)}
                        className="w-full p-2 text-xs border border-slate-300 rounded-xl bg-white"
                      >
                        <option value="high">🔥 High Threat</option>
                        <option value="medium">⚠️ Medium Warning</option>
                        <option value="low">ℹ️ Low Advisory</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block">Broadcast Type</label>
                      <select
                        value={formType}
                        onChange={(e: any) => setFormType(e.target.value)}
                        className="w-full p-2 text-xs border border-slate-300 rounded-xl bg-white"
                      >
                        <option value="real_emergency">Real Emergency</option>
                        <option value="drill">Quarterly Drill</option>
                        <option value="advisory">Advisory Notice</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block">Authorized Sender</label>
                    <input
                      type="text"
                      placeholder="e.g. Lincoln Safety Operations"
                      value={formSender}
                      onChange={(e) => setFormSender(e.target.value)}
                      className="w-full p-2.5 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 bg-white font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-3 flex flex-col justify-between">
                  <div className="space-y-1 flex-1 flex flex-col">
                    <label className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block">Evacuation Instructions / Alert Message</label>
                    <textarea
                      placeholder="Specify explicit safety coordinates. E.g., Active gas fumes detected in third-floor chemical laboratory corridor. All personnel must trigger fire doors and gather at West Quad muster yards upwind."
                      value={formMessage}
                      onChange={(e) => setFormMessage(e.target.value)}
                      className="w-full p-2.5 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 bg-white font-medium flex-1 resize-none min-h-[90px]"
                      required
                    />
                  </div>

                  <div className="flex items-center justify-between gap-4 pt-2">
                    <div className="text-xs">
                      {broadcastSuccess && <span className="text-emerald-700 font-extrabold flex items-center gap-1">✓ Broadcasted successfully!</span>}
                      {broadcastError && <span className="text-red-700 font-bold">{broadcastError}</span>}
                    </div>
                    
                    <button
                      type="submit"
                      className="py-2 px-6 bg-slate-900 hover:bg-slate-800 text-amber-400 hover:text-white font-black text-xs rounded-xl shadow-lg transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      Transmit Alert
                    </button>
                  </div>
                </div>
              </form>
            </div>
          )}

          {/* ACTIVE WARNINGS GRID */}
          <div className="grid lg:grid-cols-3 gap-8">
            
            {/* Warning Cards List */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-500 border-l-4 border-red-500 pl-2.5">
                  Live Broadcast Feed ({filteredAlerts.length})
                </h3>
                <span className="text-[10px] text-slate-400 font-mono">Real-time update stream</span>
              </div>

              {filteredAlerts.length === 0 ? (
                <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center space-y-4 shadow-sm">
                  <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                    <CheckCircle className="w-8 h-8" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-extrabold text-slate-850">No Alerts Match Filters</h4>
                    <p className="text-xs text-slate-500 max-w-sm mx-auto">
                      All systems operating within normal parameters, or no broadcasts match your active filters. Try removing search terms or category filters.
                    </p>
                  </div>
                  <button
                    onClick={() => { setSearchQuery(''); setSeverityFilter('all'); setTypeFilter('all'); }}
                    className="py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold"
                  >
                    Reset Filters
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredAlerts.map((alert) => (
                    <div 
                      key={alert.id} 
                      className={`bg-white border border-slate-200 rounded-2xl p-5 md:p-6 shadow-sm flex gap-4 items-start relative overflow-hidden group transition-all hover:shadow-md ${
                        alert.severity === 'high' && alert.isActive ? 'border-red-200 bg-red-500/[0.01]' : ''
                      }`}
                    >
                      {/* Left color bar indicator */}
                      <div className={`absolute top-0 bottom-0 left-0 w-2 ${
                        alert.severity === 'high' 
                          ? 'bg-red-500' 
                          : alert.severity === 'medium'
                            ? 'bg-amber-500'
                            : 'bg-blue-500'
                      }`} />

                      {/* Icon container */}
                      <div className={`p-3 rounded-2xl shrink-0 ${
                        alert.severity === 'high' 
                          ? 'bg-red-50 text-red-500' 
                          : alert.severity === 'medium'
                            ? 'bg-amber-50 text-amber-500'
                            : 'bg-blue-50 text-blue-500'
                      }`}>
                        <Megaphone className={`w-5 h-5 ${alert.severity === 'high' && alert.isActive ? 'animate-bounce' : ''}`} />
                      </div>

                      {/* Info details */}
                      <div className="space-y-3 flex-1 min-w-0">
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2">
                          <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                            {alert.title}
                            {!alert.isActive && (
                              <span className="bg-slate-100 text-slate-500 text-[8px] font-mono font-bold px-1.5 py-0.2 rounded border uppercase">Deactivated</span>
                            )}
                          </h4>
                          <div className="flex items-center gap-1">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-black border uppercase ${getSeverityBadgeClass(alert.severity)}`}>
                              {alert.severity}
                            </span>
                            <span className="px-1.5 py-0.5 bg-slate-100 text-slate-700 text-[9px] font-mono font-bold rounded border uppercase">
                              {alert.type}
                            </span>
                          </div>
                        </div>

                        <p className="text-xs text-slate-700 leading-relaxed font-medium">
                          {alert.message}
                        </p>

                        <div className="flex flex-col sm:flex-row justify-between sm:items-center text-[10px] text-slate-400 font-mono pt-1 gap-2">
                          <span className="flex items-center gap-1">
                            <Info className="w-3.5 h-3.5 text-slate-400" />
                            Sender: <strong className="text-slate-600">{alert.sender}</strong>
                          </span>
                          <span className="flex items-center gap-1 sm:justify-end">
                            <Clock className="w-3.5 h-3.5" />
                            {new Date(alert.timestamp).toLocaleString()}
                          </span>
                        </div>
                      </div>

                      {/* Teacher/Admin Clear control */}
                      {alert.isActive && (
                        <button
                          onClick={() => handleDeactivateAlert(alert.id)}
                          className="shrink-0 p-1.5 bg-slate-50 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-lg border border-slate-200 transition-all text-[10px] font-mono font-bold flex items-center gap-0.5"
                          title="Clear this notice"
                        >
                          <X className="w-3 h-3" /> Clear
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Side-evacuation maps checklist */}
            <div className="space-y-6">
              <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-sm">
                <div className="flex items-center gap-2 text-red-600 border-b border-slate-100 pb-3">
                  <AlertTriangle className="w-5 h-5" />
                  <h3 className="text-xs font-black uppercase tracking-widest text-slate-800">
                    Evacuation Checklist
                  </h3>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed">
                  During an active alarm or evacuation notice, memorize and immediately carry out these basic safety rules:
                </p>

                <div className="space-y-4 text-xs text-slate-700 leading-relaxed pl-1 pt-1">
                  <div className="flex gap-3">
                    <span className="w-6 h-6 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-[10px] font-mono flex items-center justify-center font-bold shrink-0">01</span>
                    <div>
                      <h4 className="font-extrabold text-slate-950">Abort Task, Leave Baggage</h4>
                      <p className="text-[11px] text-slate-500 leading-normal mt-0.5">Do not waste critical seconds packing backpacks, books, or laptops. Exit immediately.</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <span className="w-6 h-6 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-[10px] font-mono flex items-center justify-center font-bold shrink-0">02</span>
                    <div>
                      <h4 className="font-extrabold text-slate-950">Isolate Dangerous Apparatus</h4>
                      <p className="text-[11px] text-slate-500 leading-normal mt-0.5">If safe, quickly switch off laboratory gas valves, chemical vent hoods, and high-volt fans.</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <span className="w-6 h-6 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-[10px] font-mono flex items-center justify-center font-bold shrink-0">03</span>
                    <div>
                      <h4 className="font-extrabold text-slate-950">Test Door Temperature</h4>
                      <p className="text-[11px] text-slate-500 leading-normal mt-0.5">Use the back of your hand to feel wooden door panels. If hot, seek an alternate window or fire exit.</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <span className="w-6 h-6 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-[10px] font-mono flex items-center justify-center font-bold shrink-0">04</span>
                    <div>
                      <h4 className="font-extrabold text-slate-950">Evacuate Quietly, Single-File</h4>
                      <p className="text-[11px] text-slate-500 leading-normal mt-0.5">Maintain silent lines in stairwells so you can hear auditory updates from building wardens.</p>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  <div className="p-3 bg-slate-50 border border-slate-150 rounded-xl flex items-center gap-3">
                    <div className="p-2 bg-slate-250 text-slate-600 rounded-lg">
                      <MapPin className="w-4 h-4 text-slate-500" />
                    </div>
                    <div>
                      <span className="text-[9px] font-mono uppercase tracking-wider text-slate-400 block font-bold">Designated Campus Assembly Zone</span>
                      <strong className="text-xs text-slate-800">Lincoln University Central Quad Green</strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* ======================= TAB 2: EMERGENCY CONTACTS ======================= */}
      {activeSubTab === 'contacts' && (
        <div className="grid lg:grid-cols-3 gap-8 animate-fade-in">
          
          {/* Contact directory cards */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Filtering bar for contacts */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 md:p-5 flex flex-col sm:flex-row gap-3 items-center justify-between shadow-sm">
              <div className="relative w-full sm:w-72">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search emergency lines..."
                  value={contactSearch}
                  onChange={(e) => setContactSearch(e.target.value)}
                  className="pl-9 pr-4 py-1.5 w-full text-xs border border-slate-200 rounded-xl bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/25"
                />
              </div>

              <div className="flex gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
                {(['all', 'primary', 'medical', 'hazmat', 'facilities', 'support'] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedContactCategory(cat)}
                    className={`px-2.5 py-1 text-[10px] font-bold rounded-lg border capitalize whitespace-nowrap transition-all cursor-pointer ${
                      selectedContactCategory === cat
                        ? 'bg-blue-700 text-white border-blue-700 shadow-sm'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* List of contacts */}
            <div className="space-y-4">
              {filteredContacts.length === 0 ? (
                <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-500">
                  No contact helplines found matching your query.
                </div>
              ) : (
                filteredContacts.map((contact) => (
                  <div 
                    key={contact.id}
                    className="bg-white border border-slate-200 rounded-2xl p-5 md:p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:shadow-md transition-all group"
                  >
                    <div className="space-y-2 flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`px-2 py-0.5 text-[8px] font-mono uppercase font-black rounded border ${
                          contact.category === 'primary' 
                            ? 'bg-red-50 text-red-700 border-red-200'
                            : contact.category === 'medical'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : contact.category === 'hazmat'
                                ? 'bg-purple-50 text-purple-700 border-purple-200'
                                : 'bg-slate-50 text-slate-600 border-slate-200'
                        }`}>
                          {contact.category}
                        </span>
                        <h4 className="text-sm font-black text-slate-900 truncate">{contact.name}</h4>
                      </div>

                      <p className="text-xs text-slate-600 leading-relaxed">
                        {contact.description}
                      </p>

                      <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                        <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{contact.notes}</span>
                      </div>
                    </div>

                    <div className="flex md:flex-col items-center md:items-end justify-between w-full md:w-auto shrink-0 gap-3 border-t md:border-t-0 border-slate-100 pt-3 md:pt-0">
                      {/* Phone Display with dial action */}
                      <div className="space-y-0.5 text-left md:text-right">
                        <span className="text-[9px] font-mono text-slate-400 block font-bold">24-HR DIRECT CONTACT</span>
                        <span className="text-sm font-black font-mono text-slate-900 group-hover:text-blue-700 transition-colors block">{contact.number}</span>
                      </div>

                      {/* Control keys */}
                      <div className="flex gap-1">
                        {/* Copy number */}
                        <button
                          onClick={() => handleCopyNumber(contact.id, contact.number)}
                          className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-500 hover:text-slate-900 rounded-xl border border-slate-200 transition-all cursor-pointer"
                          title="Copy number to clipboard"
                        >
                          {copiedId === contact.id ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                        </button>
                        
                        {/* Simulate direct call button */}
                        <button
                          onClick={() => handleStartCall(contact)}
                          className="py-1.5 px-3 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl flex items-center gap-1 shadow-sm hover:shadow transition-all cursor-pointer"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          Simulate Call
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Dispatcher tips */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 md:p-6 text-slate-300 space-y-3">
              <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-amber-500 flex items-center gap-1.5">
                <Shield className="w-4 h-4" />
                Dispatcher Protocol Guidelines
              </h4>
              <p className="text-xs leading-relaxed text-slate-400">
                When dialling an emergency operator, keep your voice steady and communicate using the **S.A.F.E.** format:
              </p>
              <div className="grid sm:grid-cols-2 gap-4 text-xs pt-1">
                <div className="space-y-1">
                  <strong className="text-slate-200">S - Specific Location:</strong>
                  <p className="text-slate-400 text-[11px]">Identify your building, room number, or closest quad intersection instantly.</p>
                </div>
                <div className="space-y-1">
                  <strong className="text-slate-200">A - Active Hazard:</strong>
                  <p className="text-slate-400 text-[11px]">Explain if there is smoke, water, structural collapse, or physical threat.</p>
                </div>
                <div className="space-y-1">
                  <strong className="text-slate-200">F - Victims Count:</strong>
                  <p className="text-slate-400 text-[11px]">Indicate if any peers are injured, bleeding, trapped, or unconscious.</p>
                </div>
                <div className="space-y-1">
                  <strong className="text-slate-200">E - Equipment Status:</strong>
                  <p className="text-slate-400 text-[11px]">Note if fire alarm pulls have been physically pulled or if HVAC is off.</p>
                </div>
              </div>
            </div>

          </div>

          {/* TAB 2 SIDEBAR: CALL SIMULATION DIALOG DESK */}
          <div className="space-y-6">
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm border-t-4 border-t-red-600 space-y-4 sticky top-6">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3 justify-between">
                <div className="flex items-center gap-1.5">
                  <Phone className="w-4 h-4 text-red-600 animate-pulse" />
                  <h3 className="text-xs font-black uppercase tracking-widest text-slate-800">
                    Call Center Desk
                  </h3>
                </div>
                {activeCall && (
                  <span className="px-2 py-0.5 bg-red-100 text-red-800 border border-red-200 text-[9px] font-mono rounded font-bold animate-pulse">
                    LIVE CONNECTION
                  </span>
                )}
              </div>

              {activeCall ? (
                <div className="space-y-4">
                  
                  {/* Phone Screen Display */}
                  <div className="bg-slate-950 text-slate-100 p-4 rounded-2xl text-center space-y-2 font-mono border border-slate-800 shadow-inner">
                    <span className="text-[10px] text-amber-500 uppercase tracking-widest block font-bold">
                      {callStatus === 'ringing' ? '☎ RINGING...' : '• CONNECTED'}
                    </span>
                    <h4 className="text-xs font-black truncate text-white">{activeCall.name}</h4>
                    <p className="text-sm font-bold text-slate-400">{activeCall.number}</p>
                    
                    <div className="text-[10px] text-slate-500 pt-2 flex items-center justify-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-500" />
                      <span>{formatTimer(callTimer)}</span>
                    </div>
                  </div>

                  {/* Ringing loading bar */}
                  {callStatus === 'ringing' && (
                    <div className="space-y-2 py-4 text-center">
                      <div className="w-10 h-10 bg-slate-100 text-slate-600 rounded-full flex items-center justify-center mx-auto border border-slate-200 animate-spin">
                        <Phone className="w-4 h-4" />
                      </div>
                      <p className="text-xs text-slate-400 italic">Transmitting digital signal over campus VOIP grid...</p>
                    </div>
                  )}

                  {/* Connected Chat Log */}
                  {callStatus === 'connected' && (
                    <div className="space-y-3">
                      <label className="text-[9px] font-mono uppercase tracking-wider text-slate-400 block font-bold">Interactive Voice Feed</label>
                      
                      <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 h-64 overflow-y-auto space-y-3 text-xs leading-relaxed">
                        {callLog.map((log, idx) => (
                          <div 
                            key={idx} 
                            className={`p-2.5 rounded-xl max-w-[85%] ${
                              log.sender === 'dispatcher' 
                                ? 'bg-white border border-slate-200 text-slate-850 mr-auto shadow-sm' 
                                : 'bg-blue-600 text-white ml-auto'
                            }`}
                          >
                            <span className="text-[8px] font-mono uppercase tracking-widest block opacity-75 font-bold mb-0.5">
                              {log.sender === 'dispatcher' ? 'Safety Dispatcher' : 'You (Student)'}
                            </span>
                            <p className="font-medium">{log.text}</p>
                          </div>
                        ))}
                      </div>

                      {/* Interactive response options */}
                      <div className="space-y-2 pt-2">
                        <span className="text-[9px] font-mono uppercase tracking-wider text-slate-400 block font-bold">Choose safety reply:</span>
                        <div className="space-y-1.5">
                          {activeCall.sampleResponses.map((resOption, rIdx) => (
                            <button
                              key={rIdx}
                              onClick={() => handleUserReply(resOption)}
                              disabled={callLog[callLog.length - 1]?.sender === 'user'}
                              className="w-full p-2 text-left text-xs bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold rounded-xl border border-slate-200 transition-all flex items-center justify-between gap-2 disabled:opacity-50 cursor-pointer"
                            >
                              <span>{resOption}</span>
                              <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            </button>
                          ))}
                        </div>
                      </div>

                    </div>
                  )}

                  {/* Red End Call Action */}
                  <button
                    onClick={handleEndCall}
                    className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-lg shadow-red-600/10 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                    Hang Up & Evacuate
                  </button>

                </div>
              ) : (
                <div className="text-center py-12 space-y-3">
                  <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-400 border border-slate-200">
                    <Phone className="w-5 h-5 text-slate-400" />
                  </div>
                  <div>
                    <h4 className="text-xs font-extrabold text-slate-800">No active connection</h4>
                    <p className="text-[11px] text-slate-400 max-w-xs mx-auto mt-0.5">
                      Select any helpline contact card on the left and click "Simulate Call" to practice reporting emergencies under crisis scenarios.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>
      )}

      {/* ======================= TAB 3: DISASTER SAFETY PLAYBOOKS ======================= */}
      {activeSubTab === 'playbooks' && (
        <div className="grid lg:grid-cols-3 gap-8 animate-fade-in">
          
          {/* List of playbooks */}
          <div className="lg:col-span-1 space-y-3">
            <div className="flex justify-between items-center px-1 pb-1">
              <span className="text-xs font-black uppercase tracking-widest text-slate-500">Playbook Catalogue</span>
              <span className="text-[10px] text-slate-400 font-mono">Rehearsal tracker</span>
            </div>

            <div className="space-y-2">
              {playbooks.map((pb) => {
                const Icon = pb.icon;
                const isSelected = selectedPlaybookId === pb.id;
                const progress = getPlaybookCompletionRate(pb.id);

                return (
                  <button
                    key={pb.id}
                    onClick={() => setSelectedPlaybookId(pb.id)}
                    className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between gap-4 transition-all shadow-sm cursor-pointer ${
                      isSelected 
                        ? 'bg-slate-900 border-slate-900 text-slate-100 shadow-md scale-[1.01]' 
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`p-2.5 rounded-xl shrink-0 ${
                        isSelected ? 'bg-slate-800 text-amber-400' : 'bg-slate-100 text-slate-500'
                      }`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs font-black truncate">{pb.title}</h4>
                        <p className={`text-[10px] truncate mt-0.5 ${isSelected ? 'text-slate-400 font-medium' : 'text-slate-500'}`}>
                          {pb.tagline}
                        </p>
                      </div>
                    </div>

                    <div className="shrink-0 flex flex-col items-end gap-1">
                      <span className={`text-[9px] font-mono font-bold ${isSelected ? 'text-amber-400' : 'text-blue-700'}`}>
                        {progress}%
                      </span>
                      {/* Micro Progress Bar */}
                      <div className="w-12 h-1 bg-slate-200 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all duration-300 ${isSelected ? 'bg-amber-400' : 'bg-blue-700'}`}
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Detailed playbook guide display */}
          <div className="lg:col-span-2 space-y-6">
            
            <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-sm space-y-6">
              
              {/* Playbook Header */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                <div className="flex items-center gap-3.5">
                  <div className="p-3 bg-slate-950 text-amber-400 rounded-2xl shrink-0 shadow-md">
                    <PlaybookIcon className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[9px] font-mono font-black uppercase tracking-wider text-blue-700 block">TACTICAL INSTRUCTION PLAYBOOK</span>
                    <h2 className="text-xl font-black text-slate-900 leading-none mt-0.5">{currentPlaybook.title}</h2>
                    <p className="text-xs text-slate-500 mt-1 font-medium italic">"{currentPlaybook.tagline}"</p>
                  </div>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  <div className="text-right">
                    <span className="text-[8px] font-mono text-slate-400 uppercase block font-bold">Preparation Index</span>
                    <strong className="text-xs font-bold text-blue-700">{getPlaybookCompletionRate(currentPlaybook.id)}% Rehearsed</strong>
                  </div>
                  <div className="w-10 h-10 rounded-full border-4 border-slate-100 flex items-center justify-center text-xs font-mono font-black text-slate-700 relative">
                    <div 
                      className="absolute inset-[-4px] rounded-full border-4 border-blue-700 transition-all duration-500" 
                      style={{ clipPath: `inset(0 ${100 - getPlaybookCompletionRate(currentPlaybook.id)}% 0 0)` }} 
                    />
                    {getPlaybookCompletionRate(currentPlaybook.id)}%
                  </div>
                </div>
              </div>

              {/* Playbook Description */}
              <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-4 border border-slate-150 rounded-2xl font-medium">
                {currentPlaybook.description}
              </p>

              {/* Before, During, After Columns / Panels using Alert Cards styled lists */}
              <div className="space-y-6">
                
                {/* 1. BEFORE DISASTER SECTION */}
                <div className="space-y-3">
                  <div className="flex items-center gap-1.5 text-blue-800 font-extrabold text-xs uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-blue-600" />
                    Phase A: Mitigate & Prepare (Before)
                  </div>
                  
                  <div className="grid gap-2">
                    {currentPlaybook.before.map((step, idx) => {
                      const isDone = completedSteps[`${currentPlaybook.id}-before-${idx}`];
                      return (
                        <div 
                          key={idx}
                          onClick={() => toggleStepCompleted(currentPlaybook.id, 'before', idx)}
                          className={`p-3.5 border rounded-xl flex items-start gap-3 transition-all cursor-pointer ${
                            isDone 
                              ? 'bg-emerald-50/50 border-emerald-200 text-slate-600' 
                              : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                          }`}
                        >
                          <div className="pt-0.5 shrink-0">
                            {isDone ? (
                              <CheckSquare className="w-4.5 h-4.5 text-emerald-600" />
                            ) : (
                              <Square className="w-4.5 h-4.5 text-slate-300 hover:text-blue-600" />
                            )}
                          </div>
                          <p className="text-xs font-medium leading-relaxed">{step}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 2. DURING DISASTER SECTION */}
                <div className="space-y-3">
                  <div className="flex items-center gap-1.5 text-red-800 font-extrabold text-xs uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-red-600 animate-ping" />
                    Phase B: Active Emergency Actions (During)
                  </div>
                  
                  <div className="grid gap-2">
                    {currentPlaybook.during.map((step, idx) => {
                      const isDone = completedSteps[`${currentPlaybook.id}-during-${idx}`];
                      return (
                        <div 
                          key={idx}
                          onClick={() => toggleStepCompleted(currentPlaybook.id, 'during', idx)}
                          className={`p-3.5 border rounded-xl flex items-start gap-3 transition-all cursor-pointer ${
                            isDone 
                              ? 'bg-emerald-50/50 border-emerald-200 text-slate-600' 
                              : 'bg-red-500/[0.01] hover:bg-red-500/[0.03] border-red-200 text-slate-900 font-semibold'
                          }`}
                        >
                          <div className="pt-0.5 shrink-0">
                            {isDone ? (
                              <CheckSquare className="w-4.5 h-4.5 text-emerald-600" />
                            ) : (
                              <Square className="w-4.5 h-4.5 text-red-300 hover:text-red-600" />
                            )}
                          </div>
                          <p className="text-xs leading-relaxed">{step}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 3. AFTER DISASTER SECTION */}
                <div className="space-y-3">
                  <div className="flex items-center gap-1.5 text-slate-800 font-extrabold text-xs uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-slate-600" />
                    Phase C: Evacuate & Recover (After)
                  </div>
                  
                  <div className="grid gap-2">
                    {currentPlaybook.after.map((step, idx) => {
                      const isDone = completedSteps[`${currentPlaybook.id}-after-${idx}`];
                      return (
                        <div 
                          key={idx}
                          onClick={() => toggleStepCompleted(currentPlaybook.id, 'after', idx)}
                          className={`p-3.5 border rounded-xl flex items-start gap-3 transition-all cursor-pointer ${
                            isDone 
                              ? 'bg-emerald-50/50 border-emerald-200 text-slate-600' 
                              : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                          }`}
                        >
                          <div className="pt-0.5 shrink-0">
                            {isDone ? (
                              <CheckSquare className="w-4.5 h-4.5 text-emerald-600" />
                            ) : (
                              <Square className="w-4.5 h-4.5 text-slate-300 hover:text-slate-600" />
                            )}
                          </div>
                          <p className="text-xs font-medium leading-relaxed">{step}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>

              {/* Reset drill progress */}
              <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
                <span className="text-[10px] text-slate-400 font-mono">Mark all checkboxes to complete mock drill simulation.</span>
                <button
                  onClick={() => {
                    const cleared: any = {};
                    Object.keys(completedSteps).forEach(k => {
                      if (!k.startsWith(`${currentPlaybook.id}-`)) {
                        cleared[k] = completedSteps[k];
                      }
                    });
                    setCompletedSteps(cleared);
                  }}
                  className="py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-all cursor-pointer"
                >
                  Reset Playbook Checklist
                </button>
              </div>

            </div>
          </div>

        </div>
      )}

    </div>
  );
}
