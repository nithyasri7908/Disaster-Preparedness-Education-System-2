import React, { useState } from 'react';
import { 
  ShieldAlert, Play, GraduationCap, MessageSquare, Phone, Users, 
  ArrowRight, BookOpen, AlertCircle, Flame, Waves, Compass, 
  FileCheck, Activity, UserCheck, AlertTriangle, HeartHandshake, Map
} from 'lucide-react';
import { UserProfile, EmergencyAlert } from '../types';

interface HomeProps {
  user: UserProfile | null;
  alerts: EmergencyAlert[];
  onNavigate: (tab: string) => void;
}

export default function Home({ user, alerts, onNavigate }: HomeProps) {
  const activeDrills = alerts.filter(a => a.isActive && a.type === 'drill');
  const activeEmergencies = alerts.filter(a => a.isActive && a.type === 'real_emergency');
  const activeAlerts = alerts.filter(a => a.isActive);

  // State for interactive disaster categories selector
  const [selectedCategory, setSelectedCategory] = useState<string>('earthquake');

  const disasterCategories = [
    {
      id: 'earthquake',
      title: 'Seismic & Earthquakes',
      icon: Compass,
      color: 'bg-amber-50 text-amber-700 border-amber-200 hover:border-amber-300',
      activeColor: 'bg-amber-100 text-amber-800 border-amber-400',
      tagline: 'Drop, Cover, and Hold On.',
      description: 'Sudden shifting of tectonic plates. Damage usually results from collapsing structures, falling debris, and ruptured utility mains.',
      checklist: [
        'Drop onto your hands and knees to prevent being knocked over.',
        'Cover your head and neck under a sturdy table or desk.',
        'Hold on to your shelter until the ground stops shaking.',
        'Evacuate immediately if safety wardens activate the alarm after shocks stop.'
      ],
      hazardRating: 'High Risk (Infrastructure Collapsing)',
      drillFrequency: 'Quarterly academic testing required'
    },
    {
      id: 'flood',
      title: 'Flash Floods & Storms',
      icon: Waves,
      color: 'bg-blue-50 text-blue-700 border-blue-200 hover:border-blue-300',
      activeColor: 'bg-blue-100 text-blue-800 border-blue-400',
      tagline: 'Turn around, don’t drown.',
      description: 'Rapid flooding of geomorphic low-lying areas, washes, and rivers. Can arise in minutes due to heavy downpours or dam ruptures.',
      checklist: [
        'Move to designated higher floors of academic halls instantly.',
        'Never drive or walk through moving water currents.',
        'Avoid basement study halls and elevator shafts.',
        'Monitor active drainage gauges and campus broadcast warning lines.'
      ],
      hazardRating: 'High Frequency (Regional Precipitation)',
      drillFrequency: 'Bi-annual safety simulations'
    },
    {
      id: 'fire',
      title: 'Active Fires & Hazmat',
      icon: Flame,
      color: 'bg-red-50 text-red-700 border-red-200 hover:border-red-300',
      activeColor: 'bg-red-100 text-red-800 border-red-400',
      tagline: 'Pull, Aim, Squeeze, Sweep (PASS).',
      description: 'Rapidly spreading combustion within campus laboratories, libraries, or computer facilities. Involves toxic fumes and immediate thermal danger.',
      checklist: [
        'Pull fire alarm pull-stations while retreating toward designated exits.',
        'Stay low to the ground to bypass toxic carbon-monoxide clouds.',
        'Feel doors with the back of your hand before grasping handles.',
        'Gather at designated outdoor muster assembly points.'
      ],
      hazardRating: 'Severe Hazard (Chemicals & Electrical Core)',
      drillFrequency: 'Monthly dormitory & lab evacuation runs'
    },
    {
      id: 'shooter',
      title: 'Active Threat (Lockdown)',
      icon: ShieldAlert,
      color: 'bg-rose-50 text-rose-700 border-rose-200 hover:border-rose-300',
      activeColor: 'bg-rose-100 text-rose-800 border-rose-400',
      tagline: 'Run, Hide, Fight.',
      description: 'Hostile personnel threatening physical harm to students and campus staff. Requires rapid containment, tactical silences, and defensive drills.',
      checklist: [
        'Run to safe exits if a clear trajectory is physically open.',
        'Hide in classrooms; lock doors, dim lights, and silence electronic devices completely.',
        'Fight as a last resort when life is in immediate, direct danger.',
        'Remain absolutely silent and do not exit until security forces unlock the area.'
      ],
      hazardRating: 'Critical Threat (Interpersonal Danger)',
      drillFrequency: 'Annual campus-wide tactical lockdown coordination'
    }
  ];

  const stats = [
    { label: "Active Live Drills", value: activeDrills.length, color: "text-blue-700", desc: "Coordinated exercises underway" },
    { label: "Emergency Advisories", value: activeEmergencies.length, color: "text-red-600", desc: "Critical real-time situation monitors" },
    { label: "Certified Responders", value: "1,240+", color: "text-emerald-600", desc: "Trained students and faculty staff" },
    { label: "Completed Risk Audits", value: "328", color: "text-purple-700", desc: "Campus structural safety reviews" }
  ];

  const platformFeatures = [
    {
      title: "Interactive Learning Modules",
      desc: "Immersive textbooks, structural fire maps, and flashcard sets covering standard first-responder protocols.",
      icon: GraduationCap,
      linkText: "Start Learning",
      tab: "modules"
    },
    {
      title: "Real-Time Disaster Simulator",
      desc: "Multi-branch safety laboratory modeling real-world earthquakes and floods where your decisions determine the outcome.",
      icon: Play,
      linkText: "Enter Simulator",
      tab: "simulator"
    },
    {
      title: "AI Response Assistant",
      desc: "24/7 intelligent consultant to answer questions on chemistry hazards, medical kits, and local evacuations.",
      icon: MessageSquare,
      linkText: "Ask AI Assistant",
      tab: "chatbot"
    },
    {
      title: "Risk & Hazard Assessment",
      desc: "Structured auditing tool enabling users to inspect hallways, record extinguisher tags, and report structural faults.",
      icon: Map,
      linkText: "Submit Audit",
      tab: "assessment"
    }
  ];

  return (
    <div className="space-y-10 animate-fade-in pb-16">
      
      {/* 1. Emergency Alert Banner (Fetched in real-time from Express backend API) */}
      {activeAlerts.length > 0 ? (
        <div className="bg-white border-l-4 border-red-600 rounded-r-xl shadow-md p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-red-50 text-red-600 rounded-lg shrink-0 mt-0.5 animate-bounce">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-widest text-red-600 px-2.5 py-0.5 bg-red-50 rounded border border-red-100">
                  Active Emergency Transmission
                </span>
                <span className="text-slate-400 text-xs">•</span>
                <span className="text-slate-500 text-xs font-medium">Broadcasted Campus-wide</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mt-1.5">
                {activeAlerts[0].title} ({activeAlerts[0].severity.toUpperCase()} Severity)
              </h3>
              <p className="text-sm text-slate-600 mt-1 leading-relaxed">
                {activeAlerts[0].message} — Immediate compliance required.
              </p>
              <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
                <span>📍 Source: {activeAlerts[0].sender}</span>
                <span>⏱️ Posted: {new Date(activeAlerts[0].timestamp).toLocaleTimeString()}</span>
              </div>
            </div>
          </div>
          <button 
            onClick={() => onNavigate('alerts')}
            className="w-full md:w-auto shrink-0 px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-xs tracking-wider uppercase shadow-sm transition-all cursor-pointer text-center"
          >
            Review Warning Board
          </button>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <span className="relative flex h-2 w-2 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600"></span>
            </span>
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              System Status: Continuous Safety Monitoring Active
            </span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">SECURE CONNECTION SEC-09</span>
        </div>
      )}

      {/* 2. Hero Banner & Welcome Section */}
      <div className="relative bg-white border border-slate-200 rounded-2xl p-8 md:p-12 overflow-hidden shadow-sm">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-80 h-80 bg-blue-500/[0.03] rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-16 w-64 h-64 bg-emerald-500/[0.02] rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 border border-blue-100 rounded-full text-xs font-semibold text-blue-700">
            <Activity className="w-3.5 h-3.5 animate-pulse text-blue-600" />
            ACADEMIC RESPONSE PORTAL
          </div>

          <div className="space-y-3">
            {user ? (
              <h2 className="text-lg font-bold text-blue-800">
                Welcome back to ResponseEd, <span className="underline decoration-blue-200 decoration-2">{user.name}</span>
              </h2>
            ) : (
              <h2 className="text-lg font-bold text-slate-600">
                ResponseEd Prep Network
              </h2>
            )}
            
            <h1 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight leading-none">
              Empowering Communities with <span className="text-blue-700">Responsive Crisis Action</span>
            </h1>
          </div>

          <p className="text-base text-slate-600 leading-relaxed max-w-2xl">
            A specialized digital learning environment that equips students, instructional staff, and academic coordinators with interactive hazard simulators, certified first-responder training, and real-time broadcast alert management.
          </p>

          <div className="flex flex-wrap gap-3 pt-2">
            {user ? (
              <button 
                onClick={() => onNavigate(user.role === 'student' ? 'student-dash' : user.role === 'teacher' ? 'teacher-dash' : 'admin-dash')}
                className="bg-blue-700 hover:bg-blue-800 text-white px-6 py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all shadow-md shadow-blue-500/10 cursor-pointer"
              >
                Go to My {user.role === 'student' ? 'Student' : user.role === 'teacher' ? 'Teacher' : 'Coordinator'} Dashboard
              </button>
            ) : (
              <button 
                onClick={() => onNavigate('login')}
                className="bg-blue-700 hover:bg-blue-800 text-white px-6 py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all shadow-md shadow-blue-500/10 cursor-pointer"
              >
                Access Secure Portal
              </button>
            )}
            
            <button 
              onClick={() => onNavigate('about')}
              className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 px-6 py-3 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all shadow-sm cursor-pointer"
            >
              Learn More
            </button>
          </div>
        </div>
      </div>

      {/* 3. Statistics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs transition-all hover:-translate-y-1 hover:shadow-md">
            <span className="text-[10px] font-extrabold tracking-wider text-slate-400 uppercase">{stat.label}</span>
            <p className={`text-3xl md:text-4xl font-extrabold ${stat.color} mt-2 tracking-tight`}>{stat.value}</p>
            <p className="text-xs text-slate-500 mt-1 font-medium">{stat.desc}</p>
          </div>
        ))}
      </div>

      {/* 4. About the Platform Section */}
      <div className="grid lg:grid-cols-3 gap-8 bg-white border border-slate-200 rounded-2xl p-6 md:p-8 shadow-sm">
        <div className="lg:col-span-1 space-y-4">
          <div className="p-3 bg-blue-50 text-blue-700 rounded-xl w-fit">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">
            A Smart Framework for Academic Safety
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            School buildings feature concentrated occupant loads, complex laboratory components, and distinct physical vulnerabilities. ResponseEd bridges the gap between passive policy manuals and real-time, responsive drills.
          </p>
          <div className="pt-2">
            <button 
              onClick={() => onNavigate('about')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-700 hover:text-blue-800 transition-colors cursor-pointer"
            >
              Read Full Charter <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="lg:col-span-2 grid sm:grid-cols-2 gap-6">
          <div className="p-5 bg-slate-50 border border-slate-100 rounded-xl space-y-2">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-emerald-600" />
              <h4 className="text-sm font-bold text-slate-800">For Students</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Equip yourself with vital knowledge through byte-sized emergency response textbooks, simulated crisis decision paths, and official, shareable certificates.
            </p>
          </div>

          <div className="p-5 bg-slate-50 border border-slate-100 rounded-xl space-y-2">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-600" />
              <h4 className="text-sm font-bold text-slate-800">For Instructors</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Launch instant drills, broadcast localized emergency warnings, and review class safety status metrics across campuses.
            </p>
          </div>

          <div className="p-5 bg-slate-50 border border-slate-100 rounded-xl space-y-2">
            <div className="flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-purple-600" />
              <h4 className="text-sm font-bold text-slate-800">Risk Assessment Audits</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Conduct systematic walks across facilities. Record active hazards, fire extinguisher tags, and blocked pathways with the smart calculator.
            </p>
          </div>

          <div className="p-5 bg-slate-50 border border-slate-100 rounded-xl space-y-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h4 className="text-sm font-bold text-slate-800">Certified Compliance</h4>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Fully aligned with Federal Emergency Management standards, local department guidelines, and structural fire codes.
            </p>
          </div>
        </div>
      </div>

      {/* 5. Disaster Categories Section (With Interactive Expandable Quick Guide) */}
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight border-l-4 border-blue-700 pl-3">
              Standardized Disaster Categories
            </h2>
            <p className="text-xs text-slate-500">
              Click a primary disaster category to expand high-fidelity safety instructions and response checklists.
            </p>
          </div>
          <span className="text-[10px] bg-blue-50 text-blue-700 border border-blue-100 font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
            Click to interact & view checklist
          </span>
        </div>

        <div className="grid md:grid-cols-4 gap-4">
          {disasterCategories.map((category) => {
            const IconComponent = category.icon;
            const isSelected = selectedCategory === category.id;
            return (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`w-full text-left p-5 border rounded-xl transition-all ${
                  isSelected ? category.activeColor : category.color
                } shadow-xs cursor-pointer flex flex-col justify-between h-40 relative group`}
              >
                <div className="flex justify-between items-start w-full">
                  <div className="p-2.5 bg-white rounded-lg border border-slate-200/40">
                    <IconComponent className="w-5 h-5" />
                  </div>
                  {isSelected && (
                    <span className="text-[9px] font-bold bg-white text-slate-800 px-2 py-0.5 rounded-full uppercase border">
                      Active Guide
                    </span>
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-sm tracking-tight">{category.title}</h3>
                  <p className="text-[11px] opacity-80 mt-1 truncate">{category.tagline}</p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Category Expanded Cheat Sheet Panel */}
        {selectedCategory && (
          (() => {
            const cat = disasterCategories.find(c => c.id === selectedCategory);
            if (!cat) return null;
            const CatIcon = cat.icon;
            return (
              <div className="bg-white border border-slate-200 rounded-2xl p-6 md:p-8 shadow-sm grid md:grid-cols-12 gap-6 animate-fade-in">
                <div className="md:col-span-5 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-slate-50 border rounded-xl">
                      <CatIcon className="w-6 h-6 text-slate-800" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-lg text-slate-950">{cat.title}</h3>
                      <p className="text-xs text-blue-700 font-semibold">{cat.tagline}</p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {cat.description}
                  </p>
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span>Hazard Rating:</span>
                      <span className="font-bold text-slate-800">{cat.hazardRating}</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span>Drill Cycle:</span>
                      <span className="font-bold text-slate-800">{cat.drillFrequency}</span>
                    </div>
                  </div>
                </div>

                <div className="md:col-span-7 bg-slate-50 border border-slate-100 rounded-xl p-5 md:p-6 space-y-4">
                  <h4 className="text-xs font-black tracking-widest text-slate-500 uppercase">
                    Step-by-Step Response Checklist
                  </h4>
                  <ul className="space-y-2.5">
                    {cat.checklist.map((step, sIdx) => (
                      <li key={sIdx} className="flex gap-3 items-start text-xs text-slate-700">
                        <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-700 text-[10px] font-bold text-white">
                          {sIdx + 1}
                        </span>
                        <span className="leading-normal">{step}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="pt-2 text-[10px] text-slate-400 font-medium italic">
                    ⚠️ Note: Specific institutional campus structures may override general evacuation patterns. Check emergency signs in corridors.
                  </div>
                </div>
              </div>
            );
          })()
        )}
      </div>

      {/* 6. Features Section */}
      <div className="space-y-6">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight border-l-4 border-blue-700 pl-3">
          Interactive Emergency Toolkit Features
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {platformFeatures.map((feature, idx) => {
            const FeatureIcon = feature.icon;
            return (
              <div key={idx} className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col justify-between group hover:border-blue-300 transition-all">
                <div className="space-y-4">
                  <div className="p-3 bg-slate-50 border rounded-lg w-fit group-hover:bg-blue-50 group-hover:text-blue-700 transition-colors">
                    <FeatureIcon className="w-5 h-5 text-slate-700 group-hover:text-blue-700" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900">{feature.title}</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">{feature.desc}</p>
                </div>
                <div className="pt-6">
                  <button
                    onClick={() => onNavigate(feature.tab)}
                    className="w-full flex items-center justify-center gap-1 py-2 bg-slate-50 group-hover:bg-blue-700 border border-slate-200 group-hover:border-blue-700 text-slate-700 group-hover:text-white rounded text-[11px] font-bold uppercase transition-all cursor-pointer"
                  >
                    {feature.linkText} <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 7. Call-to-Action Section */}
      <div className="bg-slate-900 text-white rounded-2xl p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 left-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="space-y-3 z-10 max-w-2xl">
          <span className="text-[10px] font-black uppercase tracking-widest text-blue-400">
            Secure Enrollment Open
          </span>
          <h3 className="text-xl md:text-2xl font-extrabold tracking-tight">
            Earn your Official Disaster Responder badge today
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Take academic quizzes, achieve a 100% score on the seismic safety exams, complete risk audits, and unlock a downloadable, high-resolution ResponseEd platform certification.
          </p>
        </div>

        <div className="shrink-0 z-10 flex flex-wrap gap-3">
          <button 
            onClick={() => onNavigate('quiz')}
            className="px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-md"
          >
            Take Prep Exam
          </button>
          <button 
            onClick={() => onNavigate('resources')}
            className="px-5 py-3 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-bold rounded-lg text-xs uppercase tracking-wider transition-colors cursor-pointer"
          >
            Download Checklist Packets
          </button>
        </div>
      </div>

      {/* 8. Detailed Educational Compliance Footer */}
      <footer className="border-t border-slate-200 pt-8 mt-10 text-xs text-slate-500 space-y-6">
        <div className="grid md:grid-cols-4 gap-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-700 rounded-lg flex items-center justify-center text-white font-bold text-sm">
                DP
              </div>
              <span className="font-bold text-slate-800 uppercase text-xs">ResponseEd Hub</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Standardized Disaster Preparedness and Responsive Operations platform for secure campus safety automation.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-slate-700 text-[11px] uppercase tracking-wider mb-3">Response Tools</h4>
            <ul className="space-y-2 text-[11px]">
              <li><button onClick={() => onNavigate('modules')} className="hover:text-blue-700 transition-colors text-left cursor-pointer">Study Modules</button></li>
              <li><button onClick={() => onNavigate('simulator')} className="hover:text-blue-700 transition-colors text-left cursor-pointer">Crisis Simulator</button></li>
              <li><button onClick={() => onNavigate('assessment')} className="hover:text-blue-700 transition-colors text-left cursor-pointer">Risk Auditing</button></li>
              <li><button onClick={() => onNavigate('chatbot')} className="hover:text-blue-700 transition-colors text-left cursor-pointer">AI Helper</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-700 text-[11px] uppercase tracking-wider mb-3">Academic Guidelines</h4>
            <ul className="space-y-2 text-[11px]">
              <li><button onClick={() => onNavigate('resources')} className="hover:text-blue-700 transition-colors text-left cursor-pointer">Extinguisher PASS Protocol</button></li>
              <li><button onClick={() => onNavigate('resources')} className="hover:text-blue-700 transition-colors text-left cursor-pointer">Seismic Shelter Plans</button></li>
              <li><button onClick={() => onNavigate('resources')} className="hover:text-blue-700 transition-colors text-left cursor-pointer">Chemical Hazard Manuals</button></li>
              <li><button onClick={() => onNavigate('about')} className="hover:text-blue-700 transition-colors text-left cursor-pointer">Platform Security Architecture</button></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-slate-700 text-[11px] uppercase tracking-wider mb-2">Emergency Hotline Support</h4>
            <div className="bg-slate-900 text-white rounded-xl p-4 space-y-1.5 shadow-sm">
              <span className="text-[9px] font-black tracking-widest text-red-400 uppercase block">Urgent Action Line</span>
              <span className="text-base font-extrabold tracking-tight block">9-1-1 / 555-0199</span>
              <span className="text-[10px] text-slate-400 block leading-tight">Continuous campus police response dispatch line</span>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-200/60 pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] text-slate-400">
          <div className="flex flex-wrap gap-4 justify-center sm:justify-start">
            <span>Version 2.4.1</span>
            <span>•</span>
            <span>College District 09 Secure Link</span>
            <span>•</span>
            <span>Authorized Sandbox Node 88.01</span>
          </div>
          <div className="flex gap-4">
            <button onClick={() => onNavigate('about')} className="hover:text-blue-700 cursor-pointer">Privacy Charter</button>
            <span>•</span>
            <span>© 2024 ResponseEd International. All rights reserved.</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
