import React, { useState, useRef } from 'react';
import { UserProfile } from '../types';
import { 
  FileBadge, Award, Printer, ShieldAlert, CheckSquare, 
  Download, Lock, Info, CheckCircle, Calendar
} from 'lucide-react';

interface CertificateProps {
  user: UserProfile | null;
  onNavigate: (tab: string) => void;
}

export default function Certificate({ user, onNavigate }: CertificateProps) {
  const [studentName, setStudentName] = useState(user?.name || 'Alex Rivera');
  const [courseName, setCourseName] = useState('Disaster Preparedness and Campus Safety Core');
  const [forceUnlock, setForceUnlock] = useState(false);

  // Check if student has passed at least one quiz with 80%+
  const passedQuizzes = user 
    ? Object.keys(user.progress.completedQuizzes).filter(qid => user.progress.completedQuizzes[qid] >= 80)
    : [];
  const isEligible = passedQuizzes.length > 0 || forceUnlock;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadHTML = () => {
    const certId = `EDUSYS-77C${studentName.split(' ').map(n => n.charCodeAt(0) || 65).slice(0, 4).join('')}`;
    const timestamp = new Date().toLocaleDateString();
    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ResponseEd Certificate of Completion - ${studentName}</title>
  <style>
    body {
      background-color: #0b0f19;
      color: #f8fafc;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
      box-sizing: border-box;
    }
    .cert-container {
      background-color: #020617;
      border: 8px double rgba(245, 158, 11, 0.4);
      border-radius: 16px;
      padding: 50px 40px;
      max-width: 800px;
      width: 100%;
      text-align: center;
      position: relative;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
      box-sizing: border-box;
      margin-bottom: 24px;
    }
    .accent-top-left {
      position: absolute;
      top: 20px;
      left: 20px;
      width: 100px;
      height: 100px;
      border-left: 4px solid rgba(245, 158, 11, 0.2);
      border-top: 4px solid rgba(245, 158, 11, 0.2);
      border-top-left-radius: 12px;
    }
    .accent-bottom-right {
      position: absolute;
      bottom: 20px;
      right: 20px;
      width: 100px;
      height: 100px;
      border-right: 4px solid rgba(245, 158, 11, 0.2);
      border-bottom: 4px solid rgba(245, 158, 11, 0.2);
      border-bottom-right-radius: 12px;
    }
    .logo-seal {
      width: 64px;
      height: 64px;
      background-color: rgba(245, 158, 11, 0.1);
      border: 2px solid rgba(245, 158, 11, 0.3);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 20px auto;
    }
    .logo-seal-svg {
      width: 32px;
      height: 32px;
      color: #f59e0b;
    }
    .header-system {
      font-family: monospace;
      font-size: 14px;
      font-weight: 800;
      letter-spacing: 0.15em;
      color: #f59e0b;
      margin: 0 0 4px 0;
      text-transform: uppercase;
    }
    .header-sub {
      font-family: monospace;
      font-size: 9px;
      color: #64748b;
      margin: 0 0 32px 0;
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }
    .cert-title {
      font-family: Georgia, serif;
      font-style: italic;
      font-size: 14px;
      color: #94a3b8;
      margin: 0 0 16px 0;
    }
    .candidate-name {
      font-size: 36px;
      font-weight: 900;
      color: #f1f5f9;
      margin: 0 0 20px 0;
      text-decoration: underline;
      text-decoration-color: rgba(245, 158, 11, 0.5);
      text-decoration-style: wavy;
      text-decoration-thickness: 2px;
      text-underline-offset: 10px;
    }
    .cert-description {
      font-size: 13px;
      color: #94a3b8;
      max-width: 580px;
      margin: 0 auto 20px auto;
      line-height: 1.6;
    }
    .course-title {
      font-size: 18px;
      font-weight: 800;
      font-style: italic;
      color: #e2e8f0;
      margin: 0 0 24px 0;
    }
    .cert-footer-text {
      font-size: 13px;
      color: #94a3b8;
      margin-bottom: 40px;
    }
    .signatures-grid {
      border-top: 1px solid #1e293b;
      padding-top: 24px;
      display: grid;
      grid-template-columns: 1fr 100px 1fr;
      gap: 16px;
      align-items: flex-end;
      font-family: monospace;
      font-size: 11px;
    }
    .sig-left {
      text-align: left;
    }
    .sig-right {
      text-align: right;
    }
    .sig-title {
      color: #64748b;
      border-top: 1px solid #1e293b;
      padding-top: 4px;
      display: block;
      font-size: 10px;
      text-transform: uppercase;
      font-weight: bold;
      margin-top: 4px;
    }
    .sig-name {
      color: #94a3b8;
      font-family: Georgia, serif;
      font-style: italic;
    }
    .official-seal-dashed {
      width: 72px;
      height: 72px;
      border: 2px dashed rgba(245, 158, 11, 0.2);
      border-radius: 50%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: rgba(245, 158, 11, 0.4);
      font-size: 8px;
      font-weight: bold;
      margin: 0 auto;
    }
    .meta-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-family: monospace;
      font-size: 9px;
      color: #475569;
      border-top: 1px solid #1e293b;
      padding-top: 16px;
      margin-top: 32px;
    }
    .print-button {
      background-color: #f59e0b;
      color: #020617;
      border: none;
      padding: 12px 28px;
      font-size: 13px;
      font-weight: bold;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.2s, transform 0.1s;
      box-shadow: 0 10px 15px -3px rgba(245, 158, 11, 0.15);
    }
    .print-button:hover {
      background-color: #d97706;
      transform: translateY(-1px);
    }
    .print-button:active {
      transform: translateY(0);
    }
    @media print {
      .print-button {
        display: none;
      }
      body {
        background-color: white;
        color: black;
      }
      .cert-container {
        box-shadow: none;
        border-color: #ccc;
        background-color: white;
      }
      .candidate-name {
        color: black;
      }
      .course-title {
        color: black;
      }
    }
  </style>
</head>
<body>
  <div class="cert-container">
    <div class="accent-top-left"></div>
    <div class="accent-bottom-right"></div>
    <div class="logo-seal">
      <svg class="logo-seal-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 15l-2 5l2-1l2 1l-2-5z" />
        <circle cx="12" cy="10" r="7" />
      </svg>
    </div>
    <div class="header-system">DISASTER PREPAREDNESS & RESPONSE SYSTEM</div>
    <div class="header-sub">ACADEMIC SAFETY COUNCIL CERTIFICATION</div>
    
    <div class="cert-title">This certifies that safety candidate</div>
    <div class="candidate-name">${studentName}</div>
    <div class="cert-description">
      has successfully fulfilled all prerequisite educational modules, simulated hazard decision sandbox scenarios, and completed physical risk-assessment audits regarding
    </div>
    <div class="course-title">"${courseName}"</div>
    <div class="cert-footer-text">achieving full passing competency under institutional standards.</div>
    
    <div class="signatures-grid">
      <div class="sig-left">
        <span class="sig-name">Harold Vance</span>
        <span class="sig-title">Academic Chair</span>
      </div>
      <div class="official-seal-dashed">
        <span>OFFICIAL</span>
        <span>SECURITY</span>
        <span>SEAL</span>
      </div>
      <div class="sig-right">
        <span class="sig-name">Sarah Jenkins</span>
        <span class="sig-title">Safety Admin</span>
      </div>
    </div>
    
    <div class="meta-footer">
      <span>CERT-ID: ${certId}</span>
      <span>DATE ISSUED: ${timestamp}</span>
      <span>VERIFICATION STAMP: 2026-ACTIVE</span>
    </div>
  </div>
  <button class="print-button" onclick="window.print()">Print / Save PDF</button>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ResponseEd_Certificate_${studentName.replace(/\s+/g, '_')}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-3xl mx-auto">
      
      {/* Printable Area Styles */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #printable-cert, #printable-cert * {
            visibility: visible;
          }
          #printable-cert {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            border: none;
            background: white !important;
            color: black !important;
          }
          #printable-cert .text-slate-400 {
            color: #4a5568 !important;
          }
          #printable-cert .bg-slate-950 {
            background: #f7fafc !important;
            border-color: #cbd5e0 !important;
          }
        }
      `}</style>

      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl font-extrabold text-slate-100 tracking-tight flex items-center gap-2">
            <FileBadge className="w-6 h-6 text-amber-500" />
            Safety Credentials <span className="text-amber-500">Center</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Unlock printable, high-fidelity security completion certificates to append to your academic and student portfolio.
          </p>
        </div>
        {!isEligible && (
          <button 
            onClick={() => setForceUnlock(true)}
            className="text-[10px] font-mono uppercase bg-slate-950 border border-slate-850 hover:border-slate-700 text-slate-400 hover:text-amber-500 p-2 rounded shrink-0 transition-all cursor-pointer"
          >
            🔓 Bypass Prerequisites for Demo
          </button>
        )}
      </div>

      {!isEligible ? (
        /* Locked Screen */
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center space-y-4 max-w-md mx-auto">
          <Lock className="w-12 h-12 text-slate-600 mx-auto animate-pulse" />
          <h3 className="font-bold text-slate-100 text-sm">Credentials Locked</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            You must pass at least one Safety Competency Quiz with a score of 80% or greater to generate your digital safety certificate.
          </p>
          <div className="pt-2 flex justify-center gap-3">
            <button
              onClick={() => onNavigate('quiz')}
              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2 px-4 rounded text-xs transition-colors cursor-pointer"
            >
              Take Safety Quiz
            </button>
          </div>
        </div>
      ) : (
        /* Certificate Preview & Controls */
        <div className="space-y-6">
          
          {/* Settings Customizer Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-1.5 text-xs text-slate-400 pl-1 uppercase font-mono tracking-widest border-b border-slate-850 pb-2.5">
              <Info className="w-4 h-4 text-amber-500" />
              <span>Customize Certificate Details</span>
            </div>
            
            <div className="grid sm:grid-cols-3 gap-4 text-xs">
              <div className="space-y-1.5">
                <label className="text-slate-400 font-medium">Recipient Student Name</label>
                <input 
                  type="text"
                  value={studentName}
                  onChange={e => setStudentName(e.target.value)}
                  placeholder="Enter custom name"
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-semibold"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-slate-400 font-medium font-mono">Select Certified Course</label>
                <select 
                  onChange={e => {
                    if (e.target.value) {
                      setCourseName(e.target.value);
                    }
                  }}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-semibold"
                >
                  <option value="Disaster Preparedness and Campus Safety Core">-- Select Preset Course --</option>
                  <option value="Disaster Preparedness: Earthquake Survival & Evacuation">Earthquake Survival & Evacuation</option>
                  <option value="Hydrological Hazards: Flood Mitigation & Emergency Preparedness">Flood Mitigation & Preparedness</option>
                  <option value="Biosafety and Chemical Fire Containment Protocols">Biosafety & Fire Lab Protocols</option>
                  <option value="Active Threat Readiness: Campus Lockdown Procedures">Active Threat & Lockdown Procedures</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-slate-400 font-medium">Or Enter Custom Course Title</label>
                <input 
                  type="text"
                  value={courseName}
                  onChange={e => setCourseName(e.target.value)}
                  placeholder="Enter custom course title"
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-semibold"
                />
              </div>
            </div>
          </div>

          {/* High Fidelity Visual Certificate Card */}
          <div 
            id="printable-cert"
            className="bg-slate-950 border-8 border-double border-amber-500/40 rounded-2xl p-6 md:p-12 relative overflow-hidden text-center space-y-8 select-none shadow-2xl"
          >
            {/* Visual background accents */}
            <div className="absolute inset-0 bg-gradient-to-br from-amber-500/[0.01] to-orange-500/[0.01] pointer-events-none" />
            <div className="absolute top-0 left-0 w-32 h-32 border-l-4 border-t-4 border-amber-500/20 m-6 rounded-tl-xl" />
            <div className="absolute bottom-0 right-0 w-32 h-32 border-r-4 border-b-4 border-amber-500/20 m-6 rounded-br-xl" />

            {/* Top Logo / Seal Header */}
            <div className="space-y-2">
              <div className="mx-auto w-16 h-16 bg-amber-500/10 border-2 border-amber-500/30 rounded-full flex items-center justify-center text-amber-500">
                <Award className="w-8 h-8 text-amber-500" />
              </div>
              <h2 className="text-xs font-mono font-extrabold uppercase tracking-widest text-amber-500">
                DISASTER PREPAREDNESS & RESPONSE SYSTEM
              </h2>
              <p className="text-[9px] text-slate-500 font-mono">ACADEMIC SAFETY COUNCIL CERTIFICATION</p>
            </div>

            {/* Cert Body */}
            <div className="space-y-4">
              <p className="text-[11px] text-slate-400 font-serif italic">This certifies that safety candidate</p>
              <h1 className="text-2xl md:text-3xl font-black text-slate-100 tracking-tight underline decoration-amber-500 decoration-wavy decoration-2 underline-offset-8">
                {studentName}
              </h1>
              <p className="text-[11px] text-slate-400 max-w-lg mx-auto leading-relaxed pt-2">
                has successfully fulfilled all prerequisite educational modules, simulated hazard decision sandbox scenarios, and completed physical risk-assessment audits regarding
              </p>
              <h3 className="font-extrabold text-slate-200 text-sm italic tracking-tight pt-1">
                "{courseName}"
              </h3>
              <p className="text-[11px] text-slate-400">
                achieving full passing competency under institutional standards.
              </p>
            </div>

            {/* Footer Signatures */}
            <div className="border-t border-slate-900 pt-6 grid grid-cols-3 gap-4 items-end text-[10px] font-mono">
              <div className="space-y-1 text-left">
                <span className="text-slate-400 block font-serif italic">Harold Vance</span>
                <span className="text-slate-500 border-t border-slate-900 pt-1 block text-[9px] uppercase font-bold">Academic Chair</span>
              </div>
              <div className="flex justify-center shrink-0">
                {/* Visual Seal */}
                <div className="w-16 h-16 border-2 border-dashed border-amber-500/20 rounded-full flex flex-col items-center justify-center text-amber-500/40 text-[7px] font-bold">
                  <span>OFFICIAL</span>
                  <span>SECURITY</span>
                  <span>SEAL</span>
                </div>
              </div>
              <div className="space-y-1 text-right">
                <span className="text-slate-400 block font-serif italic">Sarah Jenkins</span>
                <span className="text-slate-500 border-t border-slate-900 pt-1 block text-[9px] uppercase font-bold">Safety Admin</span>
              </div>
            </div>

            {/* Validation footer meta */}
            <div className="flex justify-between items-center text-[8px] font-mono text-slate-600 border-t border-slate-900 pt-4">
              <span>CERT-ID: EDUSYS-77C{user?.name ? user.name.charCodeAt(0) : 'A'}</span>
              <span>VERIFICATION STAMP: 2026-ACTIVE</span>
            </div>

          </div>

          {/* Download Action Buttons */}
          <div className="flex flex-col sm:flex-row justify-center gap-3">
            <button
              onClick={handlePrint}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-100 font-bold py-2.5 px-6 rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
            >
              <Printer className="w-4 h-4 text-amber-500" /> Print / Save as PDF
            </button>
            <button
              onClick={handleDownloadHTML}
              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2.5 px-6 rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-lg shadow-amber-500/10"
            >
              <Download className="w-4 h-4" /> Download Standalone HTML Certificate
            </button>
          </div>

        </div>
      )}
    </div>
  );
}
