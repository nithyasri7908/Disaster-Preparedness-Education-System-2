import React, { useState } from 'react';
import { RISK_ASSESSMENT_ITEMS } from '../data/safetyData';
import { RiskAssessmentItem, UserProfile } from '../types';
import { 
  ShieldAlert, CheckSquare, AlertTriangle, Play, CheckCircle, Check,
  RefreshCw, Info, ClipboardCheck, ArrowRight, ShieldCheck, Trophy,
  FileText, Download, Building, Users, MapPin, Activity, FileCheck, 
  Volume2, Briefcase, HeartPulse, ChevronRight, AlertCircle, HelpCircle
} from 'lucide-react';

interface RiskAssessmentProps {
  user: UserProfile | null;
  onAuditSubmit: () => void;
  onUnlockBadge: (badgeId: string) => void;
  onNavigate: (tab: string) => void;
}

interface CustomRiskItem extends RiskAssessmentItem {
  priority: 'Critical' | 'High' | 'Medium';
  department: string;
  cost: 'Low' | 'Medium' | 'High';
  timeline: string;
}

export default function RiskAssessment({ user, onAuditSubmit, onUnlockBadge, onNavigate }: RiskAssessmentProps) {
  // Stage state: 'setup' | 'audit' | 'report'
  const [stage, setStage] = useState<'setup' | 'audit' | 'report'>('setup');
  
  // Setup inputs
  const [schoolName, setSchoolName] = useState(user?.school || 'Lincoln High School');
  const [assessorName, setAssessorName] = useState(user?.name || 'Alex Rivera');
  const [assessorRole, setAssessorRole] = useState(user?.role || 'student');
  const [schoolSize, setSchoolSize] = useState('500-1000');
  const [locationType, setLocationType] = useState('Urban');
  const [selectedHazards, setSelectedHazards] = useState<string[]>(['Earthquake', 'Fire']);

  // Active Audit Category Step
  const [activeStep, setActiveStep] = useState<number>(0);

  // Store response state. Key is item ID, value is 'full' (fully compliant), 'partial' (partial), or 'none' (non-compliant)
  const [responses, setResponses] = useState<{ [id: string]: 'full' | 'partial' | 'none' }>({});
  
  // Help tooltip states
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);

  // Detailed 12-Question Database (Combining the 6 original ones + 6 comprehensive institutional ones)
  const allAssessmentItems: CustomRiskItem[] = [
    // 1. Core items from RISK_ASSESSMENT_ITEMS (mapped with extra info for high-fidelity recommendations)
    {
      id: 'risk-1',
      category: 'Structural',
      question: 'Are tall classroom bookshelves, filing cabinets, and heavy display boards bolted securely to structural studs/walls?',
      hazardDescription: 'Unsecured tall furniture will topple instantly during seismic shaking, causing severe crushing injuries and blocking egress corridors.',
      mitigationTip: 'Install heavy-duty L-brackets or nylon straps on all cabinets exceeding 4 feet in height.',
      score: 15,
      priority: 'High',
      department: 'Facilities & Maintenance',
      cost: 'Low',
      timeline: 'Within 30 Days'
    },
    {
      id: 'risk-2',
      category: 'Non-Structural',
      question: 'Are all exit doors, corridors, and fire stairs entirely clear of furniture, backpacks, or student storage crates?',
      hazardDescription: 'Obstructed evacuation routes cause high-density bottlenecking, trips, and severe delays when exiting a darkened, smoke-filled structure.',
      mitigationTip: 'Establish a strict campus-wide hallway clearance policy; provide designated locker bays for heavy bags.',
      score: 20,
      priority: 'Critical',
      department: 'School Administration & Staff',
      cost: 'Low',
      timeline: 'Immediate (24 hours)'
    },
    {
      id: 'risk-3',
      category: 'Operational',
      question: 'Are campus fire extinguishers inspected monthly, fully charged (indicator pin in the green zone), and easily accessible?',
      hazardDescription: 'Uncharged or blocked fire extinguishers prevent staff from suppressing small trash can or laboratory electrical fires before they spread.',
      mitigationTip: 'Appoint floor safety wardens to log monthly audits on physical inspection tags hanging on each extinguisher.',
      score: 15,
      priority: 'Critical',
      department: 'Health & Safety Committee',
      cost: 'Low',
      timeline: 'Immediate (24 hours)'
    },
    {
      id: 'risk-4',
      category: 'Operational',
      question: 'Does the school display clear emergency exit floorplan maps and assembly instructions next to every room\'s exit door?',
      hazardDescription: 'Without maps, substitute teachers, guests, or panicked students will lose orientation and move in the wrong direction during high-stress alerts.',
      mitigationTip: 'Laminate and bolt high-contrast map visual sheets exactly at eye level near every classroom door latch.',
      score: 15,
      priority: 'High',
      department: 'Facilities & Maintenance',
      cost: 'Medium',
      timeline: 'Within 15 Days'
    },
    {
      id: 'risk-5',
      category: 'Environmental',
      question: 'Are chemical reactants in science laboratories stored on low, secure cabinets containing raised edge guards or lips?',
      hazardDescription: 'Shattered laboratory glass on high open shelves leads to hazardous toxic vapor mixtures, acid burns, and rapid ignition sources during earthquakes.',
      mitigationTip: 'Use plastic secondary storage containment trays and lock chemical cabinets with child-proof safety latches.',
      score: 20,
      priority: 'High',
      department: 'Science Department Faculty',
      cost: 'Low',
      timeline: 'Within 7 Days'
    },
    {
      id: 'risk-6',
      category: 'Environmental',
      question: 'Is the campus main power grid and computer servers supported by operational surge protectors and emergency generator supplies?',
      hazardDescription: 'Immediate power cuts leave crucial hallways, emergency exits, and intercom PA grids dark and non-communicative.',
      mitigationTip: 'Perform bi-monthly testing of the automatic diesel generators and verify backup battery systems on emergency PA horns.',
      score: 15,
      priority: 'Medium',
      department: 'IT & Facilities Operations',
      cost: 'High',
      timeline: 'Within 60 Days'
    },
    // 2. Additional Expanded Institutional Items
    {
      id: 'risk-7',
      category: 'Operational',
      question: 'Are explicit emergency response roles (e.g., Incident Commander, First-Aid Lead, Search Team) assigned to designated school staff?',
      hazardDescription: 'Lacking clear command hierarchy results in extreme administrative confusion, delayed response times, and failure to account for all building occupants.',
      mitigationTip: 'Implement the Incident Command System (ICS), distribute role vests, and conduct focused emergency leadership workshops.',
      score: 15,
      priority: 'High',
      department: 'School Administration',
      cost: 'Low',
      timeline: 'Within 30 Days'
    },
    {
      id: 'risk-8',
      category: 'Operational',
      question: 'Are campus-wide emergency evacuation drills (earthquake, fire, storm, threat) conducted and formally evaluated at least once per semester?',
      hazardDescription: 'Infrequent training leads to slow, panicked evacuation times, non-adherence to critical protocols, and high failure rates in actual crises.',
      mitigationTip: 'Schedule semesterly drill audits, record completion speeds, and log lessons learned inside the safety database.',
      score: 20,
      priority: 'Critical',
      department: 'Health & Safety Committee',
      cost: 'Low',
      timeline: 'Immediate (Active School Calendar)'
    },
    {
      id: 'risk-9',
      category: 'Non-Structural',
      question: 'Are large classroom glass window panels and double-door panes protected with safety glazing or shatter-resistant laminates?',
      hazardDescription: 'Shaking or high wind loads will fracture standard window panels into heavy, high-velocity razor shards, causing severe lacerations to nearby occupants.',
      mitigationTip: 'Apply defensive micro-thin safety window film to all structural exterior-facing glass portals.',
      score: 15,
      priority: 'Medium',
      department: 'Facilities & Maintenance',
      cost: 'High',
      timeline: 'Within 90 Days'
    },
    {
      id: 'risk-10',
      category: 'Operational',
      question: 'Is there an independent, battery-backed campus siren or PA system capable of reaching all indoor and outdoor areas?',
      hazardDescription: 'If power grids fail, standard intercoms go dead, rendering it impossible to issue vital warnings, sheltering alerts, or evacuation directives.',
      mitigationTip: 'Install dual-powered battery-backup siren horns in hallways, playgrounds, and remote sports fields.',
      score: 15,
      priority: 'High',
      department: 'IT & Facilities Operations',
      cost: 'Medium',
      timeline: 'Within 45 Days'
    },
    {
      id: 'risk-11',
      category: 'Structural',
      question: 'Are water, natural gas, and electricity pipelines equipped with rapid, clearly-marked manual shutoff valves accessible to key staff?',
      hazardDescription: 'Ruptured utility conduits can flood structures, trigger gas explosions, or electrocute occupants during or after earthquakes or storm breaches.',
      mitigationTip: 'Install high-visibility placards at shutoff locations and supply safety wrenches inside emergency command boxes.',
      score: 20,
      priority: 'Critical',
      department: 'Facilities & Maintenance',
      cost: 'Medium',
      timeline: 'Within 15 Days'
    },
    {
      id: 'risk-12',
      category: 'Non-Structural',
      question: 'Are dedicated trauma first-aid responders designated and equipped with fully-stocked medical response backpacks in each wing?',
      hazardDescription: 'Severe bleeding or respiratory blockages can become fatal in minutes. Waiting for city ambulances during disaster gridlock is extremely risky.',
      mitigationTip: 'Deploy bleeding control tactical packs (gauze, tourniquets, chest seals) to certified safety wardens across campus wings.',
      score: 20,
      priority: 'Critical',
      department: 'Health & Safety Committee',
      cost: 'Medium',
      timeline: 'Within 7 Days'
    }
  ];

  // Group items by Category for multi-step rendering
  const categories = [
    { name: 'Structural & Physical', items: allAssessmentItems.filter(i => i.category === 'Structural') },
    { name: 'Non-Structural & Exit', items: allAssessmentItems.filter(i => i.category === 'Non-Structural') },
    { name: 'Operational & Command', items: allAssessmentItems.filter(i => i.category === 'Operational') },
    { name: 'Environmental & Utilities', items: allAssessmentItems.filter(i => i.category === 'Environmental') }
  ];

  const handleHazardToggle = (hazard: string) => {
    setSelectedHazards(prev => 
      prev.includes(hazard) ? prev.filter(h => h !== hazard) : [...prev, hazard]
    );
  };

  const handleResponseChange = (itemId: string, value: 'full' | 'partial' | 'none') => {
    setResponses(prev => ({
      ...prev,
      [itemId]: value
    }));
  };

  // Math calculation logic
  const calculateResults = () => {
    let totalMaxScore = 0;
    let totalEarnedScore = 0;

    allAssessmentItems.forEach(item => {
      const response = responses[item.id] || 'none';
      totalMaxScore += item.score;
      if (response === 'full') {
        totalEarnedScore += item.score;
      } else if (response === 'partial') {
        totalEarnedScore += item.score * 0.5; // 50% score for partial compliance
      }
    });

    const percentScore = Math.round((totalEarnedScore / totalMaxScore) * 100);
    return {
      score: percentScore,
      maxPoints: totalMaxScore,
      earnedPoints: totalEarnedScore
    };
  };

  const { score: finalScore, earnedPoints, maxPoints } = calculateResults();

  const handleSubmitAssessment = () => {
    setStage('report');
    onAuditSubmit();
    onUnlockBadge('Audit Champion');
    
    // Log report in localStorage for Admin Dashboard
    try {
      const reports = JSON.parse(localStorage.getItem('responseed_reports') || '[]');
      const newReport = {
        id: `report-${Date.now()}`,
        schoolName,
        assessorName,
        assessorRole,
        finalScore,
        date: new Date().toLocaleDateString(),
        priorityBreakdown: {
          critical: compileRecommendations().filter(r => r.priority === 'Critical').length,
          high: compileRecommendations().filter(r => r.priority === 'High').length,
          medium: compileRecommendations().filter(r => r.priority === 'Medium').length,
        },
        responses: responses,
        recommendations: compileRecommendations().map(r => ({
          question: r.question,
          category: r.category,
          status: r.responseStatus,
          tip: r.mitigationTip,
          priority: r.priority,
          department: r.department
        }))
      };
      reports.unshift(newReport);
      localStorage.setItem('responseed_reports', JSON.stringify(reports));
    } catch (e) {
      console.error("Failed to log report in localStorage:", e);
    }
  };

  const handleResetAssessment = () => {
    setResponses({});
    setStage('setup');
    setActiveStep(0);
  };

  // Recommendations compiler based on answers
  const compileRecommendations = () => {
    return allAssessmentItems
      .filter(item => (responses[item.id] || 'none') !== 'full')
      .map(item => {
        const responseValue = responses[item.id] || 'none';
        return {
          ...item,
          responseStatus: responseValue,
          customRecommendation: responseValue === 'partial' 
            ? `Optimize and fully formalize ongoing operations: ${item.mitigationTip}`
            : `Critical Deficiency: ${item.mitigationTip} Review corresponding safety literature to implement immediate safeguards.`
        };
      })
      .sort((a, b) => {
        const priorityWeight = { 'Critical': 3, 'High': 2, 'Medium': 1 };
        return priorityWeight[b.priority] - priorityWeight[a.priority];
      });
  };

  const recommendations = compileRecommendations();

  // Category Score Breakdowns
  const getCategoryScoreBreakdown = (catName: 'Structural' | 'Non-Structural' | 'Operational' | 'Environmental') => {
    const catItems = allAssessmentItems.filter(i => i.category === catName);
    let catMax = 0;
    let catEarned = 0;
    catItems.forEach(item => {
      catMax += item.score;
      const resp = responses[item.id] || 'none';
      if (resp === 'full') catEarned += item.score;
      else if (resp === 'partial') catEarned += item.score * 0.5;
    });
    return {
      earned: catEarned,
      max: catMax,
      percent: Math.round((catEarned / catMax) * 100) || 0
    };
  };

  // Plain text audit sheet generation & download simulation
  const handleExportReport = () => {
    const timestamp = new Date().toLocaleString();
    let text = `========================================================================\n`;
    text += `             OFFICIAL CAMPUS DISASTER RISK ASSESSMENT REPORT            \n`;
    text += `========================================================================\n\n`;
    text += `DATE COMPLIANCE FILED: ${timestamp}\n`;
    text += `INSTITUTIONAL NAME:    ${schoolName}\n`;
    text += `ASSESSOR NAME:         ${assessorName}\n`;
    text += `ASSESSOR ROLE:         ${assessorRole.toUpperCase()}\n`;
    text += `SCHOOL SIZE:           ${schoolSize} students & staff\n`;
    text += `LOCATION PROFILE:      ${locationType}\n`;
    text += `PRIMARY HAZARD FOCUS:  ${selectedHazards.join(', ')}\n\n`;
    text += `------------------------------------------------------------------------\n`;
    text += `                         COMPLIANCE SUMMARY                             \n`;
    text += `------------------------------------------------------------------------\n`;
    text += `OVERALL PREPAREDNESS SCORE:  ${finalScore} / 100\n`;
    text += `COMPLIANCE CLASSIFICATION:   ${
      finalScore >= 90 ? 'Class-A: Pristine Safety Standards' :
      finalScore >= 75 ? 'Class-B: Satisfactory Readiness' :
      finalScore >= 50 ? 'Class-C: Elevated Hazards' :
      'Class-D: Severe Safety Violations'
    }\n\n`;
    
    text += `CATEGORY COMPLIANCE METRICS:\n`;
    text += ` - Structural & Physical:      ${getCategoryScoreBreakdown('Structural').percent}%\n`;
    text += ` - Non-Structural & Exit:      ${getCategoryScoreBreakdown('Non-Structural').percent}%\n`;
    text += ` - Operational & Command:      ${getCategoryScoreBreakdown('Operational').percent}%\n`;
    text += ` - Environmental & Utilities:  ${getCategoryScoreBreakdown('Environmental').percent}%\n\n`;

    text += `------------------------------------------------------------------------\n`;
    text += `                   MITIGATION & ACTIONS CHECKLIST                       \n`;
    text += `------------------------------------------------------------------------\n`;
    if (recommendations.length === 0) {
      text += `CONGRATULATIONS! Your educational facility complies with all standard safety guidelines. No pending recommendations detected.\n`;
    } else {
      recommendations.forEach((rec, idx) => {
        text += `${idx + 1}. [${rec.priority.toUpperCase()} PRIORITY] - ${rec.question}\n`;
        text += `   - STATUS:             ${rec.responseStatus === 'partial' ? 'PARTIALLY COMPLIANT' : 'NON-COMPLIANT'}\n`;
        text += `   - MITIGATION ACTION:  ${rec.customRecommendation}\n`;
        text += `   - RESPONSIBLE PARTY:  ${rec.department}\n`;
        text += `   - BUDGET EFFORT:      ${rec.cost}\n`;
        text += `   - RECTIFICATION PLAN: ${rec.timeline}\n\n`;
      });
    }

    text += `========================================================================\n`;
    text += `          Report compiled by ResponseEd Disaster Preparedness          \n`;
    text += `========================================================================\n`;

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ResponseEd_Risk_Report_${schoolName.replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const activeCategory = categories[activeStep];

  return (
    <div className="space-y-8 animate-fade-in max-w-4xl mx-auto px-1 md:px-4">
      
      {/* HEADER DECK */}
      <div id="risk-header" className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="absolute inset-0 bg-amber-600/[0.015] animate-pulse pointer-events-none" />
        
        <div className="space-y-3 max-w-xl text-center md:text-left z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full text-[10px] md:text-xs font-bold text-amber-400">
            <ShieldAlert className="w-4 h-4 animate-bounce" />
            CAMPUS DISASTER AUDIT ENGINE
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-white tracking-tight leading-none">
            School Disaster <span className="text-amber-400">Risk Assessment</span>
          </h1>
          <p className="text-xs text-slate-400 leading-relaxed">
            Diagnose structural vulnerabilities, inspect active alert systems, evaluate staff drill histories, and compile an official certified mitigation roadmap.
          </p>
        </div>

        <div className="bg-slate-950/80 border border-slate-800 p-4 rounded-2xl flex items-center gap-3 shrink-0 z-10 text-xs text-slate-400">
          <ClipboardCheck className="w-10 h-10 text-amber-400 shrink-0" />
          <div className="font-mono text-left">
            <div className="text-[10px] uppercase text-slate-500 tracking-wider">Audit Protocol</div>
            <div className="text-slate-200 font-bold">FEMA-154 Compliant</div>
            <div className="text-[9px] text-amber-400/90 font-bold">12-Point Analysis</div>
          </div>
        </div>
      </div>

      {/* ==========================================
          STAGE 1: SETUP PANEL
          ========================================== */}
      {stage === 'setup' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 space-y-8 shadow-sm animate-fade-in">
          <div className="space-y-2 border-b border-slate-100 pb-4">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
              <Building className="w-5 h-5 text-blue-700" />
              1. Institutional Profiling Setup
            </h3>
            <p className="text-xs text-slate-500">
              Provide basic institutional statistics and roles to customize the risk multipliers and focus criteria of the audit questionnaire.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block font-bold">ASSESSOR NAME</label>
              <input
                type="text"
                value={assessorName}
                onChange={(e) => setAssessorName(e.target.value)}
                placeholder="Enter assessor name"
                className="w-full text-xs p-3.5 border border-slate-200 bg-slate-50 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block font-bold">SCHOOL NAME / FACILITY ID</label>
              <input
                type="text"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                placeholder="Lincoln High School"
                className="w-full text-xs p-3.5 border border-slate-200 bg-slate-50 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block font-bold">YOUR ROLE / TITLE</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { role: 'student', label: '🎓 Student' },
                  { role: 'teacher', label: '👩‍🏫 Teacher' },
                  { role: 'admin', label: '🛡️ Admin' },
                  { role: 'safety', label: '🦺 Inspector' }
                ].map((item) => (
                  <button
                    key={item.role}
                    type="button"
                    onClick={() => setAssessorRole(item.role)}
                    className={`py-2 px-3 border rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                      assessorRole === item.role 
                        ? 'bg-blue-50 text-blue-700 border-blue-300 shadow-sm' 
                        : 'bg-transparent text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block font-bold">CAMPUS POPULATION SIZE</label>
              <select
                value={schoolSize}
                onChange={(e) => setSchoolSize(e.target.value)}
                className="w-full text-xs p-3.5 border border-slate-200 bg-slate-50 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer"
              >
                <option value="1-200">Tiny (Under 200 Students)</option>
                <option value="200-500">Compact (200 - 500 Students)</option>
                <option value="500-1000">Medium (500 - 1000 Students)</option>
                <option value="1000-2500">Large (1000 - 2500 Students)</option>
                <option value="2500+">Mega (Over 2500 Students)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block font-bold">LOCATION PROFILE TYPE</label>
              <select
                value={locationType}
                onChange={(e) => setLocationType(e.target.value)}
                className="w-full text-xs p-3.5 border border-slate-200 bg-slate-50 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer"
              >
                <option value="Urban">🏙️ Urban (High Density, High Rise, Traffic gridlock potential)</option>
                <option value="Suburb">🏡 Suburban (Medium Density, Low Rise campus structures)</option>
                <option value="Coastal">🌊 Coastal (High Risk of Tsunamis, Floods, and Cyclones)</option>
                <option value="Rural">⛰️ Rural / Isolated (Heavy response time delay risk)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block font-bold">PRIMARY ENVIRONMENTAL HAZARD CONCERNS</label>
              <div className="flex flex-wrap gap-2">
                {['Earthquake', 'Flooding', 'Tornado / High Wind', 'Fire Outbreaks', 'Active Physical Threat'].map(hazard => {
                  const active = selectedHazards.includes(hazard);
                  return (
                    <button
                      key={hazard}
                      type="button"
                      onClick={() => handleHazardToggle(hazard)}
                      className={`text-[10px] py-1.5 px-3 rounded-full border font-mono transition-all cursor-pointer ${
                        active 
                          ? 'bg-amber-100 text-amber-800 border-amber-300 font-bold' 
                          : 'bg-transparent text-slate-500 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {hazard} {active ? '✓' : '+'}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              Your data will be processed server-side to generate local safety compliance metrics.
            </div>
            <button
              onClick={() => setStage('audit')}
              className="bg-blue-700 hover:bg-blue-800 text-white font-bold py-3.5 px-6 rounded-2xl text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-lg shadow-blue-700/10 uppercase"
            >
              Start Risk Assessment <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ==========================================
          STAGE 2: STEP-BY-STEP QUESTIONNAIRE
          ========================================== */}
      {stage === 'audit' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 space-y-6 shadow-sm animate-fade-in relative">
          
          {/* Progress Tracker bar */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-mono uppercase text-slate-400 font-bold">Audit Progress: {activeStep + 1} of {categories.length} Steps</span>
              <span className="text-blue-700 font-bold">{activeCategory.name}</span>
            </div>
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden flex">
              {categories.map((_, idx) => (
                <div 
                  key={idx} 
                  className={`h-full flex-1 transition-all ${
                    idx <= activeStep ? 'bg-blue-700' : 'bg-slate-100 border-l border-white'
                  }`} 
                />
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
                <ClipboardCheck className="w-5 h-5 text-blue-700" />
                {activeCategory.name} Category Assessment
              </h3>
              <span className="text-[10px] font-mono font-bold uppercase bg-slate-100 text-slate-500 px-2 py-0.5 rounded">
                Score Weight: 35-50 pts
              </span>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              Verify your physical school facility, classrooms, and policy plans against each parameter. Choose the compliance score level that strictly applies to your school.
            </p>

            {/* List of active category items */}
            <div className="space-y-6 pt-2">
              {activeCategory.items.map((item, index) => {
                const activeResponse = responses[item.id] || 'none';
                return (
                  <div key={item.id} className="p-5 border border-slate-100 rounded-2xl bg-slate-50/50 space-y-4 transition-all hover:border-slate-200 hover:bg-white hover:shadow-sm">
                    
                    {/* Header: Question Text */}
                    <div className="flex gap-3 items-start justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[9px] font-bold text-blue-700 uppercase bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                            Item {activeStep * 3 + index + 1}
                          </span>
                          <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase">
                            Category: {item.category}
                          </span>
                        </div>
                        <h4 className="text-xs md:text-sm font-bold text-slate-900 leading-relaxed">
                          {item.question}
                        </h4>
                      </div>

                      {/* Tooltip triggers */}
                      <button 
                        type="button"
                        onClick={() => setActiveTooltip(activeTooltip === item.id ? null : item.id)}
                        className="p-1 text-slate-400 hover:text-blue-700 hover:bg-slate-100 rounded-lg transition-all shrink-0 cursor-pointer"
                        title="View Associated Hazard Details"
                      >
                        <HelpCircle className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Expansive Hazard Explanation Drawer on trigger */}
                    {activeTooltip === item.id && (
                      <div className="bg-amber-50/70 border border-amber-200/50 p-4 rounded-xl text-[11px] leading-relaxed text-amber-900 space-y-2 animate-fade-in font-sans">
                        <div className="font-bold flex items-center gap-1.5 uppercase text-[9px] text-amber-800 tracking-wider font-mono">
                          <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                          Risk Vulnerability Explanation
                        </div>
                        <p className="text-slate-700">{item.hazardDescription}</p>
                        <div className="text-[10px] font-mono text-amber-800">
                          <strong>Weight Value:</strong> {item.score} Points Deducted for Non-Compliance.
                        </div>
                      </div>
                    )}

                    {/* Interactive Answer Level Choices */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      
                      {/* Full Compliance */}
                      <button
                        type="button"
                        onClick={() => handleResponseChange(item.id, 'full')}
                        className={`p-3 border rounded-xl flex items-center gap-2.5 transition-all cursor-pointer text-left ${
                          activeResponse === 'full'
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-950 font-bold'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                          activeResponse === 'full' ? 'border-emerald-600 bg-emerald-600 text-white' : 'border-slate-300'
                        }`}>
                          {activeResponse === 'full' && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-[11px] leading-tight">🟢 Fully Compliant</div>
                          <div className="text-[9px] text-slate-400 leading-none mt-0.5">Meets FEMA safety guidelines</div>
                        </div>
                      </button>

                      {/* Partial Compliance */}
                      <button
                        type="button"
                        onClick={() => handleResponseChange(item.id, 'partial')}
                        className={`p-3 border rounded-xl flex items-center gap-2.5 transition-all cursor-pointer text-left ${
                          activeResponse === 'partial'
                            ? 'bg-amber-500/10 border-amber-500/30 text-amber-950 font-bold'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                          activeResponse === 'partial' ? 'border-amber-600 bg-amber-600 text-white' : 'border-slate-300'
                        }`}>
                          {activeResponse === 'partial' && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-[11px] leading-tight">🟡 Partially/In Progress</div>
                          <div className="text-[9px] text-slate-400 leading-none mt-0.5">Plans drafted but incomplete</div>
                        </div>
                      </button>

                      {/* Non-Compliance */}
                      <button
                        type="button"
                        onClick={() => handleResponseChange(item.id, 'none')}
                        className={`p-3 border rounded-xl flex items-center gap-2.5 transition-all cursor-pointer text-left ${
                          activeResponse === 'none'
                            ? 'bg-red-500/10 border-red-500/30 text-red-950 font-bold'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                          activeResponse === 'none' ? 'border-red-600 bg-red-600 text-white' : 'border-slate-300'
                        }`}>
                          {activeResponse === 'none' && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-[11px] leading-tight">🔴 Non-Compliant / No</div>
                          <div className="text-[9px] text-slate-400 leading-none mt-0.5">Unprepared structural hazard</div>
                        </div>
                      </button>

                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Navigation Controls inside Questionnaire */}
          <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
            <button
              onClick={() => activeStep > 0 ? setActiveStep(activeStep - 1) : setStage('setup')}
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 px-5 rounded-2xl text-xs transition-colors cursor-pointer"
            >
              {activeStep > 0 ? 'Back to Previous Step' : 'Back to Setup'}
            </button>

            {activeStep + 1 < categories.length ? (
              <button
                onClick={() => setActiveStep(activeStep + 1)}
                className="bg-blue-700 hover:bg-blue-800 text-white font-bold py-3.5 px-6 rounded-2xl text-xs transition-colors flex items-center gap-1 cursor-pointer"
              >
                Proceed to Next Step <ChevronRight className="w-4.5 h-4.5" />
              </button>
            ) : (
              <button
                onClick={handleSubmitAssessment}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 px-6 rounded-2xl text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-600/10 uppercase"
              >
                <FileCheck className="w-4.5 h-4.5" /> Complete Audit report
              </button>
            )}
          </div>
        </div>
      )}

      {/* ==========================================
          STAGE 3: DETAILED REPORT COMPLIANCE CARD
          ========================================== */}
      {stage === 'report' && (
        <div className="space-y-8 animate-fade-in">
          
          {/* Main Score & Classification Overview card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 text-center space-y-6 relative overflow-hidden">
            <div className="absolute inset-0 bg-blue-600/[0.01] pointer-events-none" />
            <Trophy className="w-16 h-16 text-amber-400 mx-auto animate-bounce" />
            
            <div className="space-y-1">
              <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-tight">Assessed Safety Report Compiled</h2>
              <p className="text-xs text-slate-400 max-w-lg mx-auto">
                Compliance report compiled successfully for <strong>{schoolName}</strong> on behalf of <strong>{assessorName} ({assessorRole.toUpperCase()})</strong>.
              </p>
            </div>

            {/* Beautiful visual circle score */}
            <div className="p-6 bg-slate-950 border border-slate-850 rounded-3xl max-w-sm mx-auto space-y-3 shadow-inner">
              <div className={`text-5xl font-black font-mono tracking-tighter ${
                finalScore >= 90 ? 'text-emerald-400' : finalScore >= 75 ? 'text-amber-400' : finalScore >= 50 ? 'text-orange-400' : 'text-red-400'
              }`}>
                {finalScore} <span className="text-xl text-slate-500">/ 100</span>
              </div>
              <div className="text-[10px] font-mono tracking-widest text-slate-500 uppercase">
                Facility Compliance Rating
              </div>
              
              <div className="pt-2">
                {finalScore >= 90 ? (
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[10px] font-bold font-mono text-emerald-400">
                    🛡️ Class-A: Pristine Safety Standards
                  </span>
                ) : finalScore >= 75 ? (
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full text-[10px] font-bold font-mono text-amber-400">
                    ⚠️ Class-B: Satisfactory Readiness Gaps
                  </span>
                ) : finalScore >= 50 ? (
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-orange-500/10 border border-orange-500/20 rounded-full text-[10px] font-bold font-mono text-orange-400">
                    ⚡ Class-C: Elevated Hazards Flagged
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-red-500/10 border border-red-500/20 rounded-full text-[10px] font-bold font-mono text-red-400 animate-pulse">
                    🚨 Class-D: Severe Safety Violations
                  </span>
                )}
              </div>
            </div>

            {/* Actions Panel */}
            <div className="flex flex-wrap justify-center gap-3">
              <button
                onClick={handleExportReport}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-200 px-5 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <Download className="w-4 h-4 text-blue-400" /> Export TXT Audit Sheet
              </button>
              <button
                onClick={handleResetAssessment}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 px-5 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" /> Restart Audit Run
              </button>
              <button
                onClick={() => onNavigate('resources')}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-5 py-3 rounded-xl text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-amber-500/10"
              >
                Open Emergency Manuals <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Category-wise progress and stats bars */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 space-y-5 shadow-sm">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight flex items-center gap-2 border-b border-slate-100 pb-3">
              <Activity className="w-5 h-5 text-blue-700" />
              Compliance Breakdown by Safety Domain
            </h3>

            <div className="grid sm:grid-cols-2 gap-6 pt-1">
              {[
                { name: 'Structural & Physical', cat: 'Structural', color: 'bg-emerald-500' },
                { name: 'Non-Structural & Exit Clearance', cat: 'Non-Structural', color: 'bg-blue-600' },
                { name: 'Operational & Command Planning', cat: 'Operational', color: 'bg-indigo-600' },
                { name: 'Environmental & Utility Safeguards', cat: 'Environmental', color: 'bg-teal-600' }
              ].map((domain) => {
                const results = getCategoryScoreBreakdown(domain.cat as any);
                return (
                  <div key={domain.cat} className="space-y-2 border border-slate-100 p-4 rounded-2xl bg-slate-50/50">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-extrabold text-slate-800">{domain.name}</span>
                      <span className="font-mono text-slate-500 font-bold">{results.percent}%</span>
                    </div>
                    <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${domain.color} rounded-full transition-all`} 
                        style={{ width: `${results.percent}%` }} 
                      />
                    </div>
                    <div className="text-[10px] font-mono text-slate-400 flex justify-between">
                      <span>Points: {results.earned} / {results.max}</span>
                      <span>{results.percent >= 90 ? '🟢 Compliant' : results.percent >= 70 ? '🟡 Moderate Risk' : '🔴 High Hazard'}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Dynamic Actionable Recommendations Checksheet */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 space-y-6 shadow-sm">
            <div className="flex items-center gap-2 text-red-600 border-b border-slate-100 pb-3 justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500 animate-pulse" />
                <h3 className="text-sm font-black uppercase tracking-tight text-slate-900">
                  Targeted Mitigation Action Plan
                </h3>
              </div>
              <span className="text-[10px] font-mono bg-amber-50 border border-amber-200 text-amber-800 px-2 py-0.5 rounded font-bold">
                {recommendations.length} Pending Actions
              </span>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              We have generated {recommendations.length} institutional safety recommendations based on your audit profile. Distribute these to corresponding campus facilities departments immediately.
            </p>

            {recommendations.length > 0 ? (
              <div className="space-y-4 pt-2 text-xs">
                {recommendations.map((rec) => (
                  <div key={rec.id} className="p-5 border border-slate-150 rounded-2xl bg-white shadow-sm hover:shadow transition-all space-y-3.5 relative overflow-hidden">
                    
                    {/* Priority label indicators */}
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        {rec.priority === 'Critical' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-red-100 border border-red-200 rounded-full text-[9px] font-bold text-red-700 font-mono">
                            🚨 CRITICAL PRIORITY
                          </span>
                        ) : rec.priority === 'High' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-orange-100 border border-orange-200 rounded-full text-[9px] font-bold text-orange-700 font-mono">
                            ⚡ HIGH PRIORITY
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-blue-100 border border-blue-200 rounded-full text-[9px] font-bold text-blue-700 font-mono">
                            🔵 MEDIUM PRIORITY
                          </span>
                        )}
                        <span className="text-[9px] font-mono text-slate-400">
                          Domain: {rec.category}
                        </span>
                      </div>

                      <div className="text-[9px] font-mono font-bold bg-slate-50 border border-slate-100 px-2.5 py-0.5 rounded text-slate-500">
                        Assessed Status: {rec.responseStatus === 'partial' ? '🟡 PARTIAL' : '🔴 DEFICIENT'}
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <h4 className="font-extrabold text-slate-900 leading-normal">{rec.question}</h4>
                      <p className="text-[11px] text-slate-500 leading-normal">
                        <strong>Active Danger:</strong> {rec.hazardDescription}
                      </p>
                    </div>

                    {/* Highly stylized recommendation box */}
                    <div className="p-3.5 bg-slate-50 border border-slate-150 rounded-xl text-[11px] text-slate-700 leading-relaxed space-y-1.5">
                      <div className="font-mono uppercase text-[9px] font-bold text-blue-800 tracking-wider">Required Safety Correction</div>
                      <p>{rec.customRecommendation}</p>
                    </div>

                    {/* Metadata: Owner, Budget, Timeframe */}
                    <div className="grid grid-cols-3 gap-2 pt-1 text-[10px] font-mono text-slate-500">
                      <div className="bg-slate-50 px-2.5 py-1.5 rounded border border-slate-100">
                        <span className="text-[8px] text-slate-400 uppercase tracking-wider block leading-none">OWNER DEPT</span>
                        <span className="font-bold text-slate-700 truncate block mt-0.5" title={rec.department}>{rec.department}</span>
                      </div>
                      <div className="bg-slate-50 px-2.5 py-1.5 rounded border border-slate-100">
                        <span className="text-[8px] text-slate-400 uppercase tracking-wider block leading-none">BUDGET NEED</span>
                        <span className="font-bold text-slate-700 block mt-0.5">{rec.cost === 'Low' ? '🟢 Low Effort ($)' : rec.cost === 'Medium' ? '🟡 Medium ($$)' : '🔴 Budget Needed ($$$)'}</span>
                      </div>
                      <div className="bg-slate-50 px-2.5 py-1.5 rounded border border-slate-100">
                        <span className="text-[8px] text-slate-400 uppercase tracking-wider block leading-none">TIMELINE</span>
                        <span className="font-bold text-slate-700 block mt-0.5">{rec.timeline}</span>
                      </div>
                    </div>

                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-6 text-center space-y-3">
                <ShieldCheck className="w-12 h-12 text-emerald-500 mx-auto animate-bounce" />
                <h3 className="font-bold text-emerald-950 text-sm">Pristine Safety Compliance</h3>
                <p className="text-xs text-emerald-700 max-w-sm mx-auto leading-normal">
                  Outstanding work! This educational facility fully aligns with structural, operational, and non-structural safety protocols. Maintain this state!
                </p>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
