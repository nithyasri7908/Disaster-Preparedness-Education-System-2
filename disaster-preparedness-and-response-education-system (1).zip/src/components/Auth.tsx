import React, { useState } from 'react';
import { 
  LogIn, UserPlus, ShieldAlert, CheckCircle, Info, 
  Lock, Eye, EyeOff, Mail, GraduationCap, School, 
  Bookmark, Shield, Building, AlertCircle
} from 'lucide-react';
import { UserProfile, UserRole } from '../types';

interface AuthProps {
  onAuthSuccess: (user: UserProfile) => void;
}

type AuthMode = 'student-login' | 'teacher-login' | 'admin-login' | 'register';

export default function Auth({ onAuthSuccess }: AuthProps) {
  const [mode, setMode] = useState<AuthMode>('student-login');
  
  // Form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [school, setSchool] = useState('Lincoln University');
  const [extraField, setExtraField] = useState('Sophomore Year'); // Grade level, department, or office
  const [role, setRole] = useState<UserRole>('student'); // Role for new registration

  // Validation & feedback state
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [successMsg, setSuccessMsg] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Auto-fill convenience credentials for demo users
  const handleQuickPreset = (presetRole: UserRole) => {
    setErrors({});
    if (presetRole === 'student') {
      setMode('student-login');
      setEmail('alex.rivera@lincolnu.edu');
      setPassword('student123');
    } else if (presetRole === 'teacher') {
      setMode('teacher-login');
      setEmail('h.vance@lincolnu.edu');
      setPassword('teacher123');
    } else if (presetRole === 'admin') {
      setMode('admin-login');
      setEmail('s.jenkins@lincolnu.edu');
      setPassword('admin123');
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    // Validate email
    if (!email) {
      newErrors.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Validate password
    if (!password) {
      newErrors.password = 'Password is required';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    if (mode === 'register') {
      if (!name.trim()) {
        newErrors.name = 'Full identity name is required';
      }
      if (!school.trim()) {
        newErrors.school = 'School or Institution name is required';
      }
      if (!extraField.trim()) {
        newErrors.extraField = role === 'student' ? 'Grade level is required' : role === 'teacher' ? 'Department is required' : 'Facility office is required';
      }
      if (password !== confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg('');

    if (!validateForm()) return;

    // Determine target role based on the current mode
    let targetRole: UserRole = 'student';
    if (mode === 'teacher-login') targetRole = 'teacher';
    if (mode === 'admin-login') targetRole = 'admin';
    if (mode === 'register') targetRole = role;

    // Use name from field or fallback to preset mock names
    let resolvedName = name;
    if (mode !== 'register') {
      if (targetRole === 'student') resolvedName = 'Alex Rivera';
      else if (targetRole === 'teacher') resolvedName = 'Professor Harold Vance';
      else resolvedName = 'Commander Sarah Jenkins';
    }

    const dummyProfile: UserProfile = {
      name: resolvedName,
      email: email,
      role: targetRole,
      school: mode === 'register' ? school : 'Lincoln University',
      gradeLevel: targetRole === 'student' ? (mode === 'register' ? extraField : 'Sophomore Year') : undefined,
      progress: {
        completedModules: targetRole === 'student' ? [] : ['mod-1'],
        completedQuizzes: {},
        badgesEarned: [],
        riskAssessmentsCompleted: targetRole === 'admin' ? 1 : 0
      }
    };

    setSuccessMsg(`Authentication Successful: Loading secure profile for ${dummyProfile.name}...`);
    
    setTimeout(() => {
      onAuthSuccess(dummyProfile);
    }, 1200);
  };

  return (
    <div className="max-w-5xl mx-auto my-6 grid md:grid-cols-12 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-md animate-fade-in">
      
      {/* Visual Context Sidebar panel - Left Column */}
      <div className="md:col-span-5 bg-slate-900 p-8 text-white flex flex-col justify-between relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-48 h-48 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="space-y-6 z-10">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center text-white font-black text-sm">
              DP
            </div>
            <div>
              <span className="font-extrabold text-xs tracking-wider block uppercase">ResponseEd Hub</span>
              <span className="text-[10px] text-slate-400 font-mono block">SECURE CREDENTIAL MGR</span>
            </div>
          </div>

          <div className="space-y-2 pt-6">
            <h2 className="text-xl font-extrabold tracking-tight">Institutional Gateway</h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Access your personalized disaster readiness portal to execute training simulations, submit facility hazard audits, or monitor campus-wide broadcast emergencies.
            </p>
          </div>

          <div className="space-y-3 pt-4 border-t border-slate-800">
            <div className="flex gap-3 items-center text-xs text-slate-300">
              <GraduationCap className="w-4 h-4 text-blue-400 shrink-0" />
              <span>🎓 Students: Take safety certifications</span>
            </div>
            <div className="flex gap-3 items-center text-xs text-slate-300">
              <School className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>👩‍🏫 Faculty: Manage drill broadcasts</span>
            </div>
            <div className="flex gap-3 items-center text-xs text-slate-300">
              <Shield className="w-4 h-4 text-purple-400 shrink-0" />
              <span>🚨 Admins: Inspect facility risk audits</span>
            </div>
          </div>
        </div>

        <div className="z-10 pt-8 space-y-3">
          {/* Quick Preset helper container */}
          <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-2.5">
            <div className="flex items-center gap-1.5 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
              <Info className="w-3.5 h-3.5 text-blue-400" />
              <span>Academic Preset Logins</span>
            </div>
            <p className="text-[10px] text-slate-500 leading-normal">
              Click to instantly populate active role credentials for direct sandbox evaluation.
            </p>
            <div className="grid grid-cols-3 gap-2">
              <button 
                type="button"
                onClick={() => handleQuickPreset('student')}
                className="py-1.5 px-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 rounded text-[9px] font-bold tracking-tight text-center truncate cursor-pointer"
              >
                🎓 Student
              </button>
              <button 
                type="button"
                onClick={() => handleQuickPreset('teacher')}
                className="py-1.5 px-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 rounded text-[9px] font-bold tracking-tight text-center truncate cursor-pointer"
              >
                👩‍🏫 Teacher
              </button>
              <button 
                type="button"
                onClick={() => handleQuickPreset('admin')}
                className="py-1.5 px-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 rounded text-[9px] font-bold tracking-tight text-center truncate cursor-pointer"
              >
                🛠️ Admin
              </button>
            </div>
          </div>

          <div className="text-[10px] text-slate-500 font-mono flex items-center justify-between">
            <span>NODE CONSOLE: SEC-90</span>
            <span>v2.4.1</span>
          </div>
        </div>
      </div>

      {/* Main Authentication & Sign-up Forms - Right Column */}
      <div className="md:col-span-7 p-6 md:p-8 space-y-6">
        
        {/* Navigation Selector Tabs */}
        <div className="flex flex-wrap gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200">
          <button
            onClick={() => { setMode('student-login'); setErrors({}); setSuccessMsg(''); }}
            className={`flex-1 py-2 text-center text-xs font-bold rounded transition-all cursor-pointer whitespace-nowrap ${
              mode === 'student-login' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            🎓 Student
          </button>
          <button
            onClick={() => { setMode('teacher-login'); setErrors({}); setSuccessMsg(''); }}
            className={`flex-1 py-2 text-center text-xs font-bold rounded transition-all cursor-pointer whitespace-nowrap ${
              mode === 'teacher-login' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            👩‍🏫 Teacher
          </button>
          <button
            onClick={() => { setMode('admin-login'); setErrors({}); setSuccessMsg(''); }}
            className={`flex-1 py-2 text-center text-xs font-bold rounded transition-all cursor-pointer whitespace-nowrap ${
              mode === 'admin-login' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            🚨 Admin
          </button>
          <button
            onClick={() => { setMode('register'); setErrors({}); setSuccessMsg(''); }}
            className={`flex-1 py-2 text-center text-xs font-bold rounded transition-all cursor-pointer whitespace-nowrap ${
              mode === 'register' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            📝 Register
          </button>
        </div>

        {/* Success Banner */}
        {successMsg && (
          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl flex items-center gap-3 text-emerald-800 text-xs animate-fade-in">
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-600 animate-bounce" />
            <span className="font-semibold">{successMsg}</span>
          </div>
        )}

        {/* Info Box about Current Form Mode */}
        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs flex gap-3">
          <ShieldAlert className={`w-5 h-5 shrink-0 mt-0.5 ${
            mode === 'student-login' ? 'text-blue-600' :
            mode === 'teacher-login' ? 'text-emerald-600' :
            mode === 'admin-login' ? 'text-purple-600' : 'text-blue-600'
          }`} />
          <div>
            <h4 className="font-bold text-slate-800">
              {mode === 'student-login' && 'Student Access Terminal'}
              {mode === 'teacher-login' && 'Instructor Access Terminal'}
              {mode === 'admin-login' && 'Administrator Security Terminal'}
              {mode === 'register' && 'Register New Safety Account'}
            </h4>
            <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
              {mode === 'student-login' && 'Authorized for certified campus disaster training, exam taking, and hazard calculators.'}
              {mode === 'teacher-login' && 'Authorized to monitor classroom performance stats, configure active learning guides, and log drill events.'}
              {mode === 'admin-login' && 'Authorized for systemic campus warning broadcasts and critical regional risk assessment records.'}
              {mode === 'register' && 'Create your official credentials to associate your compliance score with your school district.'}
            </p>
          </div>
        </div>

        {/* Main Interactive Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          
          {/* Registration fields: Full name & Role selection */}
          {mode === 'register' && (
            <div className="grid sm:grid-cols-12 gap-4">
              <div className="sm:col-span-6 space-y-1.5">
                <label className="text-slate-600 font-bold block">Full Legal Name</label>
                <input 
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Alex Rivera"
                  className={`w-full bg-white border rounded px-3 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium ${
                    errors.name ? 'border-red-500' : 'border-slate-200'
                  }`}
                />
                {errors.name && <p className="text-[10px] text-red-600 font-semibold">{errors.name}</p>}
              </div>

              <div className="sm:col-span-6 space-y-1.5">
                <label className="text-slate-600 font-bold block">Register Profile Role</label>
                <select 
                  value={role}
                  onChange={e => {
                    const selected = e.target.value as UserRole;
                    setRole(selected);
                    // Update extraField placeholder content based on selection
                    if (selected === 'student') setExtraField('Sophomore Year');
                    else if (selected === 'teacher') setExtraField('Department of Geosciences');
                    else setExtraField('Emergency Operations Centre');
                  }}
                  className="w-full bg-white border border-slate-200 rounded px-3 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium"
                >
                  <option value="student">🎓 Student Account</option>
                  <option value="teacher">👩‍🏫 Teacher/Faculty Account</option>
                  <option value="admin">🚨 School Safety Admin</option>
                </select>
              </div>
            </div>
          )}

          {/* Institutional Email field */}
          <div className="space-y-1.5">
            <label className="text-slate-600 font-bold block">Authorized Institutional Email</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input 
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="e.g. name@school.edu"
                className={`w-full bg-white border rounded pl-9 pr-3 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono ${
                  errors.email ? 'border-red-500' : 'border-slate-200'
                }`}
              />
            </div>
            {errors.email && <p className="text-[10px] text-red-600 font-semibold">{errors.email}</p>}
            {mode !== 'register' && (
              <p className="text-[10px] text-slate-400 font-medium">
                Tip: Enter your email and password, or click one of the quick preset buttons on the left sidebar.
              </p>
            )}
          </div>

          {/* Secure Passwords Section with Visibility Toggle */}
          <div className="grid sm:grid-cols-12 gap-4">
            <div className={`${mode === 'register' ? 'sm:col-span-6' : 'sm:col-span-12'} space-y-1.5`}>
              <label className="text-slate-600 font-bold block">Secure Gateway Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input 
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className={`w-full bg-white border rounded pl-9 pr-10 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 ${
                    errors.password ? 'border-red-500' : 'border-slate-200'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {errors.password && <p className="text-[10px] text-red-600 font-semibold">{errors.password}</p>}
            </div>

            {mode === 'register' && (
              <div className="sm:col-span-6 space-y-1.5">
                <label className="text-slate-600 font-bold block">Confirm Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input 
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className={`w-full bg-white border rounded pl-9 pr-3 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 ${
                      errors.confirmPassword ? 'border-red-500' : 'border-slate-200'
                    }`}
                  />
                </div>
                {errors.confirmPassword && <p className="text-[10px] text-red-600 font-semibold">{errors.confirmPassword}</p>}
              </div>
            )}
          </div>

          {/* Registration specific fields: Institution & Extra details */}
          {mode === 'register' && (
            <div className="grid sm:grid-cols-12 gap-4 pt-1">
              <div className="sm:col-span-6 space-y-1.5">
                <label className="text-slate-600 font-bold block">Campus / Institution</label>
                <div className="relative">
                  <Building className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input 
                    type="text"
                    value={school}
                    onChange={e => setSchool(e.target.value)}
                    placeholder="e.g. Lincoln University"
                    className={`w-full bg-white border rounded pl-9 pr-3 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium ${
                      errors.school ? 'border-red-500' : 'border-slate-200'
                    }`}
                  />
                </div>
                {errors.school && <p className="text-[10px] text-red-600 font-semibold">{errors.school}</p>}
              </div>

              <div className="sm:col-span-6 space-y-1.5">
                <label className="text-slate-600 font-bold block">
                  {role === 'student' ? 'Grade / Study Level' : role === 'teacher' ? 'Academic Department' : 'Office Facility Room'}
                </label>
                <div className="relative">
                  <Bookmark className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input 
                    type="text"
                    value={extraField}
                    onChange={e => setExtraField(e.target.value)}
                    placeholder={role === 'student' ? 'e.g. Sophomore' : 'e.g. Sciences'}
                    className={`w-full bg-white border rounded pl-9 pr-3 py-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium ${
                      errors.extraField ? 'border-red-500' : 'border-slate-200'
                    }`}
                  />
                </div>
                {errors.extraField && <p className="text-[10px] text-red-600 font-semibold">{errors.extraField}</p>}
              </div>
            </div>
          )}

          {/* Form action button with visual feedback based on selected tab */}
          <button
            type="submit"
            className={`w-full mt-3 py-2.5 rounded-lg flex items-center justify-center gap-2 font-extrabold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md text-white ${
              mode === 'student-login' ? 'bg-blue-700 hover:bg-blue-800 shadow-blue-500/10' :
              mode === 'teacher-login' ? 'bg-emerald-700 hover:bg-emerald-800 shadow-emerald-500/10' :
              mode === 'admin-login' ? 'bg-purple-700 hover:bg-purple-800 shadow-purple-500/10' :
              'bg-blue-600 hover:bg-blue-700 shadow-blue-600/10'
            }`}
          >
            {mode === 'register' ? (
              <>
                <UserPlus className="w-4 h-4" /> Create Compliance Profile & Sign In
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4" /> Authenticate & Access Portal
              </>
            )}
          </button>
        </form>

        {/* Informative Security Disclaimer */}
        <div className="pt-4 border-t border-slate-200/60 flex items-center gap-2 text-[10px] text-slate-400">
          <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
          <span>FEMA Safety standard compliant sandbox encryption system. All operations are audited.</span>
        </div>

      </div>

    </div>
  );
}
