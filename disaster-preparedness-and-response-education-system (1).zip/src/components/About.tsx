import React from 'react';
import { 
  ShieldCheck, BookOpen, Clock, Award, Landmark, HelpCircle, 
  Target, Eye, Compass, HeartHandshake, Shield, Users, 
  Mail, Linkedin, AlertTriangle
} from 'lucide-react';

export default function About() {
  const values = [
    { 
      title: "Empowerment via Action", 
      desc: "Shifting from passive learning to interactive decision-making. Standard simulators prepare minds to behave calmly under sensory overload.", 
      icon: ShieldCheck 
    },
    { 
      title: "Structured Curriculum", 
      desc: "Segmenting safety guidelines into natural, manmade, and biochemical threats. Categorized into standard difficulty profiles appropriate for secondary and college grade levels.", 
      icon: BookOpen 
    },
    { 
      title: "Rapid Drill Coordination", 
      desc: "Reducing campus evacuation times through highly visualized step-by-step physical muster guidelines and real-time alert dispatch networks.", 
      icon: Clock 
    },
    { 
      title: "Verifiable Competency", 
      desc: "Providing certificate tracking and testing systems where students must score 80% or greater to acquire active first-responder certificates.", 
      icon: Award 
    }
  ];

  const objectives = [
    {
      id: "obj-1",
      title: "Zero-Latency Broadcasts",
      desc: "Establish instantaneous administrative alerts during severe weather, structural, or hazmat incidents across campuses.",
      tag: "INFRASTRUCTURE"
    },
    {
      id: "obj-2",
      title: "100% Preparedness Literacy",
      desc: "Equip students with the direct physical steps (Drop/Cover/PASS) needed to execute life-saving operations automatically.",
      tag: "PEDAGOGY"
    },
    {
      id: "obj-3",
      title: "Proactive Risk Mitigation",
      desc: "Regularize student-led and faculty-managed spatial hazard audits to identify structural flaws before an emergency occurs.",
      tag: "MITIGATION"
    }
  ];

  const benefits = [
    {
      role: "For Students",
      perks: [
        "Interactive decision-making simulations representing high-fidelity disaster scenarios.",
        "Formal certification upon completing standard curriculum exams.",
        "Immediate access to a 24/7 smart safety consulting AI Chatbot."
      ],
      color: "border-blue-100 bg-blue-50/50"
    },
    {
      role: "For Instructors",
      perks: [
        "Ability to broadcast active drills and live emergency warnings to student dashboards.",
        "Interactive metrics tracking responder certification density across classes.",
        "Systematic checklists to audit school facilities and classrooms."
      ],
      color: "border-emerald-100 bg-emerald-50/50"
    },
    {
      role: "For Administrators",
      perks: [
        "FEMA-compliant logs detailing historical safety drill response and student engagement.",
        "Real-time visibility into campus risk rating indexes.",
        "Automated resource repository housing emergency contact books."
      ],
      color: "border-purple-100 bg-purple-50/50"
    }
  ];

  const team = [
    {
      name: "Dr. Evelyn Ross",
      role: "Principal Safety Strategist",
      dept: "Emergency Management Dept.",
      bio: "Former FEMA advisor specializing in educational campus safety architecture and rapid evacuation modeling.",
      initials: "ER"
    },
    {
      name: "Marcus Sterling",
      role: "Lead Educational Technologist",
      dept: "Instructional Design Division",
      bio: "Specializes in multi-branch safety simulators and game-theoretic cognitive training in high-stress environments.",
      initials: "MS"
    },
    {
      name: "Sarah Jenkins",
      role: "Student Safety Coordinator",
      dept: "Student Advisory Council",
      bio: "Oversees peer-led risk assessments, campus muster maps, and undergraduate disaster compliance reviews.",
      initials: "SJ"
    }
  ];

  return (
    <div className="space-y-12 animate-fade-in pb-12">
      
      {/* 1. Project Introduction Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-8 md:p-10 space-y-4 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-64 h-64 bg-blue-500/[0.02] rounded-full blur-3xl pointer-events-none" />
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 border border-blue-100 rounded-full text-xs font-semibold text-blue-700">
          <Landmark className="w-3.5 h-3.5" />
          ESTABLISHED 2024
        </div>
        <h1 className="text-3xl font-black text-slate-900 tracking-tight leading-tight">
          ResponseEd <span className="text-blue-700">Educational Project</span>
        </h1>
        <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
          The Disaster Preparedness and Response Education System (ResponseEd) is a comprehensive framework built to modernize safety training inside school and college campus complexes. By fusing standard local drills with interactive digital pathways, we prepare students, instructors, and safety administrators for unpredictable civic events. Our academic curriculum bridges the gap between passive policy manuals and responsive, life-saving execution.
        </p>
      </div>

      {/* 2. Vision & Mission Section */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 md:p-8 shadow-sm space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="p-3 bg-blue-50 text-blue-700 rounded-xl w-fit">
              <Eye className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Our Vision</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              To build a global academic ecosystem where high-density educational environments are universally resilient against natural, manmade, and biochemical threats. We envision school buildings where physical reflexes are fully trained, structural systems are continuously audited, and communication paths operate with zero latency.
            </p>
          </div>
          <div className="text-[10px] text-slate-400 font-mono tracking-wider uppercase font-bold">
            Resilient Infrastructure Standards
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-6 md:p-8 shadow-sm space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl w-fit">
              <Target className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Our Mission</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              To substitute dry, text-only safety guidelines with highly immersive simulations, responsive testing modules, and proactive hazard audits. We strive to democratize vital crisis response protocols (Drop, Cover, Hold On, and PASS firefighting skills) so every student and faculty member is certified to act.
            </p>
          </div>
          <div className="text-[10px] text-slate-400 font-mono tracking-wider uppercase font-bold">
            Immersive Pedagogy Automation
          </div>
        </div>
      </div>

      {/* 3. Importance of Disaster Preparedness */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 md:p-8 shadow-sm grid md:grid-cols-12 gap-6 items-center">
        <div className="md:col-span-4 space-y-3">
          <div className="p-3 bg-red-50 text-red-600 rounded-xl w-fit">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Why Campus Safety Matters</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Educational complexes house complex lab chemicals, library books, high-voltage electrical networks, and crowded corridors. During an emergency, lack of clear directions results in panic, blockages, and delayed assistance.
          </p>
        </div>

        <div className="md:col-span-8 bg-slate-50 border border-slate-100 rounded-xl p-5 space-y-4">
          <h4 className="text-[11px] font-black tracking-widest text-slate-500 uppercase">Critical Preparedness Pillars</h4>
          <div className="space-y-3">
            <div className="flex gap-3 items-start">
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-700 text-[10px] font-bold text-white">1</span>
              <div>
                <h5 className="text-xs font-bold text-slate-800">Dynamic Muscle Memory</h5>
                <p className="text-[11px] text-slate-500">Regular digital path drills reinforce reflexes, so when alarms fire, occupants react rationally rather than panicking.</p>
              </div>
            </div>
            <div className="flex gap-3 items-start">
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-700 text-[10px] font-bold text-white">2</span>
              <div>
                <h5 className="text-xs font-bold text-slate-800">Coordinated Communications</h5>
                <p className="text-[11px] text-slate-500">Connecting student dashboards directly with administrative warning broadcasts guarantees immediate alignment during hazard scenarios.</p>
              </div>
            </div>
            <div className="flex gap-3 items-start">
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-700 text-[10px] font-bold text-white">3</span>
              <div>
                <h5 className="text-xs font-bold text-slate-800">FEMA & Structural Compliance</h5>
                <p className="text-[11px] text-slate-500">Ensuring classroom layouts, chemical lockers, and fire exits comply strictly with federal safety directives through periodic hazard reports.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Strategic Objectives */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight border-l-4 border-blue-700 pl-3">
          Key Strategic Objectives
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          {objectives.map((obj) => (
            <div key={obj.id} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4 shadow-xs">
              <span className="text-[9px] bg-blue-50 text-blue-700 border border-blue-100 font-bold px-2 py-0.5 rounded uppercase">
                {obj.tag}
              </span>
              <h3 className="font-bold text-sm text-slate-900">{obj.title}</h3>
              <p className="text-xs text-slate-500 leading-relaxed">{obj.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* 5. Benefits Section */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight border-l-4 border-blue-700 pl-3">
          Platform Benefits
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          {benefits.map((benefit, idx) => (
            <div key={idx} className={`border rounded-xl p-6 space-y-4 shadow-xs ${benefit.color}`}>
              <h3 className="font-bold text-sm text-slate-900 border-b border-slate-200 pb-2">
                {benefit.role}
              </h3>
              <ul className="space-y-2 text-xs text-slate-600">
                {benefit.perks.map((perk, pIdx) => (
                  <li key={pIdx} className="flex gap-2 items-start">
                    <span className="text-slate-400 shrink-0 select-none">•</span>
                    <span>{perk}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* 6. Values Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {values.map((val, idx) => {
          const Icon = val.icon;
          return (
            <div key={idx} className="bg-white border border-slate-200 rounded-xl p-6 space-y-3 flex gap-4 shadow-xs">
              <div className="p-3 bg-blue-50 text-blue-700 rounded-xl h-fit shrink-0">
                <Icon className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="font-bold text-slate-950 text-sm">{val.title}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{val.desc}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* 7. Platform Safety Team Section */}
      <div className="space-y-6">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-slate-900 tracking-tight border-l-4 border-blue-700 pl-3">
            Academic Safety & Development Team
          </h2>
          <p className="text-xs text-slate-500">
            Meet the researchers, developers, and advisors responsible for ResponseEd's pedagogical standard.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {team.map((member, idx) => (
            <div key={idx} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4 shadow-xs relative group hover:border-blue-300 transition-all">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-blue-700 text-white font-extrabold flex items-center justify-center text-sm shadow-sm">
                  {member.initials}
                </div>
                <div>
                  <h4 className="font-bold text-slate-950 text-sm">{member.name}</h4>
                  <p className="text-[10px] text-blue-700 font-bold uppercase tracking-wider">{member.role}</p>
                </div>
              </div>
              
              <div className="text-[10px] text-slate-400 font-mono">
                DEPT: {member.dept}
              </div>

              <p className="text-xs text-slate-500 leading-relaxed">
                {member.bio}
              </p>

              <div className="flex gap-2 pt-2 border-t border-slate-100">
                <button className="flex items-center gap-1 text-[10px] font-bold text-slate-500 hover:text-blue-700 cursor-pointer">
                  <Mail className="w-3.5 h-3.5" /> Email
                </button>
                <span className="text-slate-300">|</span>
                <button className="flex items-center gap-1 text-[10px] font-bold text-slate-500 hover:text-blue-700 cursor-pointer">
                  <Linkedin className="w-3.5 h-3.5" /> LinkedIn
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
