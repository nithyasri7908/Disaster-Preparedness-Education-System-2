import React, { useState } from 'react';
import { LEARNING_MODULES } from '../data/safetyData';
import { LearningModule, UserProfile } from '../types';
import { 
  GraduationCap, BookOpen, CheckCircle, Clock, 
  ChevronRight, Play, HelpCircle, Flame, ShieldAlert, Waves, 
  Shield, ArrowLeft, Wind, Compass, Activity, Search, AlertTriangle, Check
} from 'lucide-react';

interface LearningModulesProps {
  user: UserProfile | null;
  onModuleComplete: (moduleId: string) => void;
  onNavigate: (tab: string) => void;
}

export default function LearningModules({ user, onModuleComplete, onNavigate }: LearningModulesProps) {
  const [modules] = useState<LearningModule[]>(() => {
    const saved = localStorage.getItem('responseed_modules');
    return saved ? JSON.parse(saved) : LEARNING_MODULES;
  });
  const [selectedModule, setSelectedModule] = useState<LearningModule | null>(null);
  const [activeSectionIdx, setActiveSectionIdx] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const getCategoryColor = (category: string) => {
    switch(category) {
      case 'natural': return 'text-sky-400 bg-sky-500/10 border-sky-500/20';
      case 'manmade': return 'text-orange-400 bg-orange-500/10 border-orange-500/20';
      case 'health': return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      default: return 'text-slate-400 bg-slate-500/10 border-slate-500/20';
    }
  };

  const getModuleIcon = (id: string) => {
    switch(id) {
      case 'earthquake': return <ShieldAlert className="w-5 h-5 text-amber-500" />;
      case 'fire': return <Flame className="w-5 h-5 text-red-500" />;
      case 'flood': return <Waves className="w-5 h-5 text-blue-500" />;
      case 'cyclone': return <Wind className="w-5 h-5 text-sky-500" />;
      case 'tsunami': return <Waves className="w-5 h-5 text-teal-500" />;
      case 'landslide': return <Compass className="w-5 h-5 text-orange-500" />;
      case 'first_aid': return <Activity className="w-5 h-5 text-emerald-500" />;
      default: return <GraduationCap className="w-5 h-5 text-amber-500" />;
    }
  };

  const handleCompleteClick = (moduleId: string) => {
    onModuleComplete(moduleId);
  };

  // Filter modules based on search query and category tab selection
  const filteredModules = modules.filter(mod => {
    const matchesSearch = mod.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          mod.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || mod.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* If no module is selected, render the main cards grid */}
      {!selectedModule ? (
        <div className="space-y-6">
          
          {/* Header Dashboard section */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 -mt-16 -mr-16 w-56 h-56 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
            
            <div className="max-w-2xl space-y-3 z-10 relative">
              <span className="text-[10px] font-mono font-extrabold tracking-wider bg-amber-500/10 text-amber-500 px-2.5 py-1 rounded border border-amber-500/20 uppercase">
                Interactive Curriculum
              </span>
              <h1 className="text-2xl md:text-3xl font-black text-slate-100 tracking-tight">
                Disaster Safety Learning Center
              </h1>
              <p className="text-xs text-slate-400 leading-relaxed">
                Empower yourself with academic-certified, actionable survival guides. Complete each module, perform tactical steps, and unlock physical badges validating your disaster readiness scores.
              </p>
            </div>
          </div>

          {/* Search, Filter, and Status Controls */}
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-slate-950 border border-slate-850 p-4 rounded-xl">
            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search survival modules..."
                className="w-full bg-slate-900 border border-slate-800 text-xs rounded-lg pl-9 pr-4 py-2.5 text-slate-200 placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            {/* Category Filter Tabs */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-900 rounded-lg border border-slate-800 w-full md:w-auto overflow-x-auto">
              {[
                { id: 'all', label: 'All Curriculums' },
                { id: 'natural', label: '🌿 Natural' },
                { id: 'manmade', label: '⚙️ Man-made' },
                { id: 'health', label: '🩺 Health & Aid' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setCategoryFilter(tab.id)}
                  className={`text-xs font-bold px-3 py-1.5 rounded transition-all whitespace-nowrap cursor-pointer ${
                    categoryFilter === tab.id
                      ? 'bg-amber-500 text-slate-950 shadow'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Grid of Module Cards */}
          {filteredModules.length === 0 ? (
            <div className="text-center py-12 bg-slate-900 border border-slate-850 rounded-xl space-y-2">
              <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto animate-bounce" />
              <h3 className="text-sm font-bold text-slate-200">No curiculums match your search</h3>
              <p className="text-xs text-slate-400">Try checking spelling or switching filtering categories.</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredModules.map((mod) => {
                const isCompleted = user?.progress.completedModules.includes(mod.id) || false;
                
                return (
                  <div 
                    key={mod.id}
                    id={`module-card-${mod.id}`}
                    className="group bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl overflow-hidden shadow-lg transition-all flex flex-col justify-between"
                  >
                    {/* Module Image header */}
                    <div className="relative h-44 w-full bg-slate-950 overflow-hidden">
                      <img 
                        src={mod.imageUrl} 
                        alt={mod.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                      
                      {/* Top float badges */}
                      <div className="absolute top-3 left-3 flex gap-2">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase border ${getCategoryColor(mod.category)}`}>
                          {mod.category}
                        </span>
                        <span className="bg-slate-950/80 text-slate-300 border border-slate-800 px-2 py-0.5 rounded text-[9px] font-mono">
                          {mod.difficulty}
                        </span>
                      </div>

                      {/* Completed stamp */}
                      {isCompleted && (
                        <div className="absolute top-3 right-3 bg-emerald-500 text-slate-950 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold flex items-center gap-1 shadow-md">
                          <Check className="w-3.5 h-3.5 stroke-[3]" /> COMPLETED
                        </div>
                      )}

                      {/* Bottom icon & timer overlays */}
                      <div className="absolute bottom-3 left-3 flex items-center gap-2">
                        <div className="p-1.5 bg-slate-950/90 border border-slate-800 rounded-lg text-amber-500">
                          {getModuleIcon(mod.id)}
                        </div>
                        <span className="text-[10px] font-mono text-slate-300 bg-slate-950/60 px-1.5 py-0.5 rounded">
                          ⏱️ {mod.timeToComplete}
                        </span>
                      </div>
                    </div>

                    {/* Card Content */}
                    <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                      <div className="space-y-1.5">
                        <h3 className="font-extrabold text-sm text-slate-100 group-hover:text-amber-400 transition-colors tracking-tight">
                          {mod.title}
                        </h3>
                        <p className="text-[11px] text-slate-400 leading-relaxed line-clamp-3">
                          {mod.description}
                        </p>
                      </div>

                      <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                        <span className="text-[10px] text-slate-500 font-mono">CODE: {mod.id.toUpperCase()}</span>
                        <button
                          onClick={() => {
                            setSelectedModule(mod);
                            setActiveSectionIdx(0);
                          }}
                          className="text-xs font-bold text-amber-500 hover:text-amber-400 flex items-center gap-1 transition-all cursor-pointer"
                        >
                          Launch Course <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>
      ) : (
        /* If a module is selected, render the deep curriculum view */
        <div className="grid lg:grid-cols-12 gap-8">
          
          {/* Navigation & Sidebar controls - Col span 4 */}
          <div className="lg:col-span-4 space-y-4">
            
            {/* Back button */}
            <button
              onClick={() => setSelectedModule(null)}
              className="flex items-center gap-2 text-slate-400 hover:text-slate-100 text-xs font-bold transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-amber-500" /> Back to Safety Curriculums
            </button>

            {/* Quick Switch Panel */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <h2 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
                <BookOpen className="w-4 h-4 text-amber-500" />
                Active Class Syllabus
              </h2>
              <div className="space-y-2">
                {LEARNING_MODULES.map((mod) => {
                  const currentCompleted = user?.progress.completedModules.includes(mod.id) || false;
                  const isSelected = selectedModule.id === mod.id;

                  return (
                    <button
                      key={mod.id}
                      onClick={() => {
                        setSelectedModule(mod);
                        setActiveSectionIdx(0);
                      }}
                      className={`w-full text-left p-3.5 rounded-xl border flex justify-between items-center transition-all focus:outline-none cursor-pointer ${
                        isSelected
                          ? 'bg-amber-500 border-amber-500 text-slate-950 shadow-lg shadow-amber-500/10'
                          : 'bg-slate-950 border-slate-850 hover:border-slate-700 text-slate-100'
                      }`}
                    >
                      <div className="space-y-1 min-w-0 pr-2">
                        <span className={`text-[9px] font-mono px-1 py-0.2 rounded uppercase font-semibold ${
                          isSelected 
                            ? 'bg-slate-950/20 text-slate-950' 
                            : 'bg-slate-900 text-slate-400 border border-slate-800'
                        }`}>
                          {mod.difficulty}
                        </span>
                        <h3 className="font-bold text-xs truncate leading-snug">
                          {mod.title}
                        </h3>
                      </div>
                      <div className="shrink-0">
                        {currentCompleted ? (
                          <CheckCircle className={`w-4 h-4 ${isSelected ? 'text-slate-950' : 'text-emerald-500'}`} />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Practical Drill helper panel */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-xl p-5 text-center space-y-3">
              <h3 className="text-xs font-extrabold uppercase text-amber-500 tracking-wider">Ready for simulation?</h3>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Execute interactive physical choices based on this guide in the high-stress visual sandbox environment.
              </p>
              <button
                onClick={() => onNavigate('simulator')}
                className="w-full bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-200 text-xs py-2 rounded font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Play className="w-3 h-3 text-amber-500 animate-pulse" /> Launch Crisis Sandbox
              </button>
            </div>
          </div>

          {/* Deep Syllabus Contents - Col span 8 */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Immersive Cover Photo and Title Header Banner */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg relative">
              <div className="h-52 md:h-64 relative">
                <img 
                  src={selectedModule.imageUrl} 
                  alt={selectedModule.title} 
                  className="w-full h-full object-cover brightness-50"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/30 to-transparent" />
                
                {/* Float category badge */}
                <span className={`absolute top-4 left-4 px-2.5 py-1 rounded text-[10px] font-mono font-black uppercase border shadow-md ${getCategoryColor(selectedModule.category)}`}>
                  {selectedModule.category} disaster
                </span>
                
                {/* Header texts */}
                <div className="absolute bottom-6 left-6 right-6 space-y-2">
                  <h1 className="text-xl md:text-2xl font-black text-white tracking-tight leading-none drop-shadow-md">
                    {selectedModule.title}
                  </h1>
                  <p className="text-xs text-slate-300 max-w-xl leading-relaxed drop-shadow-sm font-medium">
                    {selectedModule.description}
                  </p>
                </div>
              </div>
            </div>

            {/* Core Curriculum Structure tabs */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <div className="flex flex-wrap border-b border-slate-800 bg-slate-950">
                {[
                  { label: ' SIGHT & CAUSES' },
                  { label: '🛡️ PROTOCOLS' },
                  { label: '🚨 DRILL SEQUENCE' }
                ].map((secLabel, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveSectionIdx(idx)}
                    className={`flex-1 text-center py-3.5 text-xs font-black border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                      activeSectionIdx === idx
                        ? 'border-amber-500 text-amber-500 bg-slate-900/60'
                        : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/20'
                    }`}
                  >
                    {secLabel.label}
                  </button>
                ))}
              </div>

              {/* Tab 1: Introduction & Causes */}
              {activeSectionIdx === 0 && (
                <div className="p-6 space-y-6">
                  {/* Introduction Block */}
                  <div className="space-y-2.5">
                    <h3 className="text-xs font-extrabold uppercase text-amber-500 tracking-wider">
                      Module Introduction
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/40 border border-slate-850 p-4 rounded-lg font-medium">
                      {selectedModule.introduction}
                    </p>
                  </div>

                  {/* Causes list */}
                  <div className="space-y-3">
                    <h3 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider">
                      Primary Root Causes
                    </h3>
                    <div className="grid gap-3">
                      {selectedModule.causes.map((cause, cidx) => (
                        <div key={cidx} className="bg-slate-950 p-3 rounded-lg border border-slate-850 flex items-start gap-3 text-xs">
                          <span className="text-amber-500 font-mono font-bold shrink-0 mt-0.5">0{cidx + 1}.</span>
                          <span className="text-slate-300 font-medium">{cause}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 2: Disaster Protocols (Before, During, After, Safety Tips) */}
              {activeSectionIdx === 1 && (
                <div className="p-6 space-y-6">
                  
                  {/* Chronological Grid */}
                  <div className="grid md:grid-cols-3 gap-4">
                    
                    {/* Before Disaster */}
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3">
                      <span className="text-[10px] font-mono bg-sky-500/10 text-sky-400 border border-sky-500/20 px-2 py-0.5 rounded font-extrabold uppercase block w-max">
                        1. BEFORE
                      </span>
                      <ul className="space-y-2 text-[11px] text-slate-400 leading-relaxed">
                        {selectedModule.beforeDisaster.map((item, idx) => (
                          <li key={idx} className="flex gap-2">
                            <span className="text-sky-500 font-bold shrink-0">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* During Disaster */}
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3">
                      <span className="text-[10px] font-mono bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded font-extrabold uppercase block w-max">
                        2. DURING
                      </span>
                      <ul className="space-y-2 text-[11px] text-slate-400 leading-relaxed">
                        {selectedModule.duringDisaster.map((item, idx) => (
                          <li key={idx} className="flex gap-2">
                            <span className="text-red-500 font-bold shrink-0">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* After Disaster */}
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3">
                      <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-extrabold uppercase block w-max">
                        3. AFTER
                      </span>
                      <ul className="space-y-2 text-[11px] text-slate-400 leading-relaxed">
                        {selectedModule.afterDisaster.map((item, idx) => (
                          <li key={idx} className="flex gap-2">
                            <span className="text-emerald-500 font-bold shrink-0">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                  </div>

                  {/* Safety Tips Overlay banner */}
                  <div className="bg-amber-500/10 border border-amber-500/20 p-4 rounded-lg space-y-2">
                    <h4 className="text-xs font-extrabold text-amber-500 uppercase flex items-center gap-1.5">
                      <HelpCircle className="w-4 h-4 text-amber-500 shrink-0" />
                      Tactical Safety Lessons
                    </h4>
                    <ul className="space-y-1.5 text-[11px] text-slate-300 leading-relaxed pl-1">
                      {selectedModule.safetyTips.map((tip, tipIdx) => (
                        <li key={tipIdx} className="list-disc ml-4 pl-0.5">{tip}</li>
                      ))}
                    </ul>
                  </div>

                </div>
              )}

              {/* Tab 3: Evacuation Drill Steps */}
              {activeSectionIdx === 2 && (
                <div className="p-6 space-y-4">
                  <div className="space-y-1">
                    <h3 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider">
                      Emergency Evacuation Drill Steps
                    </h3>
                    <p className="text-xs text-slate-400">
                      A step-by-step training sequence representing real school evacuation drills. Review and understand the reasoning for each phase.
                    </p>
                  </div>

                  <div className="space-y-3 pt-2">
                    {selectedModule.drillSteps.map((ds) => (
                      <div key={ds.step} className="bg-slate-950 p-4 rounded-lg border border-slate-850 flex gap-4 items-start">
                        <span className="w-6 h-6 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-500 font-mono text-xs flex items-center justify-center shrink-0 font-extrabold">
                          {ds.step}
                        </span>
                        <div className="space-y-1">
                          <h4 className="text-xs font-extrabold text-slate-100">{ds.action}</h4>
                          <p className="text-[11px] text-slate-400 leading-normal font-mono">{ds.rationale}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>

            {/* Bottom Credit Validation Action bar */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col sm:flex-row justify-between items-center gap-4">
              <div className="space-y-1 text-center sm:text-left">
                <h4 className="text-xs font-bold text-slate-200">
                  {user?.progress.completedModules.includes(selectedModule.id) ? "Syllabus Completed" : "Verify Safety Credit"}
                </h4>
                <p className="text-[11px] text-slate-400">
                  {user?.progress.completedModules.includes(selectedModule.id) 
                    ? "This curriculum is checked off your student records." 
                    : "Marking complete logs study hours toward your Safety Badges & Certificate."}
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => onNavigate('quiz')}
                  className="bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 px-5 py-2.5 rounded text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
                >
                  Take Safety Quiz
                </button>
                <button
                  onClick={() => handleCompleteClick(selectedModule.id)}
                  disabled={user?.progress.completedModules.includes(selectedModule.id)}
                  className={`px-5 py-2.5 rounded text-xs font-black transition-all flex items-center gap-1.5 shadow-lg whitespace-nowrap ${
                    user?.progress.completedModules.includes(selectedModule.id) 
                      ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 cursor-default' 
                      : 'bg-amber-500 hover:bg-amber-600 text-slate-950 cursor-pointer'
                  }`}
                >
                  <CheckCircle className="w-4 h-4" /> {user?.progress.completedModules.includes(selectedModule.id) ? "Completed" : "Complete Module"}
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
