import React, { useState, useEffect } from 'react';
import { UserProfile, SystemLog, LearningModule, Quiz, EmergencyAlert } from '../types';
import { LEARNING_MODULES, QUIZZES } from '../data/safetyData';
import { 
  Settings, ShieldAlert, Cpu, Terminal, 
  Database, RefreshCw, Sliders, ToggleLeft, ToggleRight,
  Plus, Trash2, Edit3, Save, X, ChevronRight, Award, 
  FileText, Users, Bell, FileBadge, CheckCircle, AlertCircle, 
  Eye, BookOpen, Book, Activity, Building, Layers, Send, Check, Search, Download
} from 'lucide-react';

interface AdminDashboardProps {
  user: UserProfile | null;
  alerts: EmergencyAlert[];
  onTriggerAlert: (alertData: any) => Promise<void>;
  onDeactivateAlert: (alertId: string) => Promise<void>;
  onNavigate: (tab: string) => void;
}

// Default Seed Users List
const DEFAULT_USERS: UserProfile[] = [
  {
    name: "Alex Rivera",
    email: "alex.rivera@lincolnu.edu",
    role: "student",
    school: "Lincoln University",
    gradeLevel: "Sophomore Year",
    studentId: "STU-2026-0891",
    progress: {
      completedModules: ["earthquake"],
      completedQuizzes: { "earthquake_quiz": 100 },
      badgesEarned: ["Disaster Scholar", "Earthquake Rescuer"],
      riskAssessmentsCompleted: 1
    }
  },
  {
    name: "Professor Harold Vance",
    email: "h.vance@lincolnu.edu",
    role: "teacher",
    school: "Lincoln Geosciences Department",
    progress: { completedModules: [], completedQuizzes: {}, badgesEarned: [], riskAssessmentsCompleted: 0 }
  },
  {
    name: "Commander Sarah Jenkins",
    email: "s.jenkins@lincolnu.edu",
    role: "admin",
    school: "Lincoln Safety Operations Command",
    progress: { completedModules: [], completedQuizzes: {}, badgesEarned: [], riskAssessmentsCompleted: 0 }
  },
  {
    name: "Emily Chen",
    email: "emily.chen@lincolnu.edu",
    role: "student",
    school: "Lincoln University",
    gradeLevel: "Freshman Year",
    studentId: "STU-2026-4402",
    progress: {
      completedModules: ["chemical_lab"],
      completedQuizzes: { "science_lab_quiz": 85 },
      badgesEarned: ["First Aid Rookie"],
      riskAssessmentsCompleted: 0
    }
  },
  {
    name: "Marcus Thorne",
    email: "m.thorne@lincolnu.edu",
    role: "teacher",
    school: "Lincoln Biochemistry Department",
    progress: { completedModules: [], completedQuizzes: {}, badgesEarned: [], riskAssessmentsCompleted: 0 }
  }
];

export default function AdminDashboard({ user, alerts, onTriggerAlert, onDeactivateAlert, onNavigate }: AdminDashboardProps) {
  // Navigation Tabs: 'overview' | 'alerts' | 'modules' | 'quizzes' | 'resources' | 'users' | 'reports' | 'certificates'
  const [activeAdminTab, setActiveAdminTab] = useState<'overview' | 'alerts' | 'modules' | 'quizzes' | 'resources' | 'users' | 'reports' | 'certificates'>('overview');

  // Core System Toggle States
  const [drillMode, setDrillMode] = useState(() => {
    return localStorage.getItem('responseed_drill_mode') !== 'false';
  });
  const [maintenanceMode, setMaintenanceMode] = useState(() => {
    return localStorage.getItem('responseed_maintenance_mode') === 'true';
  });
  const [securityClearance, setSecurityClearance] = useState<'Standard' | 'Strict' | 'EOC Only'>(() => {
    return (localStorage.getItem('responseed_clearance') as any) || 'Standard';
  });

  // Stateful databases loaded from localStorage with fallback to default data
  const [modulesList, setModulesList] = useState<LearningModule[]>(() => {
    const saved = localStorage.getItem('responseed_modules');
    return saved ? JSON.parse(saved) : LEARNING_MODULES;
  });

  const [quizzesList, setQuizzesList] = useState<Quiz[]>(() => {
    const saved = localStorage.getItem('responseed_quizzes');
    return saved ? JSON.parse(saved) : QUIZZES;
  });

  const [documentsList, setDocumentsList] = useState<any[]>(() => {
    const saved = localStorage.getItem('responseed_documents');
    if (saved) return JSON.parse(saved);
    // Mimic default resource documents from ResourceCenter
    return [
      {
        id: 'fema-evac',
        title: 'FEMA Campus Evacuation Guide',
        filename: 'FEMA-Campus-Evac-2026.pdf',
        size: '2.4 MB',
        category: 'general',
        description: 'Comprehensive federal and institutional guidelines to multi-building evacuation protocols, assembly zones, and leadership roles.',
        pages: ['Page 1', 'Page 2', 'Page 3', 'Page 4']
      },
      {
        id: 'active-threat',
        title: 'Active Threat Tactical Guide',
        filename: 'Active-Threat-Lockdown-2026.pdf',
        size: '1.8 MB',
        category: 'tactical',
        description: 'Standard guidelines on Run-Hide-Fight tactics, custom door barricade techniques, and emergency response team integration.',
        pages: ['Page 1', 'Page 2', 'Page 3', 'Page 4']
      },
      {
        id: 'science-lab',
        title: 'Science Lab Chemical Safety Manual',
        filename: 'Science-Lab-Chemical-Safety.pdf',
        size: '3.1 MB',
        category: 'chemical',
        description: 'Official safety protocols for chemistry lab solvent leaks, acid neutralizations, emergency eyewash stations, and MSDS logs.',
        pages: ['Page 1', 'Page 2', 'Page 3', 'Page 4']
      }
    ];
  });

  const [usersList, setUsersList] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem('responseed_users');
    return saved ? JSON.parse(saved) : DEFAULT_USERS;
  });

  const [reportsList, setReportsList] = useState<any[]>(() => {
    const saved = localStorage.getItem('responseed_reports');
    return saved ? JSON.parse(saved) : [
      {
        id: "report-seed-1",
        schoolName: "Lincoln University",
        assessorName: "Alex Rivera",
        assessorRole: "student",
        finalScore: 82,
        date: new Date().toLocaleDateString(),
        priorityBreakdown: { critical: 1, high: 2, medium: 2 },
        responses: {},
        recommendations: [
          { question: "Are tall classroom bookshelves and heavy cabinets bolted?", category: "Structural", status: "none", tip: "Install heavy-duty L-brackets.", priority: "High", department: "Facilities & Maintenance" }
        ]
      }
    ];
  });

  // Action log lists
  const [logsList, setLogsList] = useState<SystemLog[]>([
    { id: "log-initial", timestamp: new Date().toLocaleTimeString(), type: "security", message: "Administrative security clearance authenticated.", user: "System" }
  ]);

  // Persist toggles
  useEffect(() => {
    localStorage.setItem('responseed_drill_mode', String(drillMode));
    addLog('info', `Campus drill mode toggled to: ${drillMode}`);
  }, [drillMode]);

  useEffect(() => {
    localStorage.setItem('responseed_maintenance_mode', String(maintenanceMode));
    addLog('warning', `Maintenance lockdown mode set to: ${maintenanceMode}`);
  }, [maintenanceMode]);

  useEffect(() => {
    localStorage.setItem('responseed_clearance', securityClearance);
    addLog('security', `Command clearance level escalated to: ${securityClearance}`);
  }, [securityClearance]);

  // Helper: append administrative log
  const addLog = (type: 'info' | 'warning' | 'alert' | 'security', message: string) => {
    const newLog: SystemLog = {
      id: `log-${Date.now()}-${Math.random()}`,
      timestamp: new Date().toLocaleTimeString(),
      type,
      message,
      user: user?.name || "Administrator"
    };
    setLogsList(prev => [newLog, ...prev].slice(0, 50));
  };

  // Helper: Sync localStorage for lists
  const syncModules = (list: LearningModule[]) => {
    setModulesList(list);
    localStorage.setItem('responseed_modules', JSON.stringify(list));
  };
  const syncQuizzes = (list: Quiz[]) => {
    setQuizzesList(list);
    localStorage.setItem('responseed_quizzes', JSON.stringify(list));
  };
  const syncDocuments = (list: any[]) => {
    setDocumentsList(list);
    localStorage.setItem('responseed_documents', JSON.stringify(list));
  };
  const syncUsers = (list: UserProfile[]) => {
    setUsersList(list);
    localStorage.setItem('responseed_users', JSON.stringify(list));
  };
  const syncReports = (list: any[]) => {
    setReportsList(list);
    localStorage.setItem('responseed_reports', JSON.stringify(list));
  };

  // ==========================================
  // STATE EDITORS / FORMS CONTROLS
  // ==========================================

  // Alerts states
  const [newAlertTitle, setNewAlertTitle] = useState('');
  const [newAlertMessage, setNewAlertMessage] = useState('');
  const [newAlertSeverity, setNewAlertSeverity] = useState<'low' | 'medium' | 'high'>('medium');
  const [newAlertType, setNewAlertType] = useState<'drill' | 'real_emergency' | 'advisory'>('drill');
  const [isAlertSubmitting, setIsAlertSubmitting] = useState(false);

  // Modules CRUD states
  const [editingModule, setEditingModule] = useState<LearningModule | null>(null);
  const [isAddingModule, setIsAddingModule] = useState(false);
  const [newModuleTitle, setNewModuleTitle] = useState('');
  const [newModuleCategory, setNewModuleCategory] = useState<'natural' | 'manmade' | 'health'>('natural');
  const [newModuleDifficulty, setNewModuleDifficulty] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Beginner');
  const [newModuleTime, setNewModuleTime] = useState('10 mins');
  const [newModuleDesc, setNewModuleDesc] = useState('');
  const [newModuleIntro, setNewModuleIntro] = useState('');

  // Quizzes CRUD states
  const [editingQuiz, setEditingQuiz] = useState<Quiz | null>(null);
  const [isAddingQuiz, setIsAddingQuiz] = useState(false);
  const [newQuizTitle, setNewQuizTitle] = useState('');
  const [newQuizModuleRef, setNewQuizModuleRef] = useState('');
  // Quiz question sub-state inside editing quiz
  const [newQuestionText, setNewQuestionText] = useState('');
  const [newQuestionOptions, setNewQuestionOptions] = useState<string[]>(['', '', '', '']);
  const [newQuestionCorrect, setNewQuestionCorrect] = useState<number>(0);
  const [newQuestionExplanation, setNewQuestionExplanation] = useState('');

  // Resources CRUD states
  const [editingDoc, setEditingDoc] = useState<any | null>(null);
  const [isAddingDoc, setIsAddingDoc] = useState(false);
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocFilename, setNewDocFilename] = useState('');
  const [newDocCategory, setNewDocCategory] = useState('general');
  const [newDocDesc, setNewDocDesc] = useState('');
  const [newDocSize, setNewDocSize] = useState('1.5 MB');

  // Users CRUD states
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [newUserModel, setNewUserModel] = useState<UserProfile>({
    name: '',
    email: '',
    role: 'student',
    school: 'Lincoln University',
    gradeLevel: 'Freshman Year',
    studentId: '',
    progress: { completedModules: [], completedQuizzes: {}, badgesEarned: [], riskAssessmentsCompleted: 0 }
  });

  // Modal report view
  const [selectedReport, setSelectedReport] = useState<any | null>(null);

  // ==========================================
  // ACTIONS SUBMITTERS
  // ==========================================

  // Dispatch Emergency Alert
  const handleAlertBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAlertTitle || !newAlertMessage) return;
    setIsAlertSubmitting(true);
    try {
      await onTriggerAlert({
        title: newAlertTitle,
        message: newAlertMessage,
        severity: newAlertSeverity,
        type: newAlertType,
        sender: `Command Station (${user?.name})`
      });
      addLog('alert', `Emergency alert broadcasted: ${newAlertTitle} (${newAlertSeverity.toUpperCase()})`);
      setNewAlertTitle('');
      setNewAlertMessage('');
      setActiveAdminTab('overview');
    } catch (err) {
      console.error(err);
      addLog('warning', 'Broadcast dispatcher encountered a transmission fault.');
    } finally {
      setIsAlertSubmitting(false);
    }
  };

  const handleDeactivateBroadcast = async (alertId: string) => {
    try {
      await onDeactivateAlert(alertId);
      addLog('info', `Deactivated alert broadcast ID: ${alertId}`);
    } catch (err) {
      console.error(err);
    }
  };

  // Module CRUD handlers
  const handleSaveModule = (e: React.FormEvent) => {
    e.preventDefault();
    if (isAddingModule) {
      const newMod: LearningModule = {
        id: `module-${Date.now()}`,
        title: newModuleTitle,
        category: newModuleCategory,
        difficulty: newModuleDifficulty,
        timeToComplete: newModuleTime,
        description: newModuleDesc,
        introduction: newModuleIntro,
        icon: "ShieldAlert",
        causes: ["Standard atmospheric destabilization", "Safety protocols failure"],
        beforeDisaster: ["Locate muster points", "Prepare basic supply backpacks"],
        duringDisaster: ["Evacuate building immediately", "Stay low and protect head"],
        afterDisaster: ["Verify roll call list", "Acknowledge Facilities clearance"],
        safetyTips: ["Always respect local marshals instructions"],
        imageUrl: "https://images.unsplash.com/photo-1590086782957-93c06ef21604?q=80&w=300",
        sections: [
          { title: "Theoretical Foundations", content: [newModuleDesc] },
          { title: "Immediate Action Procedures", content: ["Follow authorized egress charts immediately."] }
        ],
        drillSteps: [
          { step: 1, action: "Confirm Warning Signal", rationale: "Listen to designated sirens." },
          { step: 2, action: "Evacuate Safe Paths", rationale: "Walk cleanly to designated muster centers." }
        ]
      };
      const updated = [newMod, ...modulesList];
      syncModules(updated);
      addLog('info', `Added courses module: ${newModuleTitle}`);
      setIsAddingModule(false);
    } else if (editingModule) {
      const updated = modulesList.map(m => m.id === editingModule.id ? {
        ...m,
        title: newModuleTitle,
        category: newModuleCategory,
        difficulty: newModuleDifficulty,
        timeToComplete: newModuleTime,
        description: newModuleDesc,
        introduction: newModuleIntro
      } : m);
      syncModules(updated);
      addLog('info', `Edited courses module: ${newModuleTitle}`);
      setEditingModule(null);
    }
    // Reset forms
    setNewModuleTitle('');
    setNewModuleDesc('');
    setNewModuleIntro('');
  };

  const handleStartAddModule = () => {
    setIsAddingModule(true);
    setEditingModule(null);
    setNewModuleTitle('');
    setNewModuleCategory('natural');
    setNewModuleDifficulty('Beginner');
    setNewModuleTime('10 mins');
    setNewModuleDesc('');
    setNewModuleIntro('');
  };

  const handleStartEditModule = (mod: LearningModule) => {
    setEditingModule(mod);
    setIsAddingModule(false);
    setNewModuleTitle(mod.title);
    setNewModuleCategory(mod.category);
    setNewModuleDifficulty(mod.difficulty);
    setNewModuleTime(mod.timeToComplete);
    setNewModuleDesc(mod.description);
    setNewModuleIntro(mod.introduction || '');
  };

  const handleDeleteModule = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete module "${name}"?`)) {
      const updated = modulesList.filter(m => m.id !== id);
      syncModules(updated);
      addLog('warning', `Deleted learning module: ${name}`);
    }
  };

  // Quizzes CRUD handlers
  const handleSaveQuiz = (e: React.FormEvent) => {
    e.preventDefault();
    if (isAddingQuiz) {
      const newQuiz: Quiz = {
        id: `quiz-${Date.now()}`,
        title: newQuizTitle,
        moduleReference: newQuizModuleRef,
        questions: []
      };
      const updated = [newQuiz, ...quizzesList];
      syncQuizzes(updated);
      addLog('info', `Added safety quiz exam: ${newQuizTitle}`);
      setIsAddingQuiz(false);
    } else if (editingQuiz) {
      const updated = quizzesList.map(q => q.id === editingQuiz.id ? {
        ...q,
        title: newQuizTitle,
        moduleReference: newQuizModuleRef
      } : q);
      syncQuizzes(updated);
      addLog('info', `Updated safety quiz: ${newQuizTitle}`);
      setEditingQuiz(null);
    }
    setNewQuizTitle('');
    setNewQuizModuleRef('');
  };

  const handleStartAddQuiz = () => {
    setIsAddingQuiz(true);
    setEditingQuiz(null);
    setNewQuizTitle('');
    setNewQuizModuleRef('earthquake');
  };

  const handleStartEditQuiz = (qz: Quiz) => {
    setEditingQuiz(qz);
    setIsAddingQuiz(false);
    setNewQuizTitle(qz.title);
    setNewQuizModuleRef(qz.moduleReference);
  };

  const handleDeleteQuiz = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete quiz "${name}"?`)) {
      const updated = quizzesList.filter(q => q.id !== id);
      syncQuizzes(updated);
      addLog('warning', `Deleted quiz: ${name}`);
    }
  };

  const handleAddQuestionToQuiz = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingQuiz || !newQuestionText) return;
    const newQuest = {
      id: `q-${Date.now()}`,
      text: newQuestionText,
      options: newQuestionOptions.filter(o => o.trim() !== ''),
      correctAnswer: newQuestionCorrect,
      explanation: newQuestionExplanation
    };
    const updatedQuiz = {
      ...editingQuiz,
      questions: [...editingQuiz.questions, newQuest]
    };
    const updatedList = quizzesList.map(q => q.id === editingQuiz.id ? updatedQuiz : q);
    syncQuizzes(updatedList);
    setEditingQuiz(updatedQuiz);
    addLog('info', `Added question to quiz "${editingQuiz.title}"`);
    
    // Reset question form
    setNewQuestionText('');
    setNewQuestionOptions(['', '', '', '']);
    setNewQuestionCorrect(0);
    setNewQuestionExplanation('');
  };

  const handleDeleteQuestion = (qId: string) => {
    if (!editingQuiz) return;
    const updatedQuiz = {
      ...editingQuiz,
      questions: editingQuiz.questions.filter(q => q.id !== qId)
    };
    const updatedList = quizzesList.map(q => q.id === editingQuiz.id ? updatedQuiz : q);
    syncQuizzes(updatedList);
    setEditingQuiz(updatedQuiz);
    addLog('warning', `Deleted question from quiz "${editingQuiz.title}"`);
  };

  // Documents/Resources CRUD handlers
  const handleSaveDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (isAddingDoc) {
      const newD = {
        id: `doc-${Date.now()}`,
        title: newDocTitle,
        filename: newDocFilename || 'Custom-Manual.pdf',
        category: newDocCategory,
        description: newDocDesc,
        size: newDocSize || '1.2 MB',
        pages: [`--- PAGE 1: PROTOCOL DEFINITION ---\n${newDocDesc}`]
      };
      const updated = [newD, ...documentsList];
      syncDocuments(updated);
      addLog('info', `Added safety document manual: ${newDocTitle}`);
      setIsAddingDoc(false);
    } else if (editingDoc) {
      const updated = documentsList.map(d => d.id === editingDoc.id ? {
        ...d,
        title: newDocTitle,
        filename: newDocFilename,
        category: newDocCategory,
        description: newDocDesc,
        size: newDocSize
      } : d);
      syncDocuments(updated);
      addLog('info', `Updated safety document: ${newDocTitle}`);
      setEditingDoc(null);
    }
    setNewDocTitle('');
    setNewDocFilename('');
    setNewDocDesc('');
  };

  const handleDeleteDoc = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete document "${name}"?`)) {
      const updated = documentsList.filter(d => d.id !== id);
      syncDocuments(updated);
      addLog('warning', `Deleted safety document manual: ${name}`);
    }
  };

  // Users CRUD handlers
  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (isAddingUser) {
      const userObj = {
        ...newUserModel,
        studentId: newUserModel.role === 'student' ? (newUserModel.studentId || `STU-2026-${Math.floor(1000 + Math.random() * 9000)}`) : undefined
      };
      const updated = [userObj, ...usersList];
      syncUsers(updated);
      addLog('info', `Registered new credential profile: ${newUserModel.name} (${newUserModel.role.toUpperCase()})`);
      setIsAddingUser(false);
    } else if (editingUser) {
      const updated = usersList.map(u => u.email === editingUser.email ? {
        ...u,
        name: newUserModel.name,
        role: newUserModel.role,
        school: newUserModel.school,
        gradeLevel: newUserModel.gradeLevel,
        studentId: newUserModel.studentId
      } : u);
      syncUsers(updated);
      addLog('info', `Edited credential profile: ${newUserModel.name}`);
      setEditingUser(null);
    }
    setNewUserModel({
      name: '',
      email: '',
      role: 'student',
      school: 'Lincoln University',
      gradeLevel: 'Freshman Year',
      studentId: '',
      progress: { completedModules: [], completedQuizzes: {}, badgesEarned: [], riskAssessmentsCompleted: 0 }
    });
  };

  const handleStartEditUser = (usr: UserProfile) => {
    setEditingUser(usr);
    setIsAddingUser(false);
    setNewUserModel({ ...usr });
  };

  const handleDeleteUser = (email: string, name: string) => {
    if (confirm(`Are you sure you want to delete profile for "${name}"?`)) {
      const updated = usersList.filter(u => u.email !== email);
      syncUsers(updated);
      addLog('warning', `Revoked credentials access for: ${name}`);
    }
  };

  const handleClearReport = (id: string) => {
    if (confirm("Are you sure you want to archive / delete this audit compliance report?")) {
      const updated = reportsList.filter(r => r.id !== id);
      syncReports(updated);
      addLog('warning', `Archived hazard report ID: ${id}`);
    }
  };

  // Admin download copy of student certificates
  const handleDownloadCopyHTML = (studentName: string, school: string) => {
    const certId = `EDUSYS-77C${studentName.split(' ').map(n => n.charCodeAt(0) || 65).slice(0, 4).join('')}`;
    const timestamp = new Date().toLocaleDateString();
    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ResponseEd Certificate of Completion - ${studentName}</title>
  <style>
    body {
      background-color: #0b0f19;
      color: #f8fafc;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
      box-sizing: border-box;
    }
    .cert-container {
      background-color: #020617;
      border: 8px double rgba(245, 158, 11, 0.4);
      border-radius: 16px;
      padding: 50px 40px;
      max-width: 800px;
      width: 100%;
      text-align: center;
      position: relative;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
      box-sizing: border-box;
    }
    .title {
      color: #f59e0b;
      font-size: 28px;
      font-weight: 900;
      letter-spacing: 2px;
      text-transform: uppercase;
      margin: 10px 0;
    }
    .recipient {
      font-size: 32px;
      font-weight: 800;
      color: #ffffff;
      margin: 20px 0;
      border-bottom: 2px solid rgba(255, 255, 255, 0.1);
      display: inline-block;
      padding-bottom: 5px;
    }
  </style>
</head>
<body>
  <div class="cert-container">
    <div class="title">Certificate of Competency</div>
    <p>This certifies that</p>
    <div class="recipient">${studentName}</div>
    <p>of <strong>${school}</strong></p>
    <p>has passed all required campus emergency examinations.</p>
    <p>Serial Number: ${certId} • Generated on ${timestamp}</p>
  </div>
</body>
</html>`;
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ResponseEd_Certificate_${studentName.replace(/\s+/g, '_')}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addLog('info', `Downloaded safety credential copy for ${studentName}`);
  };

  // Filter students who have earned at least one certified passing quiz score >= 80%
  const certifiedUsers = usersList.filter(u => 
    Object.keys(u.progress.completedQuizzes).some(qid => u.progress.completedQuizzes[qid] >= 80)
  );

  return (
    <div className="space-y-6 animate-fade-in text-slate-100">
      
      {/* Visual Launcher Dashboard Hub Row */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-56 h-56 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-2xl space-y-3 z-10 relative">
          <span className="text-[10px] font-mono font-extrabold tracking-wider bg-red-500/10 text-red-400 px-2.5 py-1 rounded border border-red-500/20 uppercase">
            School Incident Command Console
          </span>
          <h1 className="text-2xl md:text-3xl font-black text-slate-100 tracking-tight flex items-center gap-2">
            <Cpu className="w-7 h-7 text-amber-500" />
            ResponseEd <span className="text-amber-500">Command Center</span>
          </h1>
          <p className="text-xs text-slate-400 leading-relaxed">
            Manage academic students, classroom courses, safety exam questionnaires, live alerts broadcast channels, and compliance hazard audits.
          </p>
        </div>
      </div>

      {/* Grid Tabs Selector Row */}
      <div className="flex flex-wrap gap-2 border-b border-slate-800 pb-3">
        {[
          { id: 'overview', name: 'Overview & Toggles', icon: Settings },
          { id: 'alerts', name: 'Alerts Dispatcher', icon: Bell },
          { id: 'modules', name: 'Courses & Modules', icon: BookOpen },
          { id: 'quizzes', name: 'Quizzes & Exams', icon: Award },
          { id: 'resources', name: 'Safety Library', icon: FileText },
          { id: 'users', name: 'Students & Staff', icon: Users },
          { id: 'reports', name: 'Hazard Reports', icon: Activity },
          { id: 'certificates', name: 'Certificates Claims', icon: FileBadge }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveAdminTab(tab.id as any);
                setEditingModule(null);
                setIsAddingModule(false);
                setEditingQuiz(null);
                setIsAddingQuiz(false);
                setEditingDoc(null);
                setIsAddingDoc(false);
                setEditingUser(null);
                setIsAddingUser(false);
              }}
              className={`flex items-center gap-1.5 px-3.5 py-2 border rounded-full text-xs font-bold transition-all cursor-pointer ${
                activeAdminTab === tab.id 
                  ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md shadow-amber-500/10' 
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {tab.name}
            </button>
          );
        })}
      </div>

      {/* Main Content Area based on Tab Selector */}
      <div className="bg-slate-950 border border-slate-850 rounded-2xl p-6 space-y-6">

        {/* ==========================================
            TAB 1: OVERVIEW & CONTROLS
            ========================================== */}
        {activeAdminTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              
              {/* Toggles settings card */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <h3 className="text-sm font-black uppercase tracking-wider text-slate-200 flex items-center gap-2 border-b border-slate-800 pb-2">
                  <Sliders className="w-4 h-4 text-amber-500" /> System Wide Safety Gates
                </h3>
                <div className="space-y-4 text-xs">
                  {/* Drill Mode Toggle */}
                  <div className="flex items-center justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-850">
                    <div className="space-y-1 pr-4">
                      <h4 className="font-bold text-slate-200">Campus Drill Mode Simulation</h4>
                      <p className="text-[10px] text-slate-500">Allow student-side alerts drills testing without panic warnings.</p>
                    </div>
                    <button onClick={() => setDrillMode(!drillMode)} className="text-amber-500">
                      {drillMode ? <ToggleRight className="w-10 h-10" /> : <ToggleLeft className="w-10 h-10 text-slate-600" />}
                    </button>
                  </div>

                  {/* Maintenance Lockdown Toggle */}
                  <div className="flex items-center justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-850">
                    <div className="space-y-1 pr-4">
                      <h4 className="font-bold text-slate-200">Maintenance Administrative Lockdown</h4>
                      <p className="text-[10px] text-slate-500">Temporarily freeze all interactive simulations and exam attempts.</p>
                    </div>
                    <button onClick={() => setMaintenanceMode(!maintenanceMode)} className="text-amber-500">
                      {maintenanceMode ? <ToggleRight className="w-10 h-10 text-red-500" /> : <ToggleLeft className="w-10 h-10 text-slate-600" />}
                    </button>
                  </div>

                  {/* Incident Level Selection */}
                  <div className="space-y-2 pt-2">
                    <label className="text-slate-400 font-bold block text-[10px] uppercase tracking-wider">Default Incident Command Mode</label>
                    <div className="grid grid-cols-3 gap-2">
                      {['Standard', 'Strict', 'EOC Only'].map((level) => (
                        <button
                          key={level}
                          type="button"
                          onClick={() => setSecurityClearance(level as any)}
                          className={`py-2 px-3 border rounded-xl text-[10px] font-black uppercase transition-all cursor-pointer ${
                            securityClearance === level 
                              ? 'bg-amber-500/15 text-amber-400 border-amber-500' 
                              : 'bg-slate-950 text-slate-500 border-slate-850 hover:bg-slate-900 hover:text-slate-300'
                          }`}
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Counts metrics display */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <h3 className="text-sm font-black uppercase tracking-wider text-slate-200 flex items-center gap-2 border-b border-slate-800 pb-2">
                  <Database className="w-4 h-4 text-amber-500" /> Active Registry Totals
                </h3>
                <div className="grid grid-cols-2 gap-4 text-xs font-semibold">
                  <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl space-y-1">
                    <span className="text-slate-500 font-mono text-[9px] uppercase tracking-widest block">Registered Profiles</span>
                    <span className="text-lg text-slate-100 font-mono font-bold">{usersList.length} Active Accounts</span>
                  </div>
                  <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl space-y-1">
                    <span className="text-slate-500 font-mono text-[9px] uppercase tracking-widest block">Classroom Courses</span>
                    <span className="text-lg text-slate-100 font-mono font-bold">{modulesList.length} Safety Courses</span>
                  </div>
                  <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl space-y-1">
                    <span className="text-slate-500 font-mono text-[9px] uppercase tracking-widest block">Risk Assessments</span>
                    <span className="text-lg text-slate-100 font-mono font-bold">{reportsList.length} Field Reports</span>
                  </div>
                  <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl space-y-1">
                    <span className="text-slate-500 font-mono text-[9px] uppercase tracking-widest block">Certificates Issued</span>
                    <span className="text-lg text-slate-100 font-mono font-bold">{certifiedUsers.length} Issued</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Live streaming logs */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-amber-500 animate-pulse" />
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-200">Live Incident Command Stream</h3>
                </div>
                <span className="text-[9px] font-mono font-bold text-emerald-400 flex items-center gap-1.5 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" /> CORE MONITORS DISPATCHED
                </span>
              </div>
              <div className="bg-slate-950 rounded-xl border border-slate-850 p-4 font-mono text-[10px] leading-relaxed text-slate-400 space-y-2 max-h-52 overflow-y-auto">
                {logsList.map((log) => (
                  <div key={log.id} className="flex gap-4 items-start hover:text-slate-200">
                    <span className="text-slate-600 shrink-0 select-none">[{log.timestamp}]</span>
                    <span className={`uppercase font-bold shrink-0 ${
                      log.type === 'alert' ? 'text-red-500' : log.type === 'warning' ? 'text-amber-500' : log.type === 'security' ? 'text-indigo-400' : 'text-blue-500'
                    }`}>
                      {log.type}
                    </span>
                    <span className="flex-1 text-slate-300 leading-normal">{log.message}</span>
                    <span className="text-slate-600 shrink-0">@{log.user}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ==========================================
            TAB 2: EMERGENCY ALERTS DISPATCHER (LIVE)
            ========================================== */}
        {activeAdminTab === 'alerts' && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Trigger/Broadcast Form */}
              <form onSubmit={handleAlertBroadcast} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-200 flex items-center gap-2 border-b border-slate-800 pb-2">
                  <Bell className="w-4 h-4 text-red-500" /> Dispatch New Campus Alert
                </h3>
                
                <div className="space-y-3 text-xs">
                  <div className="space-y-1">
                    <label className="text-slate-400 font-bold block">Incident Title</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Active Chemical Lab Spill Drill" 
                      value={newAlertTitle}
                      onChange={(e) => setNewAlertTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:border-amber-500 focus:outline-none"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-400 font-bold block">Broadcast Message / Egress Path Instructions</label>
                    <textarea 
                      placeholder="Specify evacuation paths, mustering zones, and urgent physical actions." 
                      rows={3}
                      value={newAlertMessage}
                      onChange={(e) => setNewAlertMessage(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:border-amber-500 focus:outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">Severity Level</label>
                      <select 
                        value={newAlertSeverity}
                        onChange={(e: any) => setNewAlertSeverity(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      >
                        <option value="low">Low Advisory</option>
                        <option value="medium">Medium Warning</option>
                        <option value="high">Critical Danger</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">Category Classification</label>
                      <select 
                        value={newAlertType}
                        onChange={(e: any) => setNewAlertType(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      >
                        <option value="drill">Simulation Drill</option>
                        <option value="real_emergency">Real-time Emergency</option>
                        <option value="advisory">Policy Advisory</option>
                      </select>
                    </div>
                  </div>

                  <button 
                    type="submit" 
                    disabled={isAlertSubmitting}
                    className="w-full bg-red-600 hover:bg-red-700 disabled:bg-slate-800 text-white font-black py-3 rounded-xl uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-red-600/10"
                  >
                    <Send className="w-4 h-4" />
                    {isAlertSubmitting ? "Transmitting Signal..." : "Transmit Broadcast Signal"}
                  </button>
                </div>
              </form>

              {/* Active Broadcast Queue */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-200 flex items-center gap-2 border-b border-slate-800 pb-2">
                  <Activity className="w-4 h-4 text-emerald-500 animate-pulse" /> Live Broadcast Queue
                </h3>
                <div className="space-y-3.5 max-h-96 overflow-y-auto pr-1">
                  {alerts.length === 0 ? (
                    <div className="text-center py-10 text-slate-500 text-xs font-medium">
                      No active emergency alerts currently transmitting on network.
                    </div>
                  ) : (
                    alerts.map((alert) => (
                      <div 
                        key={alert.id} 
                        className={`p-4 rounded-xl border flex flex-col justify-between space-y-3 ${
                          alert.isActive 
                            ? alert.severity === 'high' 
                              ? 'bg-red-950/20 border-red-900/40 text-red-100' 
                              : 'bg-slate-950 border-amber-900/30 text-amber-200'
                            : 'bg-slate-950/40 border-slate-900 text-slate-500'
                        }`}
                      >
                        <div className="flex justify-between items-start gap-2">
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-xs font-extrabold">{alert.title}</span>
                              <span className={`text-[8px] uppercase tracking-widest font-mono font-bold px-1.5 py-0.5 rounded ${
                                alert.severity === 'high' ? 'bg-red-500/10 text-red-400' : 'bg-slate-800 text-slate-400'
                              }`}>
                                {alert.severity} • {alert.type}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">{alert.message}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[9px] font-mono border-t border-slate-900/60 pt-2 text-slate-500">
                          <span>Sender: {alert.sender}</span>
                          <span>{new Date(alert.timestamp).toLocaleTimeString()}</span>
                        </div>

                        {alert.isActive && (
                          <button
                            onClick={() => handleDeactivateBroadcast(alert.id)}
                            className="bg-red-500/10 hover:bg-red-500 hover:text-white border border-red-500/20 transition-all text-red-400 font-bold py-1 px-2 rounded-lg text-[9px] uppercase tracking-wider self-end"
                          >
                            Deactivate Broadcast
                          </button>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ==========================================
            TAB 3: COURSES & MODULES MANAGEMENT
            ========================================== */}
        {activeAdminTab === 'modules' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-200 flex items-center gap-2">
                <Book className="w-5 h-5 text-amber-500" /> Dynamic Campus Safety Courses
              </h3>
              <button 
                onClick={handleStartAddModule}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2 px-3.5 rounded-xl text-xs flex items-center gap-1.5 shadow-md"
              >
                <Plus className="w-4 h-4" /> Create Course Module
              </button>
            </div>

            {/* Editing Panel Drawer */}
            {(editingModule || isAddingModule) && (
              <form onSubmit={handleSaveModule} className="bg-slate-900 border-2 border-amber-500/20 rounded-2xl p-6 space-y-4 animate-scale-in">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <h4 className="text-xs font-black uppercase text-amber-500">
                    {isAddingModule ? "Create New Campus Safety Course" : `Edit Course Module: ${editingModule?.title}`}
                  </h4>
                  <button type="button" onClick={() => { setEditingModule(null); setIsAddingModule(false); }} className="text-slate-400 hover:text-slate-200">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1">
                    <label className="text-slate-400 font-bold block">Course Title</label>
                    <input 
                      type="text" 
                      value={newModuleTitle}
                      onChange={(e) => setNewModuleTitle(e.target.value)}
                      placeholder="e.g. Radiological Threat Safe Postures"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">Domain Category</label>
                      <select 
                        value={newModuleCategory}
                        onChange={(e: any) => setNewModuleCategory(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      >
                        <option value="natural">Natural</option>
                        <option value="manmade">Manmade</option>
                        <option value="health">Health</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">Difficulty</label>
                      <select 
                        value={newModuleDifficulty}
                        onChange={(e: any) => setNewModuleDifficulty(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      >
                        <option value="Beginner">Beginner</option>
                        <option value="Intermediate">Intermediate</option>
                        <option value="Advanced">Advanced</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">Time Commitment</label>
                      <input 
                        type="text" 
                        value={newModuleTime}
                        onChange={(e) => setNewModuleTime(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-1 md:col-span-2">
                    <label className="text-slate-400 font-bold block">Brief Overview / Description</label>
                    <textarea 
                      value={newModuleDesc}
                      onChange={(e) => setNewModuleDesc(e.target.value)}
                      rows={2}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      required
                    />
                  </div>

                  <div className="space-y-1 md:col-span-2">
                    <label className="text-slate-400 font-bold block">Course Introduction / Lesson Header</label>
                    <textarea 
                      value={newModuleIntro}
                      onChange={(e) => setNewModuleIntro(e.target.value)}
                      rows={2}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      placeholder="Introductory material displaying to students when opening this course."
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 text-xs">
                  <button type="button" onClick={() => { setEditingModule(null); setIsAddingModule(false); }} className="bg-slate-950 hover:bg-slate-850 text-slate-300 py-2.5 px-4 rounded-xl border border-slate-800">
                    Discard
                  </button>
                  <button type="submit" className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2.5 px-6 rounded-xl flex items-center gap-1 cursor-pointer">
                    <Save className="w-4 h-4" /> Save Course
                  </button>
                </div>
              </form>
            )}

            {/* List Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider font-mono">
                    <th className="p-4">Module Name</th>
                    <th className="p-4">Domain Category</th>
                    <th className="p-4">Difficulty</th>
                    <th className="p-4">Duration</th>
                    <th className="p-4 text-right">Administrative Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {modulesList.map((mod) => (
                    <tr key={mod.id} className="hover:bg-slate-900/40">
                      <td className="p-4 font-bold text-slate-100">{mod.title}</td>
                      <td className="p-4 capitalize">
                        <span className={`px-2.5 py-1 rounded border text-[10px] font-bold ${
                          mod.category === 'natural' ? 'bg-sky-500/10 text-sky-400 border-sky-500/20' :
                          mod.category === 'manmade' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' :
                          'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        }`}>
                          {mod.category}
                        </span>
                      </td>
                      <td className="p-4">
                        <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-[10px] font-mono text-slate-400">
                          {mod.difficulty}
                        </span>
                      </td>
                      <td className="p-4 font-mono">{mod.timeToComplete}</td>
                      <td className="p-4 text-right flex gap-1.5 justify-end">
                        <button 
                          onClick={() => handleStartEditModule(mod)}
                          className="bg-slate-900 hover:bg-slate-800 text-amber-500 p-2 rounded-lg border border-slate-800 transition-colors cursor-pointer"
                          title="Edit"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleDeleteModule(mod.id, mod.title)}
                          className="bg-slate-900 hover:bg-slate-800 text-red-400 p-2 rounded-lg border border-slate-800 transition-colors cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ==========================================
            TAB 4: QUIZZES & EXAMS
            ========================================== */}
        {activeAdminTab === 'quizzes' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-200 flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-500" /> Certified Safety Exams
              </h3>
              <button 
                onClick={handleStartAddQuiz}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2 px-3.5 rounded-xl text-xs flex items-center gap-1.5 shadow-md"
              >
                <Plus className="w-4 h-4" /> Create Safety Exam
              </button>
            </div>

            {/* Create/Edit Quiz Details form */}
            {(isAddingQuiz || (editingQuiz && !newQuestionText)) && (
              <form onSubmit={handleSaveQuiz} className="bg-slate-900 border-2 border-amber-500/20 rounded-2xl p-6 space-y-4 animate-scale-in">
                <h4 className="text-xs font-black uppercase text-amber-500 border-b border-slate-800 pb-1">
                  {isAddingQuiz ? "Configure New Exam Parameters" : `Edit Exam Parameters: ${editingQuiz?.title}`}
                </h4>
                <div className="grid md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1">
                    <label className="text-slate-400 font-bold block">Exam / Quiz Title</label>
                    <input 
                      type="text" 
                      value={newQuizTitle}
                      onChange={(e) => setNewQuizTitle(e.target.value)}
                      placeholder="e.g. Science Laboratory Hazards Examination"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-400 font-bold block">Link to Safety Course (Module reference ID)</label>
                    <select 
                      value={newQuizModuleRef}
                      onChange={(e) => setNewQuizModuleRef(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                    >
                      {modulesList.map(m => (
                        <option key={m.id} value={m.id}>{m.title}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex justify-end gap-2 text-xs">
                  <button type="button" onClick={() => { setEditingQuiz(null); setIsAddingQuiz(false); }} className="bg-slate-950 hover:bg-slate-850 text-slate-300 py-2.5 px-4 rounded-xl border border-slate-800">
                    Discard
                  </button>
                  <button type="submit" className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2.5 px-6 rounded-xl flex items-center gap-1 cursor-pointer">
                    <Save className="w-4 h-4" /> Save Exam
                  </button>
                </div>
              </form>
            )}

            {/* Questions Management inside active edit quiz */}
            {editingQuiz && (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <div>
                    <h4 className="text-sm font-black text-amber-500 uppercase">Question Bank Manager</h4>
                    <p className="text-[10px] text-slate-400">Exam Name: {editingQuiz.title} • Module: {editingQuiz.moduleReference}</p>
                  </div>
                  <button onClick={() => setEditingQuiz(null)} className="text-slate-400 hover:text-slate-200 bg-slate-950 p-2 rounded-xl border border-slate-850">
                    Done Managing Questions
                  </button>
                </div>

                {/* Question List */}
                <div className="space-y-3">
                  <h5 className="text-xs font-black uppercase text-slate-300 tracking-wider">Current Exam Questions ({editingQuiz.questions.length})</h5>
                  {editingQuiz.questions.length === 0 ? (
                    <div className="text-center py-6 text-slate-500 text-xs">No questions loaded in this exam. Add one below.</div>
                  ) : (
                    editingQuiz.questions.map((quest, idx) => (
                      <div key={quest.id} className="p-4 bg-slate-950 rounded-xl border border-slate-850 space-y-2 relative text-xs">
                        <button 
                          onClick={() => handleDeleteQuestion(quest.id)}
                          className="absolute top-4 right-4 text-red-400 hover:text-red-500 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <div className="font-bold text-slate-100 flex gap-2">
                          <span className="text-amber-500 font-mono">Q{idx + 1}.</span>
                          <span>{quest.text}</span>
                        </div>
                        <div className="grid sm:grid-cols-2 gap-2 text-[11px] text-slate-400 pl-6">
                          {quest.options.map((opt, oIdx) => (
                            <div key={oIdx} className={oIdx === quest.correctAnswer ? "text-emerald-400 font-bold" : ""}>
                              {oIdx === quest.correctAnswer ? "🟢 " : "⚪ "} {opt}
                            </div>
                          ))}
                        </div>
                        <p className="text-[10px] text-slate-500 pl-6 leading-relaxed italic border-t border-slate-900/60 pt-1">
                          <strong>Rationale:</strong> {quest.explanation}
                        </p>
                      </div>
                    ))
                  )}
                </div>

                {/* Form to append question */}
                <form onSubmit={handleAddQuestionToQuiz} className="bg-slate-950 p-5 rounded-xl border border-slate-850 space-y-4 text-xs">
                  <h5 className="font-black uppercase text-amber-500 text-[11px] tracking-wider border-b border-slate-900 pb-2">Add Question to Bank</h5>
                  
                  <div className="space-y-1">
                    <label className="text-slate-400 font-bold block">Question Prompt</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Which containment cabinet is required for strong hydrochloric acid?"
                      value={newQuestionText}
                      onChange={(e) => setNewQuestionText(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-slate-200 font-semibold focus:outline-none"
                      required
                    />
                  </div>

                  <div className="grid sm:grid-cols-2 gap-3">
                    {newQuestionOptions.map((opt, oIdx) => (
                      <div key={oIdx} className="space-y-1">
                        <label className="text-slate-500 font-bold block">Option {String.fromCharCode(65 + oIdx)}</label>
                        <input 
                          type="text" 
                          value={opt}
                          onChange={(e) => {
                            const updated = [...newQuestionOptions];
                            updated[oIdx] = e.target.value;
                            setNewQuestionOptions(updated);
                          }}
                          className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-slate-200 font-medium focus:outline-none"
                          required
                        />
                      </div>
                    ))}
                  </div>

                  <div className="grid sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">Correct Option Index</label>
                      <select 
                        value={newQuestionCorrect}
                        onChange={(e: any) => setNewQuestionCorrect(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-slate-200 font-medium focus:outline-none"
                      >
                        <option value="0">Option A</option>
                        <option value="1">Option B</option>
                        <option value="2">Option C</option>
                        <option value="3">Option D</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">Safety Science Rationale (Explanation)</label>
                      <input 
                        type="text" 
                        placeholder="Explain why this choice is correct under safety standards."
                        value={newQuestionExplanation}
                        onChange={(e) => setNewQuestionExplanation(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-slate-200 font-medium focus:outline-none"
                        required
                      />
                    </div>
                  </div>

                  <button 
                    type="submit" 
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-2.5 rounded-xl uppercase tracking-wider"
                  >
                    Append Question to Bank
                  </button>
                </form>
              </div>
            )}

            {/* List table */}
            {!editingQuiz && (
              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider font-mono">
                      <th className="p-4">Exam / Quiz Title</th>
                      <th className="p-4">Linked Safety Course</th>
                      <th className="p-4">Questions Count</th>
                      <th className="p-4 text-right">Administrative Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850">
                    {quizzesList.map((qz) => (
                      <tr key={qz.id} className="hover:bg-slate-900/40">
                        <td className="p-4 font-bold text-slate-100">{qz.title}</td>
                        <td className="p-4 capitalize font-mono text-slate-400">{qz.moduleReference.replace('_', ' ')}</td>
                        <td className="p-4 font-mono font-bold text-amber-500">{qz.questions.length} Items</td>
                        <td className="p-4 text-right flex gap-1.5 justify-end">
                          <button 
                            onClick={() => handleStartEditQuiz(qz)}
                            className="bg-slate-900 hover:bg-slate-850 text-amber-500 py-1.5 px-3 rounded-lg border border-slate-800 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" /> Manage Questions
                          </button>
                          <button 
                            onClick={() => handleDeleteQuiz(qz.id, qz.title)}
                            className="bg-slate-900 hover:bg-slate-800 text-red-400 p-2 rounded-lg border border-slate-800 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* ==========================================
            TAB 5: RESOURCES DIRECTORY (PDF MANUALS)
            ========================================== */}
        {activeAdminTab === 'resources' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-200 flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-500" /> Resources Download Directory
              </h3>
              <button 
                onClick={() => { setIsAddingDoc(true); setEditingDoc(null); setNewDocTitle(''); setNewDocDesc(''); }}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2 px-3.5 rounded-xl text-xs flex items-center gap-1.5 shadow-md"
              >
                <Plus className="w-4 h-4" /> Upload Safety Document
              </button>
            </div>

            {/* Create form */}
            {(isAddingDoc || editingDoc) && (
              <form onSubmit={handleSaveDoc} className="bg-slate-900 border-2 border-amber-500/20 rounded-2xl p-6 space-y-4 animate-scale-in">
                <h4 className="text-xs font-black uppercase text-amber-500 border-b border-slate-800 pb-1">
                  Upload Safety Reference Manual
                </h4>
                <div className="grid md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1">
                    <label className="text-slate-400 font-bold block">Document Title</label>
                    <input 
                      type="text" 
                      value={newDocTitle}
                      onChange={(e) => setNewDocTitle(e.target.value)}
                      placeholder="e.g. Science Laboratory HazMat Blueprint"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">Filename (.pdf)</label>
                      <input 
                        type="text" 
                        value={newDocFilename}
                        onChange={(e) => setNewDocFilename(e.target.value)}
                        placeholder="Science-Lab-Safety.pdf"
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">File Size</label>
                      <input 
                        type="text" 
                        value={newDocSize}
                        onChange={(e) => setNewDocSize(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">Category Tag</label>
                      <select 
                        value={newDocCategory}
                        onChange={(e) => setNewDocCategory(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      >
                        <option value="general">General</option>
                        <option value="tactical">Tactical</option>
                        <option value="chemical">Chemical</option>
                        <option value="natural">Natural</option>
                        <option value="medical">Medical</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1 md:col-span-2">
                    <label className="text-slate-400 font-bold block">Resource Description</label>
                    <textarea 
                      value={newDocDesc}
                      onChange={(e) => setNewDocDesc(e.target.value)}
                      rows={2}
                      placeholder="Describe the target audience, purpose, and key survival procedures included."
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 text-xs">
                  <button type="button" onClick={() => { setEditingDoc(null); setIsAddingDoc(false); }} className="bg-slate-950 hover:bg-slate-850 text-slate-300 py-2.5 px-4 rounded-xl border border-slate-800">
                    Discard
                  </button>
                  <button type="submit" className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2.5 px-6 rounded-xl flex items-center gap-1 cursor-pointer">
                    <Save className="w-4 h-4" /> Publish Reference Manual
                  </button>
                </div>
              </form>
            )}

            {/* List Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider font-mono">
                    <th className="p-4">Document Title</th>
                    <th className="p-4">Filename</th>
                    <th className="p-4">Size</th>
                    <th className="p-4">Category</th>
                    <th className="p-4 text-right">Administrative Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {documentsList.map((doc) => (
                    <tr key={doc.id} className="hover:bg-slate-900/40">
                      <td className="p-4 font-bold text-slate-100">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-amber-500" />
                          <div>
                            <div>{doc.title}</div>
                            <div className="text-[10px] text-slate-500 font-normal leading-normal">{doc.description}</div>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 font-mono text-slate-400">{doc.filename}</td>
                      <td className="p-4 font-mono text-slate-400">{doc.size}</td>
                      <td className="p-4 capitalize">
                        <span className="bg-slate-900 px-2.5 py-0.5 rounded border border-slate-800 text-[10px] text-slate-400">
                          {doc.category}
                        </span>
                      </td>
                      <td className="p-4 text-right flex gap-1.5 justify-end">
                        <button 
                          onClick={() => handleDeleteDoc(doc.id, doc.title)}
                          className="bg-slate-900 hover:bg-slate-800 text-red-400 p-2 rounded-lg border border-slate-800 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ==========================================
            TAB 6: STUDENTS & USERS ACCOUNTS
            ========================================== */}
        {activeAdminTab === 'users' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-200 flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-500" /> Safety User Database
              </h3>
              <button 
                onClick={() => { setIsAddingUser(true); setEditingUser(null); }}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2 px-3.5 rounded-xl text-xs flex items-center gap-1.5 shadow-md"
              >
                <Plus className="w-4 h-4" /> Register New Account
              </button>
            </div>

            {/* Create/Edit User Profile Form */}
            {(isAddingUser || editingUser) && (
              <form onSubmit={handleSaveUser} className="bg-slate-900 border-2 border-amber-500/20 rounded-2xl p-6 space-y-4 animate-scale-in">
                <h4 className="text-xs font-black uppercase text-amber-500 border-b border-slate-800 pb-1">
                  {isAddingUser ? "Register Safety Profile credentials" : `Edit Security Profile: ${editingUser?.name}`}
                </h4>
                <div className="grid md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1">
                    <label className="text-slate-400 font-bold block">Account Full Name</label>
                    <input 
                      type="text" 
                      value={newUserModel.name}
                      onChange={(e) => setNewUserModel({ ...newUserModel, name: e.target.value })}
                      placeholder="Alex Rivera"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-400 font-bold block">Email Address (Login Username)</label>
                    <input 
                      type="email" 
                      value={newUserModel.email}
                      disabled={!!editingUser}
                      onChange={(e) => setNewUserModel({ ...newUserModel, email: e.target.value })}
                      placeholder="alex.rivera@lincolnu.edu"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none disabled:bg-slate-900 disabled:text-slate-600"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3 md:col-span-2">
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">Role Assignment</label>
                      <select 
                        value={newUserModel.role}
                        onChange={(e: any) => setNewUserModel({ ...newUserModel, role: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                      >
                        <option value="student">Student</option>
                        <option value="teacher">Teacher / Faculty</option>
                        <option value="admin">System Administrator</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold block">School / Campus Affiliation</label>
                      <input 
                        type="text" 
                        value={newUserModel.school}
                        onChange={(e) => setNewUserModel({ ...newUserModel, school: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                        required
                      />
                    </div>
                  </div>

                  {newUserModel.role === 'student' && (
                    <div className="grid grid-cols-2 gap-3 md:col-span-2 animate-fade-in">
                      <div className="space-y-1">
                        <label className="text-slate-400 font-bold block">Grade Year Level</label>
                        <input 
                          type="text" 
                          placeholder="Sophomore Year"
                          value={newUserModel.gradeLevel || ''}
                          onChange={(e) => setNewUserModel({ ...newUserModel, gradeLevel: e.target.value })}
                          className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-slate-400 font-bold block">Unique Student ID #</label>
                        <input 
                          type="text" 
                          placeholder="STU-2026-XXXX"
                          value={newUserModel.studentId || ''}
                          onChange={(e) => setNewUserModel({ ...newUserModel, studentId: e.target.value })}
                          className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-slate-200 font-medium focus:outline-none"
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex justify-end gap-2 text-xs">
                  <button type="button" onClick={() => { setEditingUser(null); setIsAddingUser(false); }} className="bg-slate-950 hover:bg-slate-850 text-slate-300 py-2.5 px-4 rounded-xl border border-slate-800">
                    Discard
                  </button>
                  <button type="submit" className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2.5 px-6 rounded-xl flex items-center gap-1 cursor-pointer">
                    <Save className="w-4 h-4" /> Save Security Profile
                  </button>
                </div>
              </form>
            )}

            {/* List Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider font-mono">
                    <th className="p-4">User Details</th>
                    <th className="p-4">Login Email</th>
                    <th className="p-4">School</th>
                    <th className="p-4">Security Role</th>
                    <th className="p-4">Exam Badges</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {usersList.map((usr) => (
                    <tr key={usr.email} className="hover:bg-slate-900/40">
                      <td className="p-4 font-bold text-slate-100">
                        <div>
                          <div>{usr.name}</div>
                          {usr.studentId && <div className="text-[10px] text-slate-500 font-mono font-normal">Student ID: {usr.studentId}</div>}
                        </div>
                      </td>
                      <td className="p-4 font-mono text-slate-400">{usr.email}</td>
                      <td className="p-4 text-slate-400">{usr.school}</td>
                      <td className="p-4 capitalize">
                        <span className={`px-2.5 py-1 rounded border text-[9px] font-black uppercase ${
                          usr.role === 'admin' ? 'bg-red-500/10 text-red-400 border-red-500/20 animate-pulse' :
                          usr.role === 'teacher' ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' :
                          'bg-blue-500/10 text-blue-400 border-blue-500/20'
                        }`}>
                          {usr.role}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex flex-wrap gap-1">
                          {usr.progress.badgesEarned.length === 0 ? (
                            <span className="text-slate-600 text-[10px] font-medium">- No Badges -</span>
                          ) : (
                            usr.progress.badgesEarned.map(badge => (
                              <span key={badge} className="bg-slate-900 text-amber-500 border border-amber-500/10 rounded px-1.5 py-0.5 text-[8px] font-bold">
                                🎖️ {badge}
                              </span>
                            ))
                          )}
                        </div>
                      </td>
                      <td className="p-4 text-right flex gap-1.5 justify-end">
                        <button 
                          onClick={() => handleStartEditUser(usr)}
                          className="bg-slate-900 hover:bg-slate-800 text-amber-500 p-2 rounded-lg border border-slate-800 transition-colors cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleDeleteUser(usr.email, usr.name)}
                          className="bg-slate-900 hover:bg-slate-800 text-red-400 p-2 rounded-lg border border-slate-800 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ==========================================
            TAB 7: COMPLIANCE HAZARD AUDIT REPORTS
            ========================================== */}
        {activeAdminTab === 'reports' && (
          <div className="space-y-6">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-200 flex items-center gap-2 border-b border-slate-800 pb-3">
              <Activity className="w-5 h-5 text-amber-500" /> Campus Audit Submissions Browser
            </h3>

            {reportsList.length === 0 ? (
              <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl text-slate-500 text-xs font-semibold">
                No school hazard audit compliance reports submitted yet.
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {reportsList.map((rep) => (
                  <div key={rep.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-mono text-slate-500">{rep.date}</span>
                        <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded border ${
                          rep.finalScore >= 90 ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                          rep.finalScore >= 75 ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                          'bg-red-500/10 text-red-400 border-red-500/20'
                        }`}>
                          Score: {rep.finalScore}%
                        </span>
                      </div>
                      
                      <div className="space-y-0.5">
                        <h4 className="font-bold text-slate-200 text-sm flex items-center gap-1.5">
                          <Building className="w-4 h-4 text-blue-400" /> {rep.schoolName}
                        </h4>
                        <p className="text-[10px] text-slate-400">Assessed by: <strong>{rep.assessorName}</strong> ({rep.assessorRole})</p>
                      </div>

                      <div className="grid grid-cols-3 gap-1 pt-2 border-t border-slate-950 text-center font-mono text-[9px] text-slate-500">
                        <div>
                          <div className="text-red-400 font-bold">{rep.priorityBreakdown?.critical || 0}</div>
                          <div>Critical</div>
                        </div>
                        <div>
                          <div className="text-amber-400 font-bold">{rep.priorityBreakdown?.high || 0}</div>
                          <div>High</div>
                        </div>
                        <div>
                          <div className="text-slate-400 font-bold">{rep.priorityBreakdown?.medium || 0}</div>
                          <div>Medium</div>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2 justify-end pt-2 border-t border-slate-950">
                      <button 
                        onClick={() => setSelectedReport(rep)}
                        className="bg-slate-950 hover:bg-slate-850 text-slate-200 border border-slate-800 font-bold py-1.5 px-3 rounded-lg text-[10px] uppercase flex items-center gap-1 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" /> View Report
                      </button>
                      <button 
                        onClick={() => handleClearReport(rep.id)}
                        className="bg-slate-950 hover:bg-slate-850 text-red-400 border border-slate-800 p-1.5 rounded-lg transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* View audit modal window */}
            {selectedReport && (
              <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in text-xs">
                <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col justify-between overflow-hidden shadow-2xl">
                  
                  {/* Header */}
                  <div className="bg-slate-950 p-6 border-b border-slate-800 flex justify-between items-center">
                    <div className="space-y-1">
                      <h4 className="text-base font-black uppercase tracking-tight text-white flex items-center gap-2">
                        <Building className="w-5 h-5 text-amber-500 animate-pulse" /> 
                        {selectedReport.schoolName} Safety Compliance Report
                      </h4>
                      <p className="text-[10px] text-slate-400 font-mono">Assessed: {selectedReport.date} • Score: {selectedReport.finalScore}/100</p>
                    </div>
                    <button onClick={() => setSelectedReport(null)} className="text-slate-400 hover:text-slate-200 p-1.5 bg-slate-900 border border-slate-800 rounded-lg">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Body Content */}
                  <div className="p-6 overflow-y-auto space-y-6 text-slate-300 leading-relaxed max-h-[55vh]">
                    <div className="bg-slate-950 p-4 border border-slate-850 rounded-2xl flex items-center justify-between">
                      <div className="space-y-1">
                        <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Lead Auditor Profile</span>
                        <div className="font-bold text-slate-200">{selectedReport.assessorName}</div>
                        <div className="text-[10px] font-mono text-slate-500 capitalize">Role: {selectedReport.assessorRole}</div>
                      </div>
                      
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Compliance Rating</span>
                        <div className={`text-xl font-mono font-black ${
                          selectedReport.finalScore >= 90 ? 'text-emerald-400' : 'text-amber-400'
                        }`}>
                          {selectedReport.finalScore >= 90 ? "🛡️ Class-A standards" : "⚠️ Class-B standards"}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3.5">
                      <h5 className="font-extrabold uppercase text-slate-200 text-xs border-b border-slate-800 pb-1">Recommended Remedial Actions</h5>
                      {selectedReport.recommendations && selectedReport.recommendations.length > 0 ? (
                        <div className="space-y-3">
                          {selectedReport.recommendations.map((rec: any, idx: number) => (
                            <div key={idx} className="p-3.5 bg-slate-950 rounded-xl border border-red-500/15 space-y-1.5">
                              <div className="flex justify-between items-start flex-wrap gap-2">
                                <span className="font-bold text-slate-200 text-[11px] leading-tight flex-1">⚠️ {rec.question}</span>
                                <span className="text-[8px] uppercase tracking-widest font-mono font-bold bg-red-500/10 text-red-400 border border-red-500/20 px-1.5 py-0.5 rounded">
                                  {rec.priority}
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-400 font-medium"><strong>Mitigation:</strong> {rec.tip}</p>
                              <div className="flex justify-between text-[8px] font-mono text-slate-500 pt-1 border-t border-slate-900/60">
                                <span>Responsible: {rec.department}</span>
                                <span>Egress Domain: {rec.category}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-4 text-emerald-400 text-xs font-semibold">🟢 Zero vulnerabilities detected. Pristine FEMA alignment!</div>
                      )}
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="bg-slate-950 p-5 border-t border-slate-800 flex justify-end">
                    <button 
                      onClick={() => setSelectedReport(null)}
                      className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2.5 px-6 rounded-xl uppercase tracking-wider"
                    >
                      Acknowledge Report
                    </button>
                  </div>

                </div>
              </div>
            )}

          </div>
        )}

        {/* ==========================================
            TAB 8: CERTIFICATES ISSUED & BADGES
            ========================================== */}
        {activeAdminTab === 'certificates' && (
          <div className="space-y-6">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-200 flex items-center gap-2 border-b border-slate-800 pb-3">
              <FileBadge className="w-5 h-5 text-amber-500" /> Safety Competency Credentials Tracker
            </h3>

            {certifiedUsers.length === 0 ? (
              <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl text-slate-500 text-xs font-semibold">
                No students or users have completed all safety competency exams with a passing grade (80%+) yet.
              </div>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider font-mono">
                      <th className="p-4">Certified Graduate</th>
                      <th className="p-4">Affiliated School</th>
                      <th className="p-4">Passed Safety Exams</th>
                      <th className="p-4">Earned Badges</th>
                      <th className="p-4 text-right">Official Documents</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850">
                    {certifiedUsers.map((usr) => {
                      const passedCount = Object.keys(usr.progress.completedQuizzes).filter(qid => usr.progress.completedQuizzes[qid] >= 80).length;
                      return (
                        <tr key={usr.email} className="hover:bg-slate-900/40">
                          <td className="p-4 font-bold text-slate-100">{usr.name}</td>
                          <td className="p-4 text-slate-400 font-medium">{usr.school}</td>
                          <td className="p-4 font-mono font-bold text-emerald-400">{passedCount} Exams Passed</td>
                          <td className="p-4">
                            <div className="flex flex-wrap gap-1">
                              {usr.progress.badgesEarned.map(badge => (
                                <span key={badge} className="bg-slate-900 text-amber-400 border border-amber-500/10 rounded px-2 py-0.5 text-[8px] font-bold">
                                  🎖️ {badge}
                                </span>
                              ))}
                            </div>
                          </td>
                          <td className="p-4 text-right">
                            <button 
                              onClick={() => handleDownloadCopyHTML(usr.name, usr.school)}
                              className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-500 font-bold py-1.5 px-3 rounded-lg text-[10px] uppercase flex items-center gap-1 cursor-pointer ml-auto"
                            >
                              <Download className="w-3.5 h-3.5" /> Reference Copy
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
