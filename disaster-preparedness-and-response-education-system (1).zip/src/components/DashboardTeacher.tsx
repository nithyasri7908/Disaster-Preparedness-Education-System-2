import React, { useState } from 'react';
import { UserProfile, EmergencyAlert } from '../types';
import { 
  Users, ClipboardList, Megaphone, CheckCircle, 
  Trash2, ShieldAlert, AlertCircle, Send, Radio,
  Search, Filter, Download, BookOpen, TrendingUp, 
  X, ChevronRight, GraduationCap, Award, FileText, 
  Activity, FileBadge, Lock, Unlock, Plus, RefreshCw,
  Mail, Settings, CheckCircle2, AlertTriangle, ShieldCheck,
  ChevronDown, HelpCircle, AlertOctagon, Info
} from 'lucide-react';

interface TeacherDashboardProps {
  user: UserProfile | null;
  alerts: EmergencyAlert[];
  onTriggerAlert: (alertData: any) => void;
  onDeactivateAlert: (alertId: string) => void;
  onNavigate: (tab: string) => void;
}

export default function TeacherDashboard({ user, alerts, onTriggerAlert, onDeactivateAlert, onNavigate }: TeacherDashboardProps) {
  // Navigation tabs for the console
  const [subTab, setSubTab] = useState<'overview' | 'students' | 'quizzes' | 'alerts'>('overview');
  
  // Alert dispatch state
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [severity, setSeverity] = useState<'low' | 'medium' | 'high'>('medium');
  const [type, setType] = useState<'drill' | 'real_emergency' | 'advisory'>('drill');
  const [alertSuccess, setAlertSuccess] = useState(false);

  // Student list search & filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'certified' | 'pending' | 'at-risk'>('all');
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);

  // Remediation alert toast simulation
  const [remediationTarget, setRemediationTarget] = useState<string | null>(null);
  
  // Custom interactive reports state
  const [showReportModal, setShowReportModal] = useState(false);

  // Mock Students with complete UserProfile structures
  const [students, setStudents] = useState<UserProfile[]>([
    {
      name: "Alex Rivera",
      email: "alex.rivera@lincolnu.edu",
      role: "student",
      school: "Lincoln University",
      gradeLevel: "Sophomore Year",
      studentId: "STU-2026-0012",
      progress: {
        completedModules: ["earthquake", "flood", "fire"],
        completedQuizzes: { "earthquake_quiz": 100, "flood_quiz": 85, "fire_quiz": 80 },
        badgesEarned: ["Disaster Scholar", "Earthquake Rescuer", "Flood Specialist"],
        riskAssessmentsCompleted: 2
      }
    },
    {
      name: "Emily Zhao",
      email: "emily.zhao@lincolnu.edu",
      role: "student",
      school: "Lincoln University",
      gradeLevel: "Junior Year",
      studentId: "STU-2026-0482",
      progress: {
        completedModules: ["earthquake", "flood", "fire", "health"],
        completedQuizzes: { "earthquake_quiz": 80, "flood_quiz": 90, "fire_quiz": 100, "health_quiz": 90 },
        badgesEarned: ["Earthquake Rescuer", "Audit Champion"],
        riskAssessmentsCompleted: 1
      }
    },
    {
      name: "Devon Miller",
      email: "d.miller@lincolnu.edu",
      role: "student",
      school: "Lincoln University",
      gradeLevel: "Freshman Year",
      studentId: "STU-2026-1109",
      progress: {
        completedModules: ["earthquake", "fire"],
        completedQuizzes: { "earthquake_quiz": 60, "fire_quiz": 40 },
        badgesEarned: [],
        riskAssessmentsCompleted: 0
      }
    },
    {
      name: "Nisha Patel",
      email: "nisha.p@lincolnu.edu",
      role: "student",
      school: "Lincoln University",
      gradeLevel: "Senior Year",
      studentId: "STU-2026-9481",
      progress: {
        completedModules: ["earthquake", "flood", "fire", "health"],
        completedQuizzes: { "earthquake_quiz": 100, "flood_quiz": 100, "fire_quiz": 100, "health_quiz": 95 },
        badgesEarned: ["Disaster Scholar", "Earthquake Rescuer", "Flood Specialist", "Audit Champion"],
        riskAssessmentsCompleted: 3
      }
    },
    {
      name: "Marcus Brody",
      email: "m.brody@lincolnu.edu",
      role: "student",
      school: "Lincoln University",
      gradeLevel: "Freshman Year",
      studentId: "STU-2026-3829",
      progress: {
        completedModules: ["earthquake"],
        completedQuizzes: { "earthquake_quiz": 40, "fire_quiz": 60 },
        badgesEarned: [],
        riskAssessmentsCompleted: 1
      }
    }
  ]);

  // Selected Student edits override state
  const [editQuizEq, setEditQuizEq] = useState<number>(0);
  const [editQuizFlood, setEditQuizFlood] = useState<number>(0);
  const [editQuizFire, setEditQuizFire] = useState<number>(0);
  const [editQuizHealth, setEditQuizHealth] = useState<number>(0);
  const [editModules, setEditModules] = useState<string[]>([]);
  const [editSaveSuccess, setEditSaveSuccess] = useState(false);

  if (!user || (user.role !== 'teacher' && user.role !== 'admin')) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center space-y-4 max-w-md mx-auto shadow-2xl">
        <ShieldAlert className="w-12 h-12 text-slate-500 mx-auto animate-pulse" />
        <h3 className="font-bold text-slate-100 text-sm uppercase tracking-wider">Clearance Level Insufficient</h3>
        <p className="text-xs text-slate-400 font-medium leading-relaxed">
          The Teacher Console requires standard educator level credentials or administrative clearance.
        </p>
        <button
          onClick={() => onNavigate('login')}
          className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2.5 px-6 rounded-lg text-xs transition-colors cursor-pointer"
        >
          Open Portal Login
        </button>
      </div>
    );
  }

  // Handle active broadcast submission
  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !message) return;

    onTriggerAlert({
      title,
      message,
      severity,
      type,
      sender: `Prof. Vance (${user.school})`
    });

    setAlertSuccess(true);
    setTitle('');
    setMessage('');
    setTimeout(() => {
      setAlertSuccess(false);
    }, 4000);
  };

  // Find currently selected student
  const activeStudent = students.find(s => s.studentId === selectedStudentId);

  // Setup edit states when a student is selected
  const handleSelectStudentForEdit = (student: UserProfile) => {
    setSelectedStudentId(student.studentId || null);
    setEditQuizEq(student.progress.completedQuizzes["earthquake_quiz"] || 0);
    setEditQuizFlood(student.progress.completedQuizzes["flood_quiz"] || 0);
    setEditQuizFire(student.progress.completedQuizzes["fire_quiz"] || 0);
    setEditQuizHealth(student.progress.completedQuizzes["health_quiz"] || 0);
    setEditModules(student.progress.completedModules);
    setEditSaveSuccess(false);
  };

  // Save the overridden progress back to the student
  const handleSaveStudentOverride = () => {
    if (!selectedStudentId) return;
    
    setStudents(prev => prev.map(s => {
      if (s.studentId === selectedStudentId) {
        return {
          ...s,
          progress: {
            ...s.progress,
            completedModules: editModules,
            completedQuizzes: {
              ...s.progress.completedQuizzes,
              "earthquake_quiz": editQuizEq,
              "flood_quiz": editQuizFlood,
              "fire_quiz": editQuizFire,
              "health_quiz": editQuizHealth
            }
          }
        };
      }
      return s;
    }));

    setEditSaveSuccess(true);
    setTimeout(() => {
      setEditSaveSuccess(false);
    }, 3000);
  };

  // Toggle modules in the edit sub-form
  const handleToggleModuleEdit = (modId: string) => {
    if (editModules.includes(modId)) {
      setEditModules(prev => prev.filter(m => m !== modId));
    } else {
      setEditModules(prev => [...prev, modId]);
    }
  };

  // Trigger simulated remediation email
  const handleSendRemediation = (studName: string) => {
    setRemediationTarget(studName);
    setTimeout(() => {
      setRemediationTarget(null);
    }, 4000);
  };

  // Calculate classroom aggregates
  const totalEnrolled = students.length;
  
  // Passing rate is calculated based on having average quiz score >= 80%
  const getAverageScore = (s: UserProfile) => {
    const scores = Object.values(s.progress.completedQuizzes) as number[];
    if (scores.length === 0) return 0;
    return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  };

  const certifiedStudentsCount = students.filter(s => {
    // Certified means they passed at least one safety quiz with 80%+
    return (Object.values(s.progress.completedQuizzes) as number[]).some(score => score >= 80);
  }).length;

  const averageClassCompletionPercent = Math.round(
    (students.reduce((sum, s) => sum + s.progress.completedModules.length, 0) / (totalEnrolled * 4)) * 100
  );

  const atRiskStudents = students.filter(s => {
    // At risk if any attempted quiz is below 80% or they have completed 0 quizzes
    const quizValues = Object.values(s.progress.completedQuizzes) as number[];
    return quizValues.length === 0 || quizValues.some(score => score < 80);
  });

  // Filters students based on search querying and selected tab categorization
  const filteredStudents = students.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          s.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.studentId?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const isCertified = (Object.values(s.progress.completedQuizzes) as number[]).some(score => score >= 80);
    const hasAtRiskQuiz = Object.values(s.progress.completedQuizzes).length === 0 || 
                          (Object.values(s.progress.completedQuizzes) as number[]).some(score => score < 80);

    if (statusFilter === 'certified') return matchesSearch && isCertified;
    if (statusFilter === 'pending') return matchesSearch && !isCertified;
    if (statusFilter === 'at-risk') return matchesSearch && hasAtRiskQuiz;
    return matchesSearch;
  });

  // Calculate averages per exam
  const getExamAverage = (quizId: string) => {
    const scores = students
      .map(s => s.progress.completedQuizzes[quizId])
      .filter((score): score is number => score !== undefined);
    
    if (scores.length === 0) return 0;
    return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  };

  const eqClassAvg = getExamAverage('earthquake_quiz');
  const floodClassAvg = getExamAverage('flood_quiz');
  const fireClassAvg = getExamAverage('fire_quiz');
  const healthClassAvg = getExamAverage('health_quiz');

  // Generate safety report file layout text
  const getSafetyReportText = () => {
    let text = `==================================================================\n`;
    text += `       LINCOLN CAMPUS COMPREHENSIVE STUDENT SAFETY COMPLIANCE      \n`;
    text += `==================================================================\n`;
    text += `Date of Audit: ${new Date().toLocaleDateString()}\n`;
    text += `Class Evaluation Authority: Prof. Vance (Earth Sciences)\n`;
    text += `School Division: ${user.school}\n`;
    text += `Enrollment Registered: ${students.length} Students\n`;
    text += `Average Syllabus Progress: ${averageClassCompletionPercent}%\n`;
    text += `Qualified Responders Rate: ${Math.round((certifiedStudentsCount / totalEnrolled) * 100)}%\n\n`;

    text += `CLASS EXAM SCORECARD HEATMAP:\n`;
    text += `- Earthquake Prep Average Score: ${eqClassAvg}%\n`;
    text += `- Flooding Response Average Score: ${floodClassAvg}%\n`;
    text += `- Fire Evacuation Average Score: ${fireAvg}%\n`;
    text += `- Campus First Aid Average Score: ${healthAvg}%\n\n`;

    text += `STUDENT BY STUDENT ROSTER REPORT:\n`;
    students.forEach((s, i) => {
      const isCertified = (Object.values(s.progress.completedQuizzes) as number[]).some(score => score >= 80);
      text += `------------------------------------------------------------------\n`;
      text += `${i + 1}. [ID: ${s.studentId || 'N/A'}] ${s.name} (${s.email})\n`;
      text += `   - Completed syllabus: ${s.progress.completedModules.length}/4 modules\n`;
      text += `   - Earned badges cabinet: ${s.progress.badgesEarned.length} badges (${s.progress.badgesEarned.join(', ') || 'None'})\n`;
      text += `   - Classroom audit risks reported: ${s.progress.riskAssessmentsCompleted} hazards\n`;
      text += `   - Individual exam results: \n`;
      Object.entries(s.progress.completedQuizzes).forEach(([q, score]) => {
        text += `     * ${q}: ${score}%\n`;
      });
      text += `   - Responder Clearance Standing: ${isCertified ? 'APPROVED FIRST RESPONDER ✅' : 'PENDING EDUCATION ❌'}\n`;
    });

    text += `\n==================================================================\n`;
    text += `       END OF TRANSMITTED SAFETY COMPLIANCE REPORT \n`;
    text += `==================================================================\n`;
    return text;
  };

  // Download safety report text file dynamically
  const handleDownloadReport = () => {
    const reportContent = getSafetyReportText();
    const blob = new Blob([reportContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Campus_Safety_Report_${user.school.replace(/\s+/g, '_')}.txt`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const fireAvg = fireClassAvg;
  const healthAvg = healthClassAvg;

  return (
    <div className="space-y-6 animate-fade-in text-slate-800">
      
      {/* Teacher Welcomer Block */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
          <div className="space-y-1.5 text-center md:text-left">
            <span className="px-2.5 py-0.5 bg-amber-500/10 border border-amber-500/20 rounded text-[9px] font-mono text-amber-500 font-extrabold uppercase tracking-widest">
              Educator Console
            </span>
            <h2 className="text-xl md:text-2xl font-black text-slate-100 tracking-tight">{user.name}</h2>
            <p className="text-xs text-slate-400 font-medium font-mono leading-none">
              Academic Lead • Campus Emergency operations Coordinator • {user.school}
            </p>
          </div>
          
          <div className="flex gap-4 text-center shrink-0 w-full md:w-auto">
            <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl flex-1 md:flex-none">
              <div className="text-xl font-black text-amber-500 font-mono">
                {totalEnrolled}
              </div>
              <div className="text-[9px] font-mono tracking-widest text-slate-500 uppercase font-bold">
                Students Enrolled
              </div>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl flex-1 md:flex-none">
              <div className="text-xl font-black text-emerald-500 font-mono">
                {Math.round((certifiedStudentsCount / totalEnrolled) * 100)}%
              </div>
              <div className="text-[9px] font-mono tracking-widest text-slate-500 uppercase font-bold">
                Pass rate index
              </div>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl flex-1 md:flex-none">
              <div className="text-xl font-black text-blue-400 font-mono">
                {averageClassCompletionPercent}%
              </div>
              <div className="text-[9px] font-mono tracking-widest text-slate-500 uppercase font-bold">
                Completion rate
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Simulated toast notification for remediations */}
      {remediationTarget && (
        <div className="bg-amber-500 border border-amber-400 text-slate-950 p-4 rounded-xl flex items-center justify-between gap-3 shadow-2xl animate-bounce">
          <div className="flex items-center gap-2">
            <Mail className="w-5 h-5 animate-pulse" />
            <span className="text-xs font-bold font-mono">
              [SYSTEM DISPATCH]: Remediation training warning e-mail successfully sent to student {remediationTarget}.
            </span>
          </div>
          <X className="w-4 h-4 cursor-pointer" onClick={() => setRemediationTarget(null)} />
        </div>
      )}

      {/* Sub-tab Navigation Panel */}
      <div className="flex overflow-x-auto border-b border-slate-200/60 pb-px gap-2">
        <button
          onClick={() => { setSubTab('overview'); setSelectedStudentId(null); }}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'overview'
              ? 'border-amber-500 text-amber-600 bg-amber-500/5 font-extrabold'
              : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-100/50'
          }`}
        >
          <Activity className="w-4 h-4" />
          Analytics Dashboard
        </button>
        <button
          onClick={() => setSubTab('students')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'students'
              ? 'border-amber-500 text-amber-600 bg-amber-500/5 font-extrabold'
              : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-100/50'
          }`}
        >
          <Users className="w-4 h-4" />
          Monitor Students ({students.length})
        </button>
        <button
          onClick={() => { setSubTab('quizzes'); setSelectedStudentId(null); }}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'quizzes'
              ? 'border-amber-500 text-amber-600 bg-amber-500/5 font-extrabold'
              : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-100/50'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          Quiz Heatmaps
        </button>
        <button
          onClick={() => { setSubTab('alerts'); setSelectedStudentId(null); }}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'alerts'
              ? 'border-amber-500 text-amber-600 bg-amber-500/5 font-extrabold'
              : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-100/50'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          Siren Dispatch ({alerts.filter(a => a.isActive).length})
        </button>
      </div>

      {/* Overview tab content */}
      {subTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid md:grid-cols-3 gap-6">
            
            {/* Class overview gauge card */}
            <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4 flex flex-col justify-between">
              <div className="space-y-1">
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  Overall preparedness index
                </h3>
                <p className="text-xs text-slate-400">Class preparedness ratio compiled against curriculum and exam metrics.</p>
              </div>
              
              <div className="flex items-center justify-center py-4">
                <div className="relative w-32 h-32 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="40" stroke="#f1f5f9" strokeWidth="10" fill="transparent" />
                    <circle cx="50" cy="50" r="40" stroke="#f59e0b" strokeWidth="10" fill="transparent"
                      strokeDasharray="251.2"
                      strokeDashoffset={251.2 - (251.2 * averageClassCompletionPercent) / 100}
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="text-3xl font-black text-slate-800 font-mono">{averageClassCompletionPercent}%</span>
                    <span className="text-[9px] text-slate-400 font-bold uppercase font-mono tracking-widest">Prepared</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl text-[11px] text-slate-500 font-mono space-y-1 border border-slate-100">
                <div className="flex justify-between">
                  <span>Certified First Responders:</span>
                  <span className="font-bold text-emerald-600">{certifiedStudentsCount} ({Math.round(certifiedStudentsCount/students.length*100)}%)</span>
                </div>
                <div className="flex justify-between">
                  <span>At-Risk Safety Deficits:</span>
                  <span className="font-bold text-red-500">{atRiskStudents.length} Students</span>
                </div>
              </div>
            </div>

            {/* Quick stats grid list */}
            <div className="md:col-span-2 bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-amber-500" />
                  Module Completion Percentages
                </h3>
                <span className="text-[10px] font-mono bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded-md">
                  Active Enrolled Class
                </span>
              </div>

              <div className="space-y-4">
                {[
                  { id: 'eq', title: 'Earthquake Evacuation', key: 'earthquake', avg: eqClassAvg, color: 'bg-amber-500' },
                  { id: 'flood', title: 'Severe Flooding Response', key: 'flood', avg: floodClassAvg, color: 'bg-blue-500' },
                  { id: 'fire', title: 'Dormitory Fire Escape', key: 'fire', avg: fireAvg, color: 'bg-red-500' },
                  { id: 'health', title: 'First Aid & Health Prep', key: 'health', avg: healthAvg, color: 'bg-emerald-500' }
                ].map((mod) => {
                  const completedClassCount = students.filter(s => s.progress.completedModules.includes(mod.key)).length;
                  const pct = Math.round((completedClassCount / totalEnrolled) * 100);
                  return (
                    <div key={mod.id} className="space-y-1.5 text-xs">
                      <div className="flex justify-between font-semibold text-slate-700">
                        <span>{mod.title}</span>
                        <span className="font-mono">{completedClassCount} / {totalEnrolled} ({pct}%) Completed</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div className={`${mod.color} h-full transition-all duration-500`} style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="pt-2 text-[11px] text-slate-400 font-medium">
                * Percentages reflect proportion of students who have completed the full module text and unlocked their study record checkpoints.
              </div>
            </div>

          </div>

          <div className="grid md:grid-cols-3 gap-6">

            {/* At-Risk students alert board */}
            <div className="md:col-span-2 bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-1.5">
                  <AlertTriangle className="w-4.5 h-4.5 text-red-500" />
                  <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700">
                    At-Risk Safety Records Board
                  </h3>
                </div>
                <span className="text-[10px] bg-red-50 text-red-600 font-extrabold px-2 py-0.5 rounded-full">
                  {atRiskStudents.length} flagged
                </span>
              </div>

              <p className="text-xs text-slate-400 leading-normal">
                These students have failed to score 80% or greater on emergency competency exams, or have pending unattempted coursework. Immediate remediation is recommended.
              </p>

              <div className="divide-y divide-slate-100">
                {atRiskStudents.map((stud) => {
                  const lowQuizzes = (Object.entries(stud.progress.completedQuizzes) as [string, number][]).filter(([_, score]) => score < 80);
                  return (
                    <div key={stud.studentId} className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-4">
                      <div className="space-y-1 text-xs">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                          <span className="font-extrabold text-slate-850">{stud.name}</span>
                          <span className="text-[10px] text-slate-400 font-mono">({stud.studentId})</span>
                        </div>
                        <div className="text-[11px] text-slate-500 font-medium pl-4">
                          {lowQuizzes.length === 0 ? (
                            <span className="text-amber-600 font-mono">0 quizzes completed • Syllabus Deficit</span>
                          ) : (
                            <span>Low Exam Scores: {lowQuizzes.map(([q, s]) => `${q.replace('_quiz', '')} (${s}%)`).join(', ')}</span>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={() => handleSendRemediation(stud.name)}
                        className="bg-red-50 hover:bg-red-100 text-red-600 px-3 py-1.5 rounded-lg border border-red-200/50 text-[10px] font-extrabold font-mono uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1 shrink-0"
                      >
                        <Mail className="w-3.5 h-3.5" /> Remind
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Reports & Actions */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="border-b border-slate-800 pb-3">
                  <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-amber-500" />
                    Readiness Transcripts
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Export high-fidelity campus preparedness files and transcripts for audit reporting.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 space-y-3">
                  <div className="flex justify-between text-[11px] font-mono text-slate-400">
                    <span>Export format:</span>
                    <span className="text-amber-500 font-bold">Encrypted .TXT</span>
                  </div>
                  <div className="flex justify-between text-[11px] font-mono text-slate-400">
                    <span>Audit System:</span>
                    <span className="text-slate-300 font-bold">SEC-2026-LN</span>
                  </div>
                  <div className="flex justify-between text-[11px] font-mono text-slate-400">
                    <span>Status:</span>
                    <span className="text-emerald-400 font-bold">● Active Ready</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <button
                  onClick={() => setShowReportModal(true)}
                  className="w-full bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-200 hover:text-slate-100 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Activity className="w-3.5 h-3.5" /> View Active Transcript
                </button>
                <button
                  onClick={handleDownloadReport}
                  className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 py-2.5 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-lg shadow-amber-500/10"
                >
                  <Download className="w-3.5 h-3.5" /> Download Preparedness Report
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Monitor Students tab content */}
      {subTab === 'students' && (
        <div className="grid lg:grid-cols-3 gap-6">
          
          {/* Student Grid / List Directory Column */}
          <div className="lg:col-span-2 bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                  <Users className="w-5 h-5 text-amber-500" />
                  Lincoln Lab Safety Directory
                </h3>
                <p className="text-xs text-slate-400">Select any student to review and edit safety records.</p>
              </div>

              {/* Status chips */}
              <div className="flex flex-wrap gap-1">
                {(['all', 'certified', 'pending', 'at-risk'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setStatusFilter(mode)}
                    className={`text-[10px] font-extrabold px-2.5 py-1 rounded-md uppercase tracking-wider transition-colors cursor-pointer ${
                      statusFilter === mode
                        ? 'bg-amber-500 text-slate-950 font-black'
                        : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search student by name, student id or email..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-800 focus:outline-none focus:border-amber-500 focus:bg-white font-medium"
              />
            </div>

            {/* Students Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-[10px] font-mono uppercase text-slate-400">
                    <th className="py-3">Student Profile</th>
                    <th className="py-3 text-center">Modules</th>
                    <th className="py-3 text-center">Avg Score</th>
                    <th className="py-3 text-center">Clearance Status</th>
                    <th className="py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredStudents.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400 font-mono text-xs">
                        No students match search constraints or selected filters.
                      </td>
                    </tr>
                  ) : (
                    filteredStudents.map((stud) => {
                      const avg = getAverageScore(stud);
                      const isCertified = (Object.values(stud.progress.completedQuizzes) as number[]).some(score => score >= 80);
                      const isSelected = selectedStudentId === stud.studentId;

                      return (
                        <tr 
                          key={stud.studentId} 
                          className={`hover:bg-slate-50/70 transition-colors ${isSelected ? 'bg-amber-500/5' : ''}`}
                        >
                          <td className="py-3.5">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/10 border border-amber-500/15 text-amber-600 flex items-center justify-center font-black text-sm select-none shrink-0">
                                {stud.name.split(' ').map(n => n[0]).join('')}
                              </div>
                              <div className="min-w-0">
                                <h4 className="font-extrabold text-slate-800 truncate">{stud.name}</h4>
                                <p className="text-[10px] text-slate-400 font-mono leading-none">{stud.studentId} • {stud.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-3.5 text-center font-mono font-bold text-slate-500">
                            {stud.progress.completedModules.length} / 4
                          </td>
                          <td className="py-3.5 text-center">
                            <span className={`px-2 py-0.5 rounded-md font-mono font-bold ${
                              avg >= 80 ? 'text-emerald-600 bg-emerald-50 bg-emerald-500/10' : 'text-red-500 bg-red-50'
                            }`}>
                              {avg > 0 ? `${avg}%` : 'N/A'}
                            </span>
                          </td>
                          <td className="py-3.5 text-center">
                            {isCertified ? (
                              <span className="inline-flex items-center gap-1 text-[9px] text-emerald-600 font-extrabold bg-emerald-100/50 border border-emerald-500/10 px-2 py-0.5 rounded-full uppercase tracking-wider">
                                ✓ Certified
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[9px] text-slate-500 font-extrabold bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-full uppercase tracking-wider">
                                🔒 Pending
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 text-right">
                            <button
                              onClick={() => handleSelectStudentForEdit(stud)}
                              className="text-xs bg-slate-900 hover:bg-slate-800 text-slate-100 hover:text-white px-2.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1 inline-flex"
                            >
                              Edit Profile <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

          </div>

          {/* Student Progress Override Form (Self-Contained Editor Panel) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 space-y-6 shadow-xl flex flex-col justify-between">
            {activeStudent ? (
              <div className="space-y-5">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="space-y-1">
                    <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                      Case File Editor
                    </h3>
                    <h4 className="text-sm font-black text-slate-100">{activeStudent.name}</h4>
                  </div>
                  <button 
                    onClick={() => setSelectedStudentId(null)}
                    className="p-1 bg-slate-950 hover:bg-slate-850 rounded-lg text-slate-400 hover:text-slate-200"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {editSaveSuccess && (
                  <div className="bg-emerald-500/10 border border-emerald-500/20 p-4 rounded-xl text-emerald-400 text-xs flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 animate-bounce" />
                    <span className="font-semibold">Case override successfully committed!</span>
                  </div>
                )}

                {/* Modules completed edits checkboxes */}
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase text-slate-400 font-bold block">
                    1. Override Completed Syllabus
                  </label>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 space-y-2.5">
                    {[
                      { id: 'earthquake', name: 'Earthquake Evacuation' },
                      { id: 'flood', name: 'Severe Flooding Response' },
                      { id: 'fire', name: 'Dormitory Fire Escape' },
                      { id: 'health', name: 'Campus First Aid Prep' }
                    ].map((mod) => {
                      const isChecked = editModules.includes(mod.id);
                      return (
                        <label key={mod.id} className="flex items-center gap-2.5 text-xs text-slate-300 font-medium cursor-pointer select-none">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => handleToggleModuleEdit(mod.id)}
                            className="w-4 h-4 rounded border-slate-800 text-amber-500 focus:ring-0 focus:ring-offset-0 cursor-pointer"
                          />
                          <span>{mod.name}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                {/* Score edits inputs */}
                <div className="space-y-3">
                  <label className="text-[10px] font-mono uppercase text-slate-400 font-bold block">
                    2. Override Exam Grades
                  </label>
                  
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="space-y-1">
                      <span className="text-slate-500 font-medium">Earthquake Exam (%)</span>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={editQuizEq}
                        onChange={e => setEditQuizEq(Math.min(100, Math.max(0, parseInt(e.target.value) || 0)))}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 text-xs font-mono font-bold"
                      />
                    </div>
                    <div className="space-y-1">
                      <span className="text-slate-500 font-medium">Flooding Exam (%)</span>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={editQuizFlood}
                        onChange={e => setEditQuizFlood(Math.min(100, Math.max(0, parseInt(e.target.value) || 0)))}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 text-xs font-mono font-bold"
                      />
                    </div>
                    <div className="space-y-1">
                      <span className="text-slate-500 font-medium">Fire Exam (%)</span>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={editQuizFire}
                        onChange={e => setEditQuizFire(Math.min(100, Math.max(0, parseInt(e.target.value) || 0)))}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 text-xs font-mono font-bold"
                      />
                    </div>
                    <div className="space-y-1">
                      <span className="text-slate-500 font-medium">First Aid Exam (%)</span>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={editQuizHealth}
                        onChange={e => setEditQuizHealth(Math.min(100, Math.max(0, parseInt(e.target.value) || 0)))}
                        className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-100 text-xs font-mono font-bold"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={handleSaveStudentOverride}
                    className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-2 rounded-lg text-xs transition-colors cursor-pointer"
                  >
                    Save Override Settings
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4 text-center max-w-sm mx-auto py-12 flex flex-col justify-center items-center">
                <Settings className="w-12 h-12 text-slate-600 animate-spin" />
                <div className="space-y-1.5">
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                    Syllabus override desk
                  </h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
                    Click "Edit Profile" on any student to override their reading progress, mark quizzes, or manually award Responder Clearance Certificates.
                  </p>
                </div>
              </div>
            )}

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 flex items-center justify-between text-[11px] font-mono text-slate-400 mt-6">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                Authenticated Action Log
              </span>
              <span className="font-bold text-emerald-400">● Live Secure</span>
            </div>
          </div>

        </div>
      )}

      {/* Quizzes & Syllabus Tab content */}
      {subTab === 'quizzes' && (
        <div className="space-y-6">
          
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="space-y-1">
              <h3 className="text-sm font-black text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                <ClipboardList className="w-5 h-5 text-amber-500" />
                Class-wide Syllabus Competency Heatmap
              </h3>
              <p className="text-xs text-slate-400">Evaluate Safety Exam Performance metrics and identify key struggle hotspots across all students.</p>
            </div>

            <div className="grid md:grid-cols-4 gap-4 pt-2">
              {[
                { title: 'Earthquake Evacuation Exam', id: 'earthquake_quiz', avg: eqClassAvg, color: 'text-amber-500', bg: 'bg-amber-50', border: 'border-amber-200/50', hotspot: 'Identifying glass window hazards (33% error rate)' },
                { title: 'Severe Flooding Exam', id: 'flood_quiz', avg: floodClassAvg, color: 'text-blue-500', bg: 'bg-blue-50', border: 'border-blue-200/50', hotspot: 'Estimating flowing water force depths (40% error rate)' },
                { title: 'Dormitory Fire escape Exam', id: 'fire_quiz', avg: fireAvg, color: 'text-red-500', bg: 'bg-red-50', border: 'border-red-200/50', hotspot: 'Acronym PASS extinguisher execution (25% error rate)' },
                { title: 'First Aid & Health Exam', id: 'health_quiz', avg: healthAvg, color: 'text-emerald-500', bg: 'bg-emerald-50', border: 'border-emerald-200/50', hotspot: 'Primary CPR respiration intervals (10% error rate)' }
              ].map((quiz) => (
                <div key={quiz.id} className={`p-4 rounded-xl border ${quiz.bg} ${quiz.border} flex flex-col justify-between space-y-4 shadow-sm`}>
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-bold">SAFETY AREA</span>
                    <h4 className="text-xs font-extrabold text-slate-700 leading-normal">{quiz.title}</h4>
                  </div>
                  
                  <div className="py-2">
                    <div className="text-3xl font-black font-mono text-slate-800">{quiz.avg}%</div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-mono">CLASS AVERAGE</span>
                  </div>

                  <div className="border-t border-slate-200/80 pt-2 text-[10px] text-slate-500 space-y-1">
                    <span className="font-bold text-slate-600 block uppercase font-mono">DIAGNOSTIC HOTSPOT:</span>
                    <p className="leading-relaxed font-medium">{quiz.hotspot}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            
            {/* Class syllabus overview heatmap */}
            <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700">
                Syllabus Chapter Completions Heatmap
              </h3>
              
              <div className="space-y-4.5">
                {[
                  { chapter: '1. Earthquake Survival Guide', id: 'earthquake', desc: 'Sustained classroom shaking drills, Drop-Cover-Hold rules.' },
                  { chapter: '2. Flood & Coastal Escape Alerts', id: 'flood', desc: 'Higher ground shelter, flash alert categorization scales.' },
                  { chapter: '3. Campus Fire Drill Assembly', id: 'fire', desc: 'Exit layout planning, extinguisher chemistry basics.' },
                  { chapter: '4. Physical Hazards & CPR', id: 'health', desc: 'Medical operations, respiratory rescue, hazard checks.' }
                ].map((chap) => {
                  const completions = students.filter(s => s.progress.completedModules.includes(chap.id)).length;
                  const ratio = completions / totalEnrolled;
                  let hue = 'bg-slate-100';
                  if (ratio > 0.8) hue = 'bg-emerald-500 text-white';
                  else if (ratio > 0.5) hue = 'bg-amber-500 text-slate-950';
                  else if (ratio > 0) hue = 'bg-orange-500 text-white';
                  
                  return (
                    <div key={chap.id} className="flex items-center justify-between gap-4 p-3 rounded-xl border border-slate-100 hover:border-slate-200 transition-all bg-slate-50/50">
                      <div className="space-y-1 text-xs">
                        <h4 className="font-extrabold text-slate-850">{chap.chapter}</h4>
                        <p className="text-[10px] text-slate-400 font-medium leading-normal">{chap.desc}</p>
                      </div>

                      <div className={`p-2.5 rounded-lg font-mono font-black text-xs text-center min-w-[5rem] shrink-0 ${hue}`}>
                        {completions} / {totalEnrolled}
                        <span className="block text-[8px] font-bold uppercase tracking-widest leading-none mt-0.5">COMPLETED</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Simulated pedagogical recommendation insights */}
            <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1">
                  <GraduationCap className="w-4.5 h-4.5 text-amber-500 animate-pulse" />
                  Educator Pedagogical Insights
                </h3>
                
                <p className="text-xs text-slate-400 leading-relaxed">
                  Insights compiled dynamically from class-wide exam results and safety drill patterns.
                </p>

                <div className="space-y-3 pt-2 text-xs">
                  <div className="p-3 bg-red-50 border border-red-200/40 rounded-xl flex gap-2.5 items-start text-red-800">
                    <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <h4 className="font-extrabold">Reinforce Fire Extinguisher Usage:</h4>
                      <p className="text-[11px] text-red-700/80 leading-relaxed">
                        3 of 5 active students struggled with extinguisher rules. Recommend launching classroom lectures on chemical classification.
                      </p>
                    </div>
                  </div>

                  <div className="p-3 bg-amber-50 border border-amber-200/40 rounded-xl flex gap-2.5 items-start text-amber-800">
                    <Info className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <h4 className="font-extrabold">Active Drill Promotion:</h4>
                      <p className="text-[11px] text-amber-700/80 leading-relaxed">
                        Syllabus completions are high (74%), but actual classroom audit logs are lagging (Average 1.4 submissions per student).
                      </p>
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-50 border border-emerald-200/40 rounded-xl flex gap-2.5 items-start text-emerald-800">
                    <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <h4 className="font-extrabold">Seismic Evacuation Excellence:</h4>
                      <p className="text-[11px] text-emerald-700/80 leading-relaxed">
                        Class average score for Earthquake Prep is {eqClassAvg}%. Standard Drop-Cover-Hold protocols are safely mastered.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => handleSendRemediation('All Pending Class')}
                className="w-full bg-slate-950 hover:bg-slate-850 text-slate-200 hover:text-white py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Mail className="w-4 h-4" /> Dispatch Study Reminder to All Incomplete
              </button>
            </div>

          </div>

        </div>
      )}

      {/* Siren Controls & Alerts Dispatch tab */}
      {subTab === 'alerts' && (
        <div className="grid lg:grid-cols-3 gap-8 animate-fade-in">
          
          {/* Dispatcher Form column */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Radio className="w-5 h-5 text-amber-500 animate-pulse" />
              <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-200">
                Emergency Dispatch Center
              </h3>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Broadcast simulated earthquake drills, fire escape reminders, or meteorological warnings directly into all student dashboards in real-time.
            </p>

            {alertSuccess && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 p-4 rounded-xl flex items-center gap-3 text-emerald-400 text-xs">
                <CheckCircle className="w-5 h-5 shrink-0 animate-bounce" />
                <span className="font-semibold">Simulated Alert Broadcast Active!</span>
              </div>
            )}

            <form onSubmit={handleBroadcast} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="text-slate-400 font-medium">Alert / Title Headline *</label>
                <input 
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Earthquake evacuation drill"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500 font-semibold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-400 font-medium">Broadcast Alert Message *</label>
                <textarea 
                  required
                  rows={3}
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  placeholder="Details of evacuation assembly points, exit constraints..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500 font-medium leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-slate-400 font-medium">Severity Scale</label>
                  <select 
                    value={severity}
                    onChange={e => setSeverity(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500 font-semibold cursor-pointer"
                  >
                    <option value="low">🟡 Low (Advisory)</option>
                    <option value="medium">🟠 Medium (Drill Alert)</option>
                    <option value="high">🔴 High (Tactical Warning)</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-slate-400 font-medium">Alert Type</label>
                  <select 
                    value={type}
                    onChange={e => setType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500 font-semibold cursor-pointer"
                  >
                    <option value="drill">Practice Drill</option>
                    <option value="advisory">Civil Advisory</option>
                    <option value="real_emergency">Critical Warning</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-lg shadow-amber-500/5 text-xs uppercase"
              >
                <Send className="w-3.5 h-3.5" /> Launch Dispatch Sirens
              </button>
            </form>
          </div>

          {/* Active alerts monitor list */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 space-y-4 shadow-xl flex flex-col justify-between">
            <div className="space-y-3">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-100">
                Operational Warning Sirens Monitor
              </h3>
              <p className="text-xs text-slate-400">
                Below are the active emergency transmissions currently broadcasted campus-wide. Deactivate finished drills to clear student dashboard banners.
              </p>

              <div className="grid md:grid-cols-2 gap-4 max-h-[24rem] overflow-y-auto pr-1 pt-2">
                {alerts.map((alert) => (
                  <div 
                    key={alert.id} 
                    className={`p-4 rounded-xl border flex gap-3 justify-between items-start transition-all ${
                      alert.isActive 
                        ? 'bg-slate-950 border-amber-500/30' 
                        : 'bg-slate-950/40 border-slate-900 opacity-50'
                    }`}
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`px-1.5 py-0.2 rounded text-[8px] font-mono uppercase font-bold border ${
                          alert.severity === 'high' 
                            ? 'bg-red-500/10 text-red-500 border-red-500/20' 
                            : alert.severity === 'medium' 
                              ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' 
                              : 'bg-blue-500/10 text-blue-500 border-blue-500/20'
                        }`}>
                          {alert.severity} • {alert.type}
                        </span>
                        {!alert.isActive && (
                          <span className="text-[8px] font-mono bg-slate-900 text-slate-600 px-1.5 py-0.2 rounded border border-slate-850 uppercase">Deactivated</span>
                        )}
                      </div>
                      <h4 className="text-xs font-extrabold text-slate-200 truncate">{alert.title}</h4>
                      <p className="text-[10px] text-slate-400 leading-normal line-clamp-2">{alert.message}</p>
                      <p className="text-[9px] font-mono text-slate-500 pt-1">Broadcaster: {alert.sender}</p>
                    </div>

                    {alert.isActive && (
                      <button
                        onClick={() => onDeactivateAlert(alert.id)}
                        className="p-1.5 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 hover:border-red-500/40 text-red-400 rounded transition-all shrink-0 cursor-pointer"
                        title="Deactivate Drill"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 flex items-center justify-between text-[11px] font-mono text-slate-400 mt-6">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                Operational Broadcasting Node
              </span>
              <span className="font-bold text-emerald-400">● Live Streaming</span>
            </div>
          </div>

        </div>
      )}

      {/* Transcript/Report view modal popup */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 flex flex-col justify-between max-h-[85vh]">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-black text-slate-100 uppercase tracking-wide flex items-center gap-1.5">
                <FileText className="w-5 h-5 text-amber-500" />
                Safety Compliance Transcript Preview
              </h3>
              <button 
                onClick={() => setShowReportModal(false)}
                className="p-1 bg-slate-950 hover:bg-slate-850 rounded-lg text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto bg-slate-950 p-4 rounded-xl border border-slate-850 font-mono text-xs text-slate-300 whitespace-pre leading-relaxed select-all">
              {getSafetyReportText()}
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowReportModal(false)}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-400 hover:text-slate-200 px-4 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer"
              >
                Close Preview
              </button>
              <button
                onClick={() => { handleDownloadReport(); setShowReportModal(false); }}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 px-5 py-2 rounded-lg text-xs font-black transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Download className="w-4 h-4" /> Save .TXT File
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
