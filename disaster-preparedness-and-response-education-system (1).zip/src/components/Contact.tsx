import React, { useState } from 'react';
import { Phone, Mail, MapPin, Send, CheckCircle } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    school: '',
    subject: 'Safety Audit Request',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email && formData.message) {
      setSubmitted(true);
      // Simulate submission
      setTimeout(() => {
        setSubmitted(false);
        setFormData({
          name: '',
          email: '',
          school: '',
          subject: 'Safety Audit Request',
          message: ''
        });
      }, 5000);
    }
  };

  const directories = [
    { name: "Campus Safety Head Office", phone: "(555) 123-4567", email: "safety@campusemail.edu", hours: "24/7 Security Dispatch" },
    { name: "Local Fire Department (Precinct 4)", phone: "(555) 987-6543", email: "station4@cityfire.gov", hours: "Non-Emergency Main Line" },
    { name: "Municipal Hazard Mitigation Office", phone: "(555) 456-7890", email: "mitigation@citygov.org", hours: "8:00 AM - 5:00 PM Weekdays" }
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <h1 className="text-2xl font-extrabold text-slate-100 tracking-tight">
          Hotlines & <span className="text-amber-500">Directories</span>
        </h1>
        <p className="text-xs text-slate-400 mt-2">
          Keep active contact with university medical centers, localized safety coordinators, and civic fire responders. Use the form below to request custom audits.
        </p>
      </div>

      {/* Directory & Form Grid */}
      <div className="grid md:grid-cols-2 gap-8">
        
        {/* Directories Column */}
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-100 tracking-tight uppercase border-b border-slate-800 pb-3">
              Campus & Local Responders
            </h3>
            
            <div className="space-y-4 divide-y divide-slate-800">
              {directories.map((dir, idx) => (
                <div key={idx} className="space-y-2 pt-4 first:pt-0">
                  <h4 className="text-xs font-bold text-slate-200">{dir.name}</h4>
                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 font-mono">
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-amber-500" />
                      <span>{dir.phone}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-amber-500" />
                      <span className="truncate">{dir.email}</span>
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-500">{dir.hours}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Physical Address Info */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex items-start gap-4">
            <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-xl">
              <MapPin className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-slate-200">Main Administration & Safety Labs</h4>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Disaster Preparedness Systems Inc.<br />
                Building D, Suite 402, Technology University Boulevard<br />
                Campus Annex, CA 94016
              </p>
            </div>
          </div>
        </div>

        {/* Inquiry Form Column */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-100 tracking-tight uppercase">
            Inquire Audit / Support
          </h3>
          
          {submitted ? (
            <div className="bg-emerald-500/10 border border-emerald-500/20 p-6 rounded-lg text-center space-y-3">
              <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto animate-bounce" />
              <h4 className="text-xs font-bold text-slate-200">Request Dispatched Successfully</h4>
              <p className="text-[11px] text-slate-400 leading-normal">
                Your safety inquiry has been safely logged in our database. A school safety officer will follow up with your institution shortly.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Your Name *</label>
                  <input 
                    type="text" 
                    required
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    placeholder="Enter name"
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-medium"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Your Email *</label>
                  <input 
                    type="email" 
                    required
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                    placeholder="Enter email"
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Institution/School</label>
                  <input 
                    type="text" 
                    value={formData.school}
                    onChange={e => setFormData({...formData, school: e.target.value})}
                    placeholder="e.g. Lincoln College"
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-medium"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Subject Category</label>
                  <select 
                    value={formData.subject}
                    onChange={e => setFormData({...formData, subject: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-medium"
                  >
                    <option>Safety Audit Request</option>
                    <option>Syllabus/Curriculum Query</option>
                    <option>Platform Technical Support</option>
                    <option>Feedback & Suggestions</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-medium">Detailed Message *</label>
                <textarea 
                  required
                  rows={4}
                  value={formData.message}
                  onChange={e => setFormData({...formData, message: e.target.value})}
                  placeholder="Outline your inquiry, specify campus hazard locations or custom audit queries..."
                  className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500 font-medium leading-relaxed"
                />
              </div>

              <button 
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2.5 rounded flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-amber-500/5"
              >
                <Send className="w-3.5 h-3.5" /> Dispatch Inquiry
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
