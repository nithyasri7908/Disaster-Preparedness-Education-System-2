import React, { useState, useEffect, useRef } from 'react';
import { 
  FolderOpen, FileText, Download, CheckSquare, 
  MapPin, Printer, ArrowRight, HelpCircle, LayoutGrid,
  Search, Play, Pause, ChevronRight, ChevronDown, Check,
  Activity, BookOpen, AlertCircle, Eye, AlertTriangle, Flame,
  Waves, Skull, Clock, Shield, Award, HeartPulse, RefreshCw, Plus, X,
  ExternalLink, FileCheck, Info, Sparkles, Volume2, VolumeX, EyeOff, ListTodo, CheckCircle
} from 'lucide-react';

// Guide Document Interface
interface SafetyDocument {
  id: string;
  title: string;
  filename: string;
  size: string;
  category: 'general' | 'medical' | 'chemical' | 'natural' | 'tactical';
  description: string;
  pages: string[];
  tableOfContents: string[];
}

// Training Video Interface
interface TrainingVideo {
  id: string;
  title: string;
  duration: string;
  category: string;
  thumbnailColor: string;
  description: string;
  captions: string[];
}

// First Aid Procedure Interface
interface FirstAidInjury {
  id: string;
  name: string;
  icon: any;
  severity: 'Critical' | 'Urgent' | 'Moderate';
  immediateActions: string[];
  neverDo: string[];
  requiredGear: string[];
  practiceSteps: {
    prompt: string;
    choices: string[];
    correctIndex: number;
    successMessage: string;
  }[];
}

export default function ResourceCenter() {
  // Navigation tabs: 'handbooks' | 'firstaid' | 'videos' | 'tools'
  const [activeTab, setActiveTab] = useState<'handbooks' | 'firstaid' | 'videos' | 'tools'>('handbooks');

  // ==========================================
  // STATE 1: HANDBOOKS & DOCUMENTS DIRECTORY
  // ==========================================
  const [safetyDocuments] = useState<SafetyDocument[]>(() => {
    const saved = localStorage.getItem('responseed_documents');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'fema-evac',
        title: 'FEMA Campus Evacuation Guide',
        filename: 'FEMA-Campus-Evac-2026.pdf',
        size: '2.4 MB',
        category: 'general',
        description: 'Comprehensive federal and institutional guidelines to multi-building evacuation protocols, assembly zones, and leadership roles.',
        tableOfContents: [
          '1. Structural Readiness & Evacuation Drills',
          '2. Designated Campus Assembly Points',
          '3. Leadership Commands & Roster Operations',
          '4. Post-Incident Inspection & Return to Class'
        ],
        pages: [
          '--- PAGE 1: INTRODUCTION ---\nThis compliance guide outlines standard procedures for rapid evacuation of academic facilities. It is vital to learn your building coordinator’s name and find at least two independent exit stairways in your department.\n\nKey Takeaways:\n• Prioritize human evacuation over physical assets.\n• Leave heavier bags and computers behind if smoke is active.\n• Direct students towards primary muster zones.',
          '--- PAGE 2: EVACUATION DRILLS & BLUEPRINTS ---\nAnnual and quarterly drills must simulate blockaded corridors and chemical vapor escapes. All faculty members must verify roster listings in the Teacher Dashboard within 5 minutes of assembling in the muster yard.\n\nRecommended Checklist:\n• Sound fire drill alarms manually if smoke detectors fail to trigger.\n• Do not deploy fire elevators during structural emergencies.',
          '--- PAGE 3: SPECIAL ASSISTANCE PROTOCOLS ---\nIdentify students with restricted physical mobility prior to semesters. Assign two peer safety assistants to each designated classmate to facilitate wheelchair transport down reinforced structural stairways.',
          '--- PAGE 4: POST-INCIDENT CRITERIA ---\nDo not re-enter academic structures until municipal Fire Response Marshals certify that carbon monoxide meters record less than 9 PPM and structural beams are sound.'
        ]
      },
      {
        id: 'active-threat',
        title: 'Active Threat Tactical Guide',
        filename: 'Active-Threat-Lockdown-2026.pdf',
        size: '1.8 MB',
        category: 'tactical',
        description: 'Standard guidelines on Run-Hide-Fight tactics, custom door barricade techniques, and emergency response team integration.',
        tableOfContents: [
          '1. Threat Identification & Quick Alarms',
          '2. Barricading & Physical Room Fortifications',
          '3. Run-Hide-Fight Matrix Decision Rules',
          '4. Interacting with Entering Law Enforcement'
        ],
        pages: [
          '--- PAGE 1: THREAT IDENTIFICATION ---\nActive physical threats represent high-intensity operations where split-second safety acts determine survival rates. Turn off classroom lights and silence mobile phone ringtones immediately.\n\nImmediate Actions:\n• Lock doors and pull shades to block external visual lines.\n• Barricade door handles with heavy desks, tables, or filing drawers.',
          '--- PAGE 2: RUN-HIDE-FIGHT MATRIX ---\n1. RUN: Evacuate instantly if there is an unobstructed, safe outdoor egress pathway. Leave everything behind.\n2. HIDE: Secure windowless closets or locked offices if escape is blockaded. Silence all audio sources.\n3. FIGHT: Act with extreme physical aggression as a group to disarm the intruder if life is directly threatened.',
          '--- PAGE 3: BARRICADING STRATEGIES ---\nAvoid grouping inside the center of classrooms. Disperse along the walls nearest the doors to be in a blind spot for anyone looking through door window panels. Wedges or straps around door closing arms are highly effective.',
          '--- PAGE 4: DE-ESCALATION & POLICE ENTRY ---\nKeep hands completely empty, fully visible, and raised above your head. Avoid making sudden hand gestures towards response units. Speak only when spoken to by officers.'
        ]
      },
      {
        id: 'science-lab',
        title: 'Science Lab Chemical Safety Manual',
        filename: 'Science-Lab-Chemical-Safety.pdf',
        size: '3.1 MB',
        category: 'chemical',
        description: 'Official safety protocols for chemistry lab solvent leaks, acid neutralizations, emergency eyewash stations, and MSDS logs.',
        tableOfContents: [
          '1. Chemical Hazard Material Labels',
          '2. Eyewash & Safety Shower Protocols',
          '3. Active Acid / Base Spill Containment',
          '4. Toxic Gas Ventilation Procedures'
        ],
        pages: [
          '--- PAGE 1: HAZARD CLASSIFICATION ---\nAll laboratories must display standard NFPA 704 Diamond charts showing Flamability, Health, Instability, and Special Hazard values between 0 and 4.\n\nPrecautions:\n• Secure high-concentration mineral acids in corrosive containment cabinets.\n• Wear level-B protective goggles and nitrile chemical gloves during synthesis.',
          '--- PAGE 2: EMERGENCY FLUSH STATIONS ---\nIf any corrosive chemical drops on skin or eye surfaces, you must activate safety eyewash fountains or body showers and flush with clean flowing water for a MINIMUM of 15 continuous minutes. Do not rub eyes.',
          '--- PAGE 3: HAZMAT SPILL KITS ---\nUse specialized dry chemical binders (sodium bicarbonate for acid spills, citric acid for basic spills) rather than wiping with organic paper towels, which can ignite or produce toxic vapors.',
          '--- PAGE 4: VENTILATION PROTOCOLS ---\nIn case of volatile vapors or natural gas leaks, activate the emergency fume hood max-exhaust toggle, shut off main gas supply handles, and evacuate laboratory units immediately.'
        ]
      },
      {
        id: 'severe-weather',
        title: 'Severe Weather & Tornado Manual',
        filename: 'Severe-Weather-Tornado-Shelters.pdf',
        size: '1.2 MB',
        category: 'natural',
        description: 'Storm warning indicators, reinforced basement safety shelter listings, and procedures for high-wind physical safety.',
        tableOfContents: [
          '1. Watch vs. Warning Classifications',
          '2. Approved Structural Shelter Maps',
          '3. Safety Postures for High Wind Hazards',
          '4. Post-Storm Debris Safety Guidelines'
        ],
        pages: [
          '--- PAGE 1: ATMOSPHERIC THREATS ---\nRecognize weather warning systems:\n• Severe Weather WATCH: Atmospheric conditions exist. Prepare supplies and charge emergency radios.\n• Severe Weather WARNING: Funnel cloud or severe damage is imminent. Seek immediate indoor shelter.',
          '--- PAGE 2: DESIGNATED CAMPUS SHELTERS ---\nSafe zones are located on the lowest levels (basement storage wings) of reinforced concrete structures. Avoid wide-span ceilings like gymnasiums, cafeterias, or performing arts theaters, which can buckle under high loads.',
          '--- PAGE 3: PHYSICAL PROTECTIVE POSTURES ---\nIf sheltering, kneel low on hands and knees, head down, and cover your skull and neck with your hands or heavy protective jackets. Crawl under solid tables or work benches to stay safe from falling drywall panels.',
          '--- PAGE 4: UTILITY DEBRIS PRECAUTIONS ---\nBe alert to fallen utility lines. Assume any downed cable is fully live, energized, and lethal. Avoid touching puddles near downed cables and contact Facilities Maintenance immediately.'
        ]
      },
      {
        id: 'first-aid-quick',
        title: 'First Aid Quick Reference Sheet',
        filename: 'First-Aid-Quick-Reference.pdf',
        size: '850 KB',
        category: 'medical',
        description: 'High-contrast printable safety chart summarizing CPR, tourniquet application, and choked airway relief procedures.',
        tableOfContents: [
          '1. Primary Victim Survey (ABC Check)',
          '2. CPR Chest Compression Cycles',
          '3. Tourniquet & Bleeding Control',
          '4. Managing Shock & Thermal Exposure'
        ],
        pages: [
          '--- PAGE 1: PRIMARY ASSESSMENT ---\nAlways survey the scene for active hazards (exposed wires, fumes) before approaching a victim. Conduct a rapid check using the ABC method:\n• A - AIRWAY: Clear any physical blockages.\n• B - BREATHING: Check for rise and fall of chest.\n• C - CIRCULATION: Check for carotid pulse.',
          '--- PAGE 2: CPR TIMING METRICS ---\nMaintain chest compressions at 100 to 120 beats per minute (BPM). Compress to a depth of 2 to 2.4 inches. Give 30 compressions followed by 2 breaths. If untrained, provide continuous hands-only CPR.',
          '--- PAGE 3: ARTERIAL TRAUMA ---\nFor severe, pulsing arterial bleeding, direct pressure must be applied. If bleeding persists, apply an approved tourniquet 2 to 3 inches above the wound (never over a joint) and tighten until bleeding ceases. Note the application time.',
          '--- PAGE 4: SHOCK MITIGATION ---\nKeep trauma victims warm with thermal space blankets. Elevate legs slightly if there are no spinal fractures, and reassure them to maintain a low heart rate.'
        ]
      }
    ];
  });

  const [docSearch, setDocSearch] = useState<string>('');
  const [docCategory, setDocCategory] = useState<string>('all');
  const [selectedDoc, setSelectedDoc] = useState<SafetyDocument>(safetyDocuments[0]);
  const [docPageIdx, setDocPageIdx] = useState<number>(0);
  const [downloadHistory, setDownloadHistory] = useState<{ name: string; timestamp: string }[]>([]);
  const [isSimulatingDownload, setIsSimulatingDownload] = useState<boolean>(false);
  const [activeDownloadId, setActiveDownloadId] = useState<string | null>(null);

  const filteredDocs = safetyDocuments.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(docSearch.toLowerCase()) || 
                          doc.description.toLowerCase().includes(docSearch.toLowerCase()) ||
                          doc.filename.toLowerCase().includes(docSearch.toLowerCase());
    const matchesCategory = docCategory === 'all' || doc.category === docCategory;
    return matchesSearch && matchesCategory;
  });

  const handleDownloadDoc = (doc: SafetyDocument) => {
    setIsSimulatingDownload(true);
    setActiveDownloadId(doc.id);
    setTimeout(() => {
      setIsSimulatingDownload(false);
      setActiveDownloadId(null);
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setDownloadHistory(prev => [{ name: doc.filename, timestamp: timeStr }, ...prev]);
      
      // Trigger native download simulation
      const textContent = doc.pages.join('\n\n');
      const blob = new Blob([textContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = doc.filename.replace('.pdf', '_export.txt');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }, 1200);
  };

  // ==========================================
  // STATE 2: INTERACTIVE FIRST AID STATION
  // ==========================================
  const firstAidInjuries: FirstAidInjury[] = [
    {
      id: 'bleeding',
      name: 'Severe Arterial Bleeding',
      icon: Activity,
      severity: 'Critical',
      immediateActions: [
        'Apply firm, continuous, direct pressure directly to the bleeding wound using a sterile dressing.',
        'Call Campus Police/Medical dispatchers (+1 555-911-3000) instantly.',
        'If blood saturates the original dressing, place additional dressings directly on top. Do NOT lift the original cloth.',
        'Apply an approved tactical CAT tourniquet 2 to 3 inches above the wound site (closer to the heart) if direct pressure fails.'
      ],
      neverDo: [
        'NEVER apply a tourniquet directly over a joint (like a knee or elbow).',
        'NEVER release pressure or lift dressings to "peek" if the bleeding has slowed down.'
      ],
      requiredGear: [
        'Sterile gauze dressings',
        'Tactical CAT Tourniquet',
        'Protective Nitrile gloves',
        'Permanent marker (to write time on Tourniquet)'
      ],
      practiceSteps: [
        {
          prompt: 'You approach a classmate in Science Lab who has a deep glass laceration on their forearm with pulsing, bright red blood. What is your first priority?',
          choices: [
            'Rinse the forearm under tap water to wash away glass.',
            'Put on protective nitrile gloves and apply firm, direct pressure with clean gauze.',
            'Run out to search for a medical stretcher.'
          ],
          correctIndex: 1,
          successMessage: 'Excellent. Putting on gloves protects you, and direct pressure is the single most critical immediate step to slow arterial blood flow!'
        },
        {
          prompt: 'The direct gauze pressure is saturated with dark red blood. How should you proceed?',
          choices: [
            'Pull off the soaked gauze and wash the wound with iodine.',
            'Apply a second layer of thick gauze directly over the saturated first layer, maintaining heavy pressure.',
            'Squeeze the forearm tightly with your bare hands.'
          ],
          correctIndex: 1,
          successMessage: 'Correct. Never remove the base gauze layer, as doing so destroys newly forming clotting agents. Always layer more gauze on top!'
        },
        {
          prompt: 'Direct pressure fails to stop the heavy pulsing bleed. Where do you place the tourniquet?',
          choices: [
            'Wrap it tightly directly over the elbow joint.',
            'Apply it 2 to 3 inches above the laceration (between the injury and the shoulder), avoiding any joint.',
            'Wrap it directly around their wrist.'
          ],
          correctIndex: 1,
          successMessage: 'Great job. Tourniquets must always be placed 2 to 3 inches above the wound site, avoiding joint zones, and tightened until bleeding stops completely.'
        }
      ]
    },
    {
      id: 'chemical-splash',
      name: 'Corrosive Chemical Splash',
      icon: Skull,
      severity: 'Critical',
      immediateActions: [
        'Lead the victim instantly to the laboratory Emergency Safety Eyewash Station or Body Shower.',
        'Flush all affected skin, face, or eyes with continuous, lukewarm, clean water for at least 15 to 20 minutes.',
        'Instruct the victim to blink rapidly while in the eye fountain stream to ensure fluid rinses behind eyelids.',
        'Gently strip away any contaminated lab clothing or jewelry while flushing.'
      ],
      neverDo: [
        'NEVER apply salves, butter, or neutralizing acid-neutralizer solutions onto the skin without professional oversight.',
        'NEVER delay flushing to wait for emergency transport.'
      ],
      requiredGear: [
        'Emergency eyewash fountain',
        'Safety body shower pulls',
        'Clean hospital blankets or gowns'
      ],
      practiceSteps: [
        {
          prompt: 'A classmate splashes highly concentrated hydrochloric acid on their forearms and near their left eye. What is your initial move?',
          choices: [
            'Smear a basic baking soda paste over their skin to neutralize the acid.',
            'Escort them immediately to the eyewash and body safety shower to begin flushing.',
            'Wipe their arm clean with absorbent paper towels.'
          ],
          correctIndex: 1,
          successMessage: 'Correct. Quick water flushing is paramount. Applying baking soda paste can trigger exothermic reactions, creating thermal burns!'
        },
        {
          prompt: 'How long must the student remain under the continuous safety wash stream?',
          choices: [
            'Until the skin feels cool (usually about 2 to 3 minutes).',
            'At least 15 to 20 continuous minutes.',
            'Only until you retrieve the chemical MSDS sheet.'
          ],
          correctIndex: 1,
          successMessage: 'Spot on. Chemicals continue eating through skin tissues long after surface contact. Continuous washing for 15-20 minutes is mandatory!'
        }
      ]
    },
    {
      id: 'choking',
      name: 'Severe Airway Obstruction',
      icon: AlertTriangle,
      severity: 'Urgent',
      immediateActions: [
        'Verify if the victim can speak, cough, or breathe. If they can cough loudly, encourage them to keep coughing.',
        'If they cannot breathe, speak, or make sound, stand behind them to perform abdominal thrusts (Heimlich Maneuver).',
        'Make a fist with one hand, place the thumb side slightly above their navel (belly button), and clasp with your other hand.',
        'Perform quick, sharp, inward and upward physical thrusts.'
      ],
      neverDo: [
        'NEVER perform abdominal thrusts if the person is coughing powerfully and breathing.',
        'NEVER perform blind finger sweeps inside the mouth unless you can see the object.'
      ],
      requiredGear: [
        'Your physical hands (no gear required)',
        'An AED unit (placed nearby in case of cardiac arrest)'
      ],
      practiceSteps: [
        {
          prompt: 'An individual clutches their throat, cannot speak, and their lips are turning blue. What do you do?',
          choices: [
            'Have them lay flat on their back and punch their chest.',
            'Stand behind them, wrap your arms around their waist, and perform upward abdominal thrusts.',
            'Give them a glass of water to drink immediately.'
          ],
          correctIndex: 1,
          successMessage: 'Correct. The Heimlich maneuver generates instant high pressure in the chest to eject the lodged object from the windpipe.'
        }
      ]
    }
  ];

  const [selectedInjury, setSelectedInjury] = useState<FirstAidInjury>(firstAidInjuries[0]);
  const [practiceStepIdx, setPracticeStepIdx] = useState<number>(0);
  const [selectedPracticeChoice, setSelectedPracticeChoice] = useState<number | null>(null);
  const [showPracticeResult, setShowPracticeResult] = useState<boolean>(false);
  const [isChoiceCorrect, setIsChoiceCorrect] = useState<boolean>(false);
  const [practiceCompleted, setPracticeCompleted] = useState<boolean>(false);

  // CPR Metronome State
  const [cprMetronomeActive, setCprMetronomeActive] = useState<boolean>(false);
  const [metronomeCount, setMetronomeCount] = useState<number>(0);
  const [isMetronomeMuted, setIsMetronomeMuted] = useState<boolean>(true); // browser safe audio default
  const audioCtxRef = useRef<AudioContext | null>(null);
  const intervalRef = useRef<any>(null);

  const startCprMetronome = () => {
    setCprMetronomeActive(true);
    setMetronomeCount(0);
    
    // Interval for 105 Beats Per Minute (approx. 571 ms per beat)
    const msPerBeat = Math.round((60 / 105) * 1000);
    
    intervalRef.current = setInterval(() => {
      setMetronomeCount(prev => prev + 1);
      
      // Play brief audible click if not muted
      if (!isMetronomeMuted) {
        try {
          const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
          if (AudioCtx) {
            const ctx = audioCtxRef.current || new AudioCtx();
            audioCtxRef.current = ctx;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.frequency.setValueAtTime(880, ctx.currentTime); // high click pitch
            gain.gain.setValueAtTime(0.04, ctx.currentTime); // low volume
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05); // quick decay
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.06);
          }
        } catch (e) {
          console.error("Audio metronome click failed:", e);
        }
      }
    }, msPerBeat);
  };

  const stopCprMetronome = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setCprMetronomeActive(false);
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (audioCtxRef.current) audioCtxRef.current.close();
    };
  }, []);

  const handlePracticeAnswerSubmit = (choiceIdx: number) => {
    setSelectedPracticeChoice(choiceIdx);
    const correct = choiceIdx === selectedInjury.practiceSteps[practiceStepIdx].correctIndex;
    setIsChoiceCorrect(correct);
    setShowPracticeResult(true);
  };

  const handleNextPracticeStep = () => {
    setShowPracticeResult(false);
    setSelectedPracticeChoice(null);
    if (practiceStepIdx + 1 < selectedInjury.practiceSteps.length) {
      setPracticeStepIdx(prev => prev + 1);
    } else {
      setPracticeCompleted(true);
    }
  };

  const handleResetPractice = (injury: FirstAidInjury) => {
    setSelectedInjury(injury);
    setPracticeStepIdx(0);
    setSelectedPracticeChoice(null);
    setShowPracticeResult(false);
    setPracticeCompleted(false);
  };

  // ==========================================
  // STATE 3: TRAINING VIDEO ACADEMY
  // ==========================================
  const trainingVideos: TrainingVideo[] = [
    {
      id: 'extinguisher-pass',
      title: 'How to Operate Fire Extinguishers (PASS Technique)',
      duration: '3m 12s',
      category: 'Fire Safety',
      thumbnailColor: 'from-rose-500 to-red-600',
      description: 'Master the Pull, Aim, Squeeze, and Sweep method to safely neutralize combustible or chemical fires before they reach structural flashover.',
      captions: [
        'Welcome to Campus Fire Training. Today, we demonstrate fire extinguisher controls.',
        'Locate standard class-ABC dry chemical containers in your department hallway.',
        'First: PULL the safety pin. This breaks the temper-indicator plastic seal.',
        'Second: AIM low. Point the horn nozzle directly at the BASE of the flames, not the smoke.',
        'Third: SQUEEZE the handle trigger firmly to discharge chemical powder agents.',
        'Fourth: SWEEP slowly from side to side at the fuel source until fire goes out.',
        'Always maintain an escape path behind you. Keep back 6 to 8 feet from high heat.'
      ]
    },
    {
      id: 'hands-only-cpr',
      title: 'Hands-Only CPR & AED Placement Quick Start',
      duration: '2m 45s',
      category: 'Medical Emergency',
      thumbnailColor: 'from-amber-500 to-orange-600',
      description: 'Step-by-step procedures to maintain oxygen circulation for unconscious victims and program an Automated External Defibrillator.',
      captions: [
        'Seconds matter during sudden cardiac arrest. Assess chest responsiveness.',
        'Check breathing. If absent, place heels of both hands in the center of the chest.',
        'Compress deeply (2 to 2.4 inches) at a rhythm of 100 to 120 compressions per minute.',
        'Do not slow down! Keep compressions going until medical paramedics take over.',
        'If an AED arrives: Open the case, power it on, and follow the voice instructions.',
        'Peel and place electrode pads on bare skin: Upper right chest and lower left ribside.',
        'Ensure nobody touches the patient while the AED analyzes cardiac rhythm.',
        'Press the flashing shock button if commanded by the AED system voice.'
      ]
    },
    {
      id: 'active-threat-response',
      title: 'Campus Active Shooter: Run, Hide, Fight Strategy',
      duration: '4m 05s',
      category: 'Security Warning',
      thumbnailColor: 'from-slate-700 to-slate-900',
      description: 'Tactical guidance approved by safety agencies detailing immediate self-preservation decisions during active threat events.',
      captions: [
        'Active threat drills prepare you for critical high-stress physical scenarios.',
        'Remember the primary hierarchy of self-preservation: Run, Hide, Fight.',
        'If an escape route is available: Run immediately. Do not consult others.',
        'If escape is blockaded: Hide. Lock classroom doors, barricade with desks, turn off lights.',
        'Form a defensive layout behind entryways with heavy physical objects.',
        'If confronted directly: Fight with raw physical aggression. Disarm with team force.',
        'When security tactical units enter, raise hands, show palms open and empty.'
      ]
    },
    {
      id: 'chemical-spill-remediation',
      title: 'Laboratory Chemical Spill Containment',
      duration: '3m 30s',
      category: 'Hazard Mitigation',
      thumbnailColor: 'from-emerald-500 to-teal-600',
      description: 'Standard lab procedures to identify hazardous chemicals, use neutralization binders, and log reports.',
      captions: [
        'Chemical compounds pose physical risks. Always verify MSDS labels.',
        'In a spill event: Alert all occupants and clear research laboratory tables.',
        'Retrieve the yellow hazmat spill kit near your department locker.',
        'Apply safety neutralizing chemical sheets over active mineral acids.',
        'Sweep dry coagulated chemical sludge into hazardous discard bins.',
        'Document compound name, spill volume, and reporting crew on logs.'
      ]
    }
  ];

  const [activeVideo, setActiveVideo] = useState<TrainingVideo>(trainingVideos[0]);
  const [videoPlayProgress, setVideoPlayProgress] = useState<number>(0);
  const [videoPlaying, setVideoPlaying] = useState<boolean>(false);
  const [videoCompletedIds, setVideoCompletedIds] = useState<string[]>([]);
  const [currentCaptionIdx, setCurrentCaptionIdx] = useState<number>(0);
  const videoTimerRef = useRef<any>(null);

  // Handle Play/Pause
  const togglePlayVideo = () => {
    if (videoPlaying) {
      clearInterval(videoTimerRef.current);
      setVideoPlaying(false);
    } else {
      setVideoPlaying(true);
      // Advance progress bar by ~4% per second
      videoTimerRef.current = setInterval(() => {
        setVideoPlayProgress(prev => {
          if (prev >= 100) {
            clearInterval(videoTimerRef.current);
            setVideoPlaying(false);
            if (!videoCompletedIds.includes(activeVideo.id)) {
              setVideoCompletedIds(old => [...old, activeVideo.id]);
            }
            return 100;
          }
          return prev + 4;
        });
      }, 1000);
    }
  };

  // Sync captions index to video play progress
  useEffect(() => {
    const totalCaptions = activeVideo.captions.length;
    const progressShare = 100 / totalCaptions;
    const currentIdx = Math.min(
      Math.floor(videoPlayProgress / progressShare),
      totalCaptions - 1
    );
    setCurrentCaptionIdx(currentIdx >= 0 ? currentIdx : 0);
  }, [videoPlayProgress, activeVideo]);

  // Handle switching video
  const selectVideo = (video: TrainingVideo) => {
    if (videoTimerRef.current) clearInterval(videoTimerRef.current);
    setVideoPlaying(false);
    setActiveVideo(video);
    setVideoPlayProgress(0);
    setCurrentCaptionIdx(0);
  };

  // ==========================================
  // STATE 4: TOOLS - CHECKLIST & BLUEPRINTS (Original features perfectly retained)
  // ==========================================
  const [kitItems, setKitItems] = useState([
    { name: "3 Gallons of Drinking Water", checked: true },
    { name: "Non-Perishable Canned Food (3-day supply)", checked: true },
    { name: "Manual Can Opener", checked: true },
    { name: "First Aid Medical Dressing Kit", checked: false },
    { name: "Emergency Whistle or Alert Horn", checked: false },
    { name: "Hand-Crank Flashlight & AM/FM Radio", checked: false },
    { name: "Spare Lithium Batteries", checked: false },
    { name: "N95 Dust Filtration Mask", checked: false },
    { name: "Heavy Utility Work Gloves", checked: false }
  ]);
  const [newItemName, setNewItemName] = useState('');

  // 8x8 Grid representing room blocks
  const [grid, setGrid] = useState<string[][]>(
    Array(8).fill(null).map(() => Array(8).fill('empty'))
  );
  const [drawTool, setDrawTool] = useState<string>('wall');

  const handleToggleKitItem = (idx: number) => {
    const updated = [...kitItems];
    updated[idx].checked = !updated[idx].checked;
    setKitItems(updated);
  };

  const handleAddKitItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;
    setKitItems([...kitItems, { name: newItemName.trim(), checked: false }]);
    setNewItemName('');
  };

  const handleCellClick = (r: number, c: number) => {
    const updated = [...grid.map(row => [...row])];
    updated[r][c] = updated[r][c] === drawTool ? 'empty' : drawTool;
    setGrid(updated);
  };

  const handleClearGrid = () => {
    setGrid(Array(8).fill(null).map(() => Array(8).fill('empty')));
  };

  const checkedCount = kitItems.filter(i => i.checked).length;
  const kitScore = Math.round((checkedCount / kitItems.length) * 100);

  const getCellColor = (val: string) => {
    switch (val) {
      case 'wall': return 'bg-slate-700 border-slate-600 text-white';
      case 'exit': return 'bg-red-600 border-red-500 text-white animate-pulse';
      case 'path': return 'bg-amber-500 border-amber-400 text-slate-950';
      case 'muster': return 'bg-emerald-500 border-emerald-400 text-white';
      default: return 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-400';
    }
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-7xl mx-auto px-1 md:px-4">
      
      {/* HEADER DECK */}
      <div id="resource-header" className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 relative overflow-hidden flex flex-col lg:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="absolute inset-0 bg-blue-600/[0.015] animate-pulse pointer-events-none" />
        
        <div className="space-y-4 max-w-2xl text-center lg:text-left z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full text-[10px] md:text-xs font-bold text-blue-400">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
            COMPREHENSIVE INSTITUTIONAL LIBRARY
          </div>
          <h1 className="text-2xl md:text-4xl font-black text-white tracking-tight leading-none">
            Disaster Preparedness <span className="text-blue-400">Resource Center</span>
          </h1>
          <p className="text-xs text-slate-400 max-w-lg leading-relaxed">
            Access certified compliance handbooks, review video masterclasses, execute interactive first-aid practice sims, and construct custom emergency kits.
          </p>
        </div>

        {/* STATS SUMMARY IN HEADER */}
        <div className="flex gap-4 shrink-0 w-full lg:w-auto z-10 font-mono text-center">
          <div className="bg-slate-950/80 border border-slate-800 px-4 py-3 rounded-2xl flex-1 lg:flex-initial">
            <div className="text-xl font-bold text-blue-400">{safetyDocuments.length}</div>
            <div className="text-[9px] text-slate-500 uppercase tracking-wider">Guides</div>
          </div>
          <div className="bg-slate-950/80 border border-slate-800 px-4 py-3 rounded-2xl flex-1 lg:flex-initial">
            <div className="text-xl font-bold text-emerald-400">{videoCompletedIds.length}/{trainingVideos.length}</div>
            <div className="text-[9px] text-slate-500 uppercase tracking-wider">Videos Done</div>
          </div>
          <div className="bg-slate-950/80 border border-slate-800 px-4 py-3 rounded-2xl flex-1 lg:flex-initial">
            <div className="text-xl font-bold text-amber-500">{kitScore}%</div>
            <div className="text-[9px] text-slate-500 uppercase tracking-wider">Kit Status</div>
          </div>
        </div>
      </div>

      {/* CORE NAVIGATION BAR */}
      <div id="resource-tabs" className="bg-white border border-slate-200 rounded-2xl p-1.5 flex flex-wrap gap-1 shadow-sm">
        <button
          onClick={() => setActiveTab('handbooks')}
          className={`flex-1 min-w-[120px] py-3 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'handbooks' 
              ? 'bg-blue-700 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <FolderOpen className="w-4 h-4" />
          PDF Manuals & Guides
        </button>
        <button
          onClick={() => setActiveTab('firstaid')}
          className={`flex-1 min-w-[120px] py-3 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'firstaid' 
              ? 'bg-blue-700 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <HeartPulse className="w-4 h-4" />
          First Aid & CPR Station
        </button>
        <button
          onClick={() => setActiveTab('videos')}
          className={`flex-1 min-w-[120px] py-3 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'videos' 
              ? 'bg-blue-700 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Play className="w-4 h-4" />
          Video Training Academy
        </button>
        <button
          onClick={() => setActiveTab('tools')}
          className={`flex-1 min-w-[120px] py-3 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'tools' 
              ? 'bg-blue-700 text-white shadow-md' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <ListTodo className="w-4 h-4" />
          Interactive Prep Tools
        </button>
      </div>

      {/* ==========================================
          TAB 1: HANDBOOKS DIRECTORY & VIEWER
          ========================================== */}
      {activeTab === 'handbooks' && (
        <div className="grid lg:grid-cols-3 gap-8 animate-fade-in">
          
          {/* LEFT: Search & PDF List */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-sm">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
                <Search className="w-4 h-4 text-blue-700" />
                Guides Filter Panel
              </h3>

              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Search manuals..."
                  value={docSearch}
                  onChange={(e) => setDocSearch(e.target.value)}
                  className="w-full text-xs p-3 border border-slate-200 bg-slate-50 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />

                <div className="space-y-1">
                  <label className="text-[10px] font-mono text-slate-500 block">CATEGORY</label>
                  <div className="flex flex-col gap-1">
                    {[
                      { id: 'all', label: '🗂️ All Formats' },
                      { id: 'general', label: '🏢 General Safety' },
                      { id: 'tactical', label: '🛡️ Physical Security' },
                      { id: 'chemical', label: '🧪 Science & Hazard' },
                      { id: 'natural', label: '🌪️ Storm & Seismic' },
                      { id: 'medical', label: '⛑️ Medical Guide' }
                    ].map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setDocCategory(cat.id)}
                        className={`text-left text-xs p-2.5 rounded-xl border transition-all ${
                          docCategory === cat.id 
                            ? 'bg-blue-50 text-blue-700 border-blue-200 font-bold' 
                            : 'bg-transparent text-slate-600 border-transparent hover:bg-slate-50'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Downloader Log */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3 shadow-sm">
              <h4 className="text-xs font-black text-slate-900 uppercase tracking-tight flex items-center gap-1.5">
                <Printer className="w-4 h-4 text-blue-700" />
                Workstation Export Log
              </h4>
              <p className="text-[11px] text-slate-500">
                Exports will save as editable text manuals. Print them out to bind inside classroom emergency doors.
              </p>

              {downloadHistory.length === 0 ? (
                <div className="text-center py-6 text-[10px] text-slate-400 font-mono italic">
                  No active exports in this session.
                </div>
              ) : (
                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {downloadHistory.map((hist, i) => (
                    <div key={i} className="flex items-center justify-between text-[10px] bg-slate-50 p-2 rounded border border-slate-100 font-mono">
                      <span className="text-slate-700 truncate max-w-[120px]">{hist.name}</span>
                      <span className="text-emerald-600 font-bold">{hist.timestamp}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* MIDDLE & RIGHT: Selected PDF Viewer */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Horizontal scroll of actual matching cards */}
            <div className="grid md:grid-cols-2 gap-4">
              {filteredDocs.map((doc) => (
                <div 
                  key={doc.id}
                  onClick={() => { setSelectedDoc(doc); setDocPageIdx(0); }}
                  className={`bg-white border rounded-2xl p-4 shadow-sm cursor-pointer transition-all hover:-translate-y-0.5 hover:shadow-md flex flex-col justify-between space-y-4 ${
                    selectedDoc.id === doc.id ? 'border-blue-500 ring-2 ring-blue-500/10' : 'border-slate-200'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] font-mono uppercase tracking-wider bg-slate-100 px-2 py-0.5 rounded text-slate-500">
                        {doc.size}
                      </span>
                      <FileText className={`w-4 h-4 ${selectedDoc.id === doc.id ? 'text-blue-600' : 'text-slate-400'}`} />
                    </div>
                    <h4 className="text-xs font-extrabold text-slate-900 group-hover:text-blue-700 leading-tight">
                      {doc.title}
                    </h4>
                    <p className="text-[10px] text-slate-500 line-clamp-2">
                      {doc.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[10px] font-bold">
                    <span className="text-blue-600 flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5" /> Read
                    </span>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleDownloadDoc(doc); }}
                      disabled={isSimulatingDownload && activeDownloadId === doc.id}
                      className="text-slate-600 hover:text-slate-950 flex items-center gap-1"
                    >
                      {isSimulatingDownload && activeDownloadId === doc.id ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600" /> Processing...
                        </>
                      ) : (
                        <>
                          <Download className="w-3.5 h-3.5" /> Export TXT
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ))}

              {filteredDocs.length === 0 && (
                <div className="col-span-2 text-center bg-white border border-slate-200 rounded-2xl p-10 text-slate-400 text-xs italic">
                  No emergency manuals match your active filters.
                </div>
              )}
            </div>

            {/* INTEGRATED MANUAL READER SIMULATOR */}
            {selectedDoc && (
              <div className="bg-slate-950 text-slate-100 rounded-3xl border border-slate-800 overflow-hidden shadow-2xl">
                
                {/* Header of reader */}
                <div className="bg-slate-900 border-b border-slate-800 p-4 md:px-6 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 bg-blue-600/10 rounded-lg flex items-center justify-center text-blue-400 font-bold border border-blue-500/20">
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold truncate max-w-[240px] md:max-w-none text-slate-100">{selectedDoc.title}</div>
                      <div className="text-[9px] text-slate-400 font-mono uppercase tracking-wider">{selectedDoc.filename}</div>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => handleDownloadDoc(selectedDoc)}
                    disabled={isSimulatingDownload && activeDownloadId === selectedDoc.id}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 py-1.5 px-3 rounded-xl text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                  >
                    {isSimulatingDownload && activeDownloadId === selectedDoc.id ? (
                      <RefreshCw className="w-3 h-3 animate-spin text-blue-400" />
                    ) : (
                      <Download className="w-3 h-3" />
                    )}
                    Print Guide
                  </button>
                </div>

                {/* Main panel - TOC + Page Content */}
                <div className="grid md:grid-cols-4 min-h-[300px]">
                  
                  {/* Left panel: TOC */}
                  <div className="md:col-span-1 bg-slate-900/50 p-4 border-r border-slate-900 space-y-3 hidden md:block">
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block">TABLE OF CONTENTS</span>
                    <div className="space-y-1">
                      {selectedDoc.tableOfContents.map((chapter, cIdx) => (
                        <button
                          key={cIdx}
                          onClick={() => setDocPageIdx(cIdx)}
                          className={`w-full text-left text-[10px] p-2 rounded transition-all leading-tight ${
                            docPageIdx === cIdx 
                              ? 'bg-blue-600/15 text-blue-300 font-bold' 
                              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                          }`}
                        >
                          {chapter}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Right panel: Page viewer screen */}
                  <div className="md:col-span-3 p-6 flex flex-col justify-between space-y-6">
                    <div className="bg-slate-900 border border-slate-850 p-5 rounded-2xl min-h-[200px] shadow-inner font-mono text-xs leading-relaxed text-slate-300 select-text whitespace-pre-wrap">
                      {selectedDoc.pages[docPageIdx]}
                    </div>

                    {/* Pagination */}
                    <div className="flex items-center justify-between pt-4 border-t border-slate-900">
                      <button
                        onClick={() => setDocPageIdx(prev => Math.max(0, prev - 1))}
                        disabled={docPageIdx === 0}
                        className="p-1.5 bg-slate-900 text-slate-400 hover:text-slate-100 rounded disabled:opacity-30 cursor-pointer"
                      >
                        Previous Page
                      </button>
                      <span className="text-[10px] font-mono text-slate-500">
                        Page {docPageIdx + 1} of {selectedDoc.pages.length}
                      </span>
                      <button
                        onClick={() => setDocPageIdx(prev => Math.min(selectedDoc.pages.length - 1, prev + 1))}
                        disabled={docPageIdx === selectedDoc.pages.length - 1}
                        className="p-1.5 bg-slate-900 text-slate-400 hover:text-slate-100 rounded disabled:opacity-30 cursor-pointer"
                      >
                        Next Page
                      </button>
                    </div>
                  </div>

                </div>

              </div>
            )}

          </div>

        </div>
      )}

      {/* ==========================================
          TAB 2: FIRST AID & CPR STATION
          ========================================== */}
      {activeTab === 'firstaid' && (
        <div className="space-y-8 animate-fade-in">
          
          {/* CPR METRONOME DRUM BANNER */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 text-blue-500/5 select-none pointer-events-none">
              <HeartPulse className="w-48 h-48 animate-pulse" />
            </div>

            <div className="space-y-3 max-w-xl z-10 text-center md:text-left">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-50 text-red-700 border border-red-100 rounded-full text-[10px] font-bold">
                <span className="w-2 h-2 rounded-full bg-red-600 animate-ping" />
                CPR METRONOME DRILL CONTROLS
              </div>
              <h3 className="text-lg font-black text-slate-900">
                Hands-Only CPR Chest Compression Rhythm
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Survival rates double if compressions are kept between 100 and 120 beats per minute (BPM). This interactive metronome delivers visual ticks at **105 BPM** to practice standard CPR compression intervals.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-4 shrink-0 z-10">
              
              {/* Pulse Visualizer */}
              <div className="flex items-center gap-1 bg-slate-900 px-4 py-3 rounded-2xl border border-slate-800">
                <div className={`w-3.5 h-3.5 rounded-full ${cprMetronomeActive ? 'bg-red-500 animate-ping' : 'bg-slate-700'}`} />
                <span className="font-mono text-xs text-slate-300 font-bold w-12 text-center">
                  {cprMetronomeActive ? `${metronomeCount} BEATS` : 'READY'}
                </span>
              </div>

              {/* Mute Toggle */}
              <button
                onClick={() => setIsMetronomeMuted(!isMetronomeMuted)}
                className={`p-3 rounded-xl border transition-all cursor-pointer ${
                  isMetronomeMuted 
                    ? 'bg-slate-100 text-slate-500 border-slate-200' 
                    : 'bg-amber-50 border-amber-200 text-amber-700'
                }`}
                title={isMetronomeMuted ? "Enable Sound Click" : "Mute Sound Click"}
              >
                {isMetronomeMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>

              {/* Start Metronome Button */}
              <button
                onClick={cprMetronomeActive ? stopCprMetronome : startCprMetronome}
                className={`w-40 py-3 rounded-xl font-bold text-xs shadow transition-all cursor-pointer ${
                  cprMetronomeActive 
                    ? 'bg-red-600 hover:bg-red-700 text-white shadow-red-600/10' 
                    : 'bg-blue-700 hover:bg-blue-800 text-white shadow-blue-700/10'
                }`}
              >
                {cprMetronomeActive ? 'Stop Metronome' : 'Activate Metronome'}
              </button>
            </div>
          </div>

          {/* TWO PANEL: Injury Guides List (Left) + Interactive Practice Scenario Simulator (Right) */}
          <div className="grid lg:grid-cols-3 gap-8">
            
            {/* LEFT: Injuries List Cards */}
            <div className="lg:col-span-1 space-y-4">
              <div className="flex justify-between items-center px-1">
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Select Injury Scenario</span>
                <span className="text-[10px] text-blue-600 font-bold">Interactive practice inside</span>
              </div>

              {firstAidInjuries.map((injury) => {
                const InjuryIcon = injury.icon;
                return (
                  <div
                    key={injury.id}
                    onClick={() => handleResetPractice(injury)}
                    className={`bg-white border rounded-2xl p-5 shadow-sm cursor-pointer transition-all hover:border-blue-300 flex items-start gap-4 ${
                      selectedInjury.id === injury.id ? 'border-blue-500 ring-2 ring-blue-500/10' : 'border-slate-200'
                    }`}
                  >
                    <div className={`p-3 rounded-xl ${
                      injury.severity === 'Critical' ? 'bg-red-50 text-red-600' : 'bg-amber-50 text-amber-600'
                    }`}>
                      <InjuryIcon className="w-5 h-5" />
                    </div>
                    
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-black text-slate-900 leading-tight">
                          {injury.name}
                        </h4>
                        <span className={`text-[8px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                          injury.severity === 'Critical' ? 'bg-red-500 text-white' : 'bg-amber-400 text-slate-950'
                        }`}>
                          {injury.severity}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500">
                        {injury.immediateActions[0]}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* RIGHT: Detail Viewer & Step-By-Step Practice Simulation */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Detailed Procedures Card */}
              <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-4 gap-4">
                  <div className="space-y-1">
                    <h3 className="text-base font-black text-slate-900 uppercase">
                      ⛑️ {selectedInjury.name} Quick Response Protocol
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Standard operational procedures compiled by trauma clinicians and compliance boards.
                    </p>
                  </div>
                  
                  <button 
                    onClick={() => handleResetPractice(selectedInjury)}
                    className="self-start sm:self-center py-1.5 px-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-[10px] font-mono font-bold text-slate-600 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" /> Reset Practice Sim
                  </button>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  
                  {/* Immediate actions */}
                  <div className="space-y-3">
                    <span className="text-[9px] font-mono font-black text-emerald-700 uppercase tracking-widest block bg-emerald-50 px-2 py-1 rounded">
                      Immediate Actions (First 60s)
                    </span>
                    <ul className="space-y-2 text-xs">
                      {selectedInjury.immediateActions.map((act, i) => (
                        <li key={i} className="flex gap-2 text-slate-700 leading-relaxed">
                          <Check className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                          <span>{act}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Never do & Gear */}
                  <div className="space-y-6">
                    <div className="space-y-3">
                      <span className="text-[9px] font-mono font-black text-red-700 uppercase tracking-widest block bg-red-50 px-2 py-1 rounded">
                        Critical Safety Warnings
                      </span>
                      <ul className="space-y-2 text-xs">
                        {selectedInjury.neverDo.map((warn, i) => (
                          <li key={i} className="flex gap-2 text-slate-700 leading-relaxed">
                            <X className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                            <span>{warn}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="space-y-3">
                      <span className="text-[9px] font-mono font-black text-blue-700 uppercase tracking-widest block bg-blue-50 px-2 py-1 rounded">
                        Required First Aid Gear
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedInjury.requiredGear.map((gear, i) => (
                          <span key={i} className="text-[10px] font-mono bg-slate-100 text-slate-700 py-1 px-2.5 rounded-lg border border-slate-150">
                            ⚙️ {gear}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                </div>

                {/* THE PRACTICE SIMULATION STAGE */}
                <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 space-y-4 shadow-inner relative overflow-hidden">
                  <div className="absolute -top-12 -right-12 p-12 text-blue-500/5 select-none pointer-events-none">
                    <Sparkles className="w-32 h-32" />
                  </div>

                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <Award className="w-4 h-4 text-amber-500 animate-pulse" />
                      <span className="text-[10px] font-mono font-bold text-amber-400">PRACTICE DIAGNOSTIC SIMULATOR</span>
                    </div>
                    <span className="text-[9px] font-mono text-slate-500 uppercase">
                      Scenario Progress: {practiceStepIdx + 1} / {selectedInjury.practiceSteps.length}
                    </span>
                  </div>

                  {!practiceCompleted ? (
                    <div className="space-y-4 relative z-10">
                      
                      {/* Active prompt question */}
                      <p className="text-xs font-bold leading-relaxed text-slate-100">
                        ❓ {selectedInjury.practiceSteps[practiceStepIdx].prompt}
                      </p>

                      {/* Choice items */}
                      <div className="space-y-2">
                        {selectedInjury.practiceSteps[practiceStepIdx].choices.map((choice, idx) => {
                          const isSelected = selectedPracticeChoice === idx;
                          return (
                            <button
                              key={idx}
                              disabled={showPracticeResult}
                              onClick={() => handlePracticeAnswerSubmit(idx)}
                              className={`w-full text-left p-3 rounded-xl border transition-all text-xs flex justify-between items-center cursor-pointer ${
                                isSelected 
                                  ? isChoiceCorrect 
                                    ? 'bg-emerald-500/10 border-emerald-500 text-emerald-200' 
                                    : 'bg-red-500/10 border-red-500 text-red-200'
                                  : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'
                              }`}
                            >
                              <span>{choice}</span>
                              {isSelected && (isChoiceCorrect ? <Check className="w-4 h-4 text-emerald-400" /> : <X className="w-4 h-4 text-red-400" />)}
                            </button>
                          );
                        })}
                      </div>

                      {/* Feedback results panel */}
                      {showPracticeResult && (
                        <div className={`p-4 rounded-xl border animate-slide-down ${
                          isChoiceCorrect ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-300' : 'bg-red-500/5 border-red-500/20 text-red-300'
                        }`}>
                          <div className="flex items-start gap-2.5 text-xs">
                            <div className="mt-0.5">
                              {isChoiceCorrect ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-red-400" />}
                            </div>
                            <div className="space-y-2">
                              <span className="font-extrabold block">
                                {isChoiceCorrect ? '✓ Verification Passed' : '✗ Protocol Breach'}
                              </span>
                              <p className="text-[11px] leading-relaxed text-slate-300">
                                {isChoiceCorrect 
                                  ? selectedInjury.practiceSteps[practiceStepIdx].successMessage 
                                  : 'Correction: Re-evaluate guidelines and choose the safest, most logical immediate medical intervention.'}
                              </p>
                              
                              <button
                                onClick={isChoiceCorrect ? handleNextPracticeStep : () => setShowPracticeResult(false)}
                                className="py-1 px-4 bg-white hover:bg-slate-100 text-slate-950 font-black text-[10px] rounded shadow transition-colors"
                              >
                                {isChoiceCorrect ? 'Proceed Next Step →' : 'Re-try Choice'}
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                    </div>
                  ) : (
                    <div className="text-center py-6 space-y-4 animate-fade-in relative z-10">
                      <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto text-xl">
                        ✓
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-sm font-black text-white">First Aid Skill Training Confirmed!</h4>
                        <p className="text-[10px] text-slate-400 max-w-sm mx-auto leading-relaxed">
                          You have successfully completed the diagnostic practice flow for **{selectedInjury.name}**. You are ready for field incidents!
                        </p>
                      </div>
                      <button
                        onClick={() => handleResetPractice(selectedInjury)}
                        className="py-1.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow cursor-pointer transition-colors"
                      >
                        Practice Again
                      </button>
                    </div>
                  )}

                </div>

              </div>

            </div>

          </div>

        </div>
      )}

      {/* ==========================================
          TAB 3: TRAINING VIDEO ACADEMY
          ========================================== */}
      {activeTab === 'videos' && (
        <div className="grid lg:grid-cols-3 gap-8 animate-fade-in">
          
          {/* LEFT: Videos List Panel */}
          <div className="lg:col-span-1 space-y-4">
            <div className="flex justify-between items-center px-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Training Modules</span>
              <span className="text-[10px] text-blue-600 font-bold">Earn Certification Status</span>
            </div>

            {trainingVideos.map((video) => {
              const isCompleted = videoCompletedIds.includes(video.id);
              const isActive = activeVideo.id === video.id;
              return (
                <div
                  key={video.id}
                  onClick={() => selectVideo(video)}
                  className={`bg-white border rounded-2xl p-4 shadow-sm cursor-pointer transition-all hover:border-slate-300 flex flex-col justify-between space-y-3 relative overflow-hidden ${
                    isActive ? 'border-blue-500 ring-2 ring-blue-500/10' : 'border-slate-200'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-[9px] font-mono">
                      <span className="bg-slate-100 text-slate-600 py-0.5 px-2 rounded uppercase tracking-wider">
                        {video.category}
                      </span>
                      <span className="text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {video.duration}
                      </span>
                    </div>

                    <h4 className="text-xs font-black text-slate-900 leading-snug">
                      {video.title}
                    </h4>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[10px] font-bold">
                    <span className="text-slate-500 flex items-center gap-1 font-mono">
                      {isCompleted ? (
                        <span className="text-emerald-600 flex items-center gap-0.5">
                          <Check className="w-3.5 h-3.5" /> Completed
                        </span>
                      ) : (
                        <span className="text-slate-400">Unwatched</span>
                      )}
                    </span>
                    
                    <span className="text-blue-600 flex items-center gap-1 group-hover:underline">
                      Play Simulation <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* MIDDLE/RIGHT: Video Player Simulator Screen */}
          <div className="lg:col-span-2 space-y-6">
            
            <div className="bg-slate-950 text-white rounded-3xl border border-slate-800 overflow-hidden shadow-2xl space-y-4 p-5 md:p-6">
              
              {/* VIDEO SCREEN EMBED SIMULATOR */}
              <div className={`relative aspect-video rounded-2xl overflow-hidden bg-gradient-to-br ${activeVideo.thumbnailColor} border border-slate-800 flex flex-col justify-between p-6 shadow-inner`}>
                
                {/* top corner overlays */}
                <div className="flex justify-between items-start z-10 font-mono text-[9px] font-bold">
                  <div className="bg-slate-950/80 backdrop-blur px-2.5 py-1 rounded-lg border border-slate-800 text-slate-200 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                    SIMULATED LESSON FEED
                  </div>
                  <div className="bg-slate-950/80 backdrop-blur px-2.5 py-1 rounded-lg border border-slate-800 text-slate-300">
                    SPEED: 1.0x
                  </div>
                </div>

                {/* center big button play */}
                <div className="flex justify-center items-center z-10">
                  <button
                    onClick={togglePlayVideo}
                    className="w-16 h-16 rounded-full bg-slate-950/90 hover:bg-slate-950 border border-slate-800 text-white flex items-center justify-center shadow-2xl transition-all hover:scale-105 hover:border-slate-700 cursor-pointer"
                  >
                    {videoPlaying ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7 ml-1" />}
                  </button>
                </div>

                {/* BOTTOM CLOSED CAPTIONS FRAME */}
                <div className="bg-slate-950/90 border border-slate-800 p-3 rounded-xl max-w-xl mx-auto w-full text-center z-10">
                  <p className="text-[11px] font-mono font-bold leading-normal text-amber-300 tracking-wide">
                    🗣️ "{activeVideo.captions[currentCaptionIdx]}"
                  </p>
                </div>

              </div>

              {/* VIDEO PLAYER METRIC CONTROLS */}
              <div className="space-y-4">
                
                {/* Progress bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
                    <span>PLAYBACK TIMELINE PROGRESS</span>
                    <span>{videoPlayProgress}% COMPLETE</span>
                  </div>
                  
                  <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div 
                      className="bg-blue-500 h-full transition-all duration-300" 
                      style={{ width: `${videoPlayProgress}%` }} 
                    />
                  </div>
                </div>

                {/* Title & Description of current video */}
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-t border-slate-900 pt-4">
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-slate-100">
                      {activeVideo.title}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed max-w-xl">
                      {activeVideo.description}
                    </p>
                  </div>

                  <div className="shrink-0 flex items-center gap-2">
                    {videoCompletedIds.includes(activeVideo.id) ? (
                      <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1.5 rounded-xl text-[10px] font-bold flex items-center gap-1 font-mono">
                        <Check className="w-3.5 h-3.5" /> MODULE COMPLETE
                      </span>
                    ) : (
                      <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 px-3 py-1.5 rounded-xl text-[10px] font-bold flex items-center gap-1 font-mono animate-pulse">
                        <AlertCircle className="w-3.5 h-3.5" /> UNFINISHED
                      </span>
                    )}
                  </div>
                </div>

              </div>

            </div>

          </div>

        </div>
      )}

      {/* ==========================================
          TAB 4: INTERACTIVE CHECKLISTS & SKETCHPAD (Original compliance features preserved)
          ========================================== */}
      {activeTab === 'tools' && (
        <div className="grid md:grid-cols-2 gap-8 animate-fade-in">
          
          {/* Grab-Kit Checklist Builder */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-6 shadow-sm">
            <div className="space-y-1">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
                <CheckSquare className="w-4 h-4 text-blue-700" />
                Emergency Grab-Kit Checklist Builder
              </h3>
              <p className="text-xs text-slate-500 leading-normal">
                Pack a personal disaster grab-bag. Check off essential items to calculate your readiness score, and insert custom equipment below.
              </p>
            </div>

            {/* Score Gauge */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-150 flex items-center justify-between gap-4">
              <div className="space-y-0.5">
                <div className="text-xl font-black text-amber-600 font-mono">{kitScore}%</div>
                <div className="text-[9px] font-mono tracking-wider text-slate-500 uppercase">Emergency Kit Ready</div>
              </div>
              <div className="w-36 bg-slate-200 h-2.5 rounded-full overflow-hidden border border-slate-300">
                <div className="bg-amber-500 h-full transition-all duration-300" style={{ width: `${kitScore}%` }} />
              </div>
            </div>

            {/* Checklist items */}
            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 text-xs">
              {kitItems.map((item, idx) => (
                <label 
                  key={idx} 
                  className={`flex items-center gap-3 p-2.5 rounded-xl border transition-all cursor-pointer ${
                    item.checked 
                      ? 'bg-amber-500/5 border-amber-500/20 text-slate-800 font-medium' 
                      : 'bg-slate-50 border-slate-150 text-slate-400'
                  }`}
                >
                  <input 
                    type="checkbox" 
                    checked={item.checked}
                    onChange={() => handleToggleKitItem(idx)}
                    className="w-3.5 h-3.5 rounded text-amber-500 bg-slate-100 border-slate-300 accent-amber-500 shrink-0"
                  />
                  <span className="truncate">{item.name}</span>
                </label>
              ))}
            </div>

            {/* Add custom item form */}
            <form onSubmit={handleAddKitItem} className="flex gap-2 text-xs pt-2">
              <input 
                type="text" 
                required
                value={newItemName}
                onChange={e => setNewItemName(e.target.value)}
                placeholder="e.g. Inhaler, emergency radio..."
                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
              />
              <button 
                type="submit"
                className="bg-slate-900 hover:bg-slate-850 text-amber-400 hover:text-white font-extrabold px-4 py-2 rounded-xl text-xs transition-all shadow cursor-pointer shrink-0"
              >
                Insert Item
              </button>
            </form>
          </div>

          {/* Evacuation Blueprint Sketcher Grid */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-6 shadow-sm">
            <div className="space-y-1">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
                <LayoutGrid className="w-4 h-4 text-blue-700" />
                Exit Route Sketchpad Grid
              </h3>
              <p className="text-xs text-slate-500 leading-normal">
                Sketch customized room egress routes. Choose a tile type and tap on the grid cells to draw blockages, exit doors, paths, and assembly muster fields.
              </p>
            </div>

            {/* Selector Toolbar */}
            <div className="flex flex-wrap gap-1 bg-slate-50 p-2 rounded-xl border border-slate-200 text-[10px] font-bold justify-between">
              <div className="flex flex-wrap gap-1">
                <button 
                  onClick={() => setDrawTool('wall')}
                  className={`px-2.5 py-1 rounded transition-all cursor-pointer ${drawTool === 'wall' ? 'bg-slate-700 text-white' : 'text-slate-500 hover:text-slate-800'}`}
                >
                  🧱 Wall
                </button>
                <button 
                  onClick={() => setDrawTool('exit')}
                  className={`px-2.5 py-1 rounded transition-all cursor-pointer ${drawTool === 'exit' ? 'bg-red-600 text-white font-bold' : 'text-slate-500 hover:text-slate-800'}`}
                >
                  🚪 Exit
                </button>
                <button 
                  onClick={() => setDrawTool('path')}
                  className={`px-2.5 py-1 rounded transition-all cursor-pointer ${drawTool === 'path' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-500 hover:text-slate-800'}`}
                >
                  🔀 Path
                </button>
                <button 
                  onClick={() => setDrawTool('muster')}
                  className={`px-2.5 py-1 rounded transition-all cursor-pointer ${drawTool === 'muster' ? 'bg-emerald-500 text-white font-bold' : 'text-slate-500 hover:text-slate-800'}`}
                >
                  🏁 Muster
                </button>
              </div>

              <button 
                onClick={handleClearGrid}
                className="text-red-600 hover:text-red-700 font-mono uppercase text-[9px] hover:underline"
              >
                Reset Grid
              </button>
            </div>

            {/* Grid Container */}
            <div className="flex justify-center">
              <div className="grid grid-cols-8 gap-1 bg-slate-50 p-3 rounded-2xl border border-slate-200 w-full aspect-square max-w-[260px] shadow-inner">
                {grid.map((row, rIdx) => 
                  row.map((cell, cIdx) => (
                    <button
                      key={`${rIdx}-${cIdx}`}
                      onClick={() => handleCellClick(rIdx, cIdx)}
                      className={`aspect-square border rounded-md transition-colors cursor-pointer text-[8px] font-black ${getCellColor(cell)} flex items-center justify-center`}
                      title="Tap to draw"
                    >
                      {cell === 'exit' ? 'EXIT' : cell === 'muster' ? 'SAFE' : ''}
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
