import React, { useState, useRef, useEffect } from 'react';
import { 
  MessageSquare, Send, Bot, User, RefreshCw, 
  HelpCircle, ChevronRight, AlertTriangle, Play,
  Volume2, VolumeX, Copy, Check, Heart, Droplet,
  Flame, Activity, Thermometer, Phone, Info,
  ShieldAlert, Sparkles, CheckSquare, Square, ClipboardList, LifeBuoy
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

interface FirstAidProtocol {
  title: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  steps: string[];
  tip: string;
}

export default function AiChatbot() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { 
      id: 'msg-1', 
      role: 'assistant', 
      content: "Hello! I am your AI Disaster Assistant & Emergency Response Specialist.\n\nI am fully equipped with federal disaster guidelines, first-aid protocols, and emergency evacuation procedures.\n\nHow can I assist you with safety, preparedness, or urgent first-aid questions today?" 
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isPlayingSpeech, setIsPlayingSpeech] = useState<string | null>(null);

  // First Aid protocols state
  const [activeProtocolKey, setActiveProtocolKey] = useState<string | null>(null);

  // FEMA Kit items list
  const initialFemaItems = [
    { id: 'item-1', label: '3-Day Water Supply (1 gallon/person/day)', checked: false },
    { id: 'item-2', label: '3-Day Non-Perishable Canned Food', checked: false },
    { id: 'item-3', label: 'Loud Whistle (to signal rescuers)', checked: false },
    { id: 'item-4', label: 'Heavy-Duty Flashlight & Extra Batteries', checked: false },
    { id: 'item-5', label: 'Laminated First-Aid & Trauma Kit', checked: false },
    { id: 'item-6', label: 'Hand-Crank or Battery NOAA Radio', checked: false },
    { id: 'item-7', label: 'Dust Masks (for air filtration)', checked: false },
    { id: 'item-8', label: 'Multi-tool / Heavy-Duty Pocket knife', checked: false }
  ];

  const [femaItems, setFemaItems] = useState(initialFemaItems);

  // Load checklist progress from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('fema_kit_progress');
      if (saved) {
        setFemaItems(JSON.parse(saved));
      }
    } catch (e) {
      console.warn("Failed to load FEMA kit items from storage", e);
    }
  }, []);

  const handleFemaToggle = (id: string) => {
    const updated = femaItems.map(item => 
      item.id === id ? { ...item, checked: !item.checked } : item
    );
    setFemaItems(updated);
    try {
      localStorage.setItem('fema_kit_progress', JSON.stringify(updated));
    } catch (e) {
      console.warn("Failed to persist FEMA kit progress", e);
    }
  };

  const completedFemaCount = femaItems.filter(item => item.checked).length;
  const femaProgressPercentage = Math.round((completedFemaCount / femaItems.length) * 100);

  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  // Quick Chips (Safety shortcuts)
  const safetyShortcuts = [
    "Step-by-step CPR instructions",
    "How to treat severe bleeding?",
    "First-aid for 2nd-degree burns",
    "FEMA safety kit checklist info",
    "Active shooter campus response"
  ];

  // First Aid Manual Static Protocol Data
  const firstAidProtocols: Record<string, FirstAidProtocol> = {
    cpr: {
      title: "Cardiopulmonary Resuscitation (CPR)",
      severity: "CRITICAL",
      steps: [
        "Verify scene safety. Tap the person's shoulder and shout 'Are you OK?' loudly.",
        "Call 911 immediately (or direct someone to do so) and request an AED.",
        "Check breathing: If not breathing or only gasping, immediately start chest compressions.",
        "Give 30 compressions: Push hard & fast in the center of the chest (100-120 beats per minute, 2 inches deep).",
        "Give 2 rescue breaths: Tilt head back, lift chin, pinch nose, and blow into the mouth.",
        "Repeat cycles of 30 compressions and 2 breaths. Use AED as soon as it is available."
      ],
      tip: "Think of the song 'Stayin' Alive' for the perfect 100-120 bpm rhythm."
    },
    bleeding: {
      title: "Severe Bleeding Protocol",
      severity: "HIGH",
      steps: [
        "Put on gloves if available. Avoid exposing yourself to blood.",
        "Apply direct pressure: Place a sterile dressing or clean cloth over the wound and apply firm pressure.",
        "Elevate the injury: If possible, keep the bleeding limb raised above heart level.",
        "Apply pressure bandage: Wrap a bandage tightly over the dressing to hold constant pressure.",
        "Do NOT remove soaked dressings: Layer more cloth on top to avoid tearing clotting blood.",
        "If bleeding is life-threatening, apply a tourniquet 2 inches above the wound (never on joints)."
      ],
      tip: "Tourniquets hurt. If applied correctly, they will save a life. Note the exact application time."
    },
    burns: {
      title: "Thermal & Chemical Burns",
      severity: "MEDIUM",
      steps: [
        "Remove source of heat or flush dry chemicals with cool running water for 20 minutes.",
        "Cool the burn: Submerge or run cool (not cold or icy) tap water over the burn for 10-15 minutes.",
        "Protect: Cover loosely with a sterile, non-stick dry dressing.",
        "Do NOT apply butter, oils, or ice: These trap heat, damage tissue, and invite infection.",
        "Do NOT break blisters: Blisters protect the healing layer underneath."
      ],
      tip: "Get medical help immediately for burns covering the face, hands, major joints, or large skin areas."
    },
    choking: {
      title: "Choking (Heimlich Maneuver)",
      severity: "CRITICAL",
      steps: [
        "Ask 'Are you choking?' If they can speak, cough, or breathe, do not perform the maneuver.",
        "Give 5 back blows: Stand behind them, bend them forward, and deliver 5 firm blows with the heel of your hand between their shoulder blades.",
        "Give 5 abdominal thrusts: Stand behind them, wrap arms around waist, make a fist above their navel, grab it with the other hand, and pull in & up.",
        "Alternate 5 back blows and 5 thrusts until the object is dislodged or the person loses consciousness.",
        "If they become unconscious, carefully lower them to the floor and begin CPR."
      ],
      tip: "Never perform thrusts on someone who is coughing strongly, as they may clear the blockage themselves."
    },
    poison: {
      title: "Poisoning & Toxic Exposure",
      severity: "HIGH",
      steps: [
        "Ensure scene safety: Avoid inhaling fumes. Move the victim to fresh air if gases are present.",
        "If swallowed: Do NOT induce vomiting unless instructed by medical staff.",
        "If on skin/eyes: Flush thoroughly with running tap water for at least 15-20 minutes.",
        "Call Poison Control: Contact 1-800-222-1222 immediately for customized treatment advice.",
        "Have the substance container ready to read labels to the poison specialist."
      ],
      tip: "Keep the container or residue of the ingested substance to show emergency crews."
    }
  };

  const handleShortcutClick = (query: string) => {
    if (loading) return;
    sendMessage(query);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;
    sendMessage(input.trim());
    setInput('');
  };

  const sendMessage = async (text: string) => {
    const userMsg: ChatMessage = { id: `msg-${Date.now()}`, role: 'user', content: text };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);
    setErrorMsg('');

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: messages.map(m => ({
            role: m.role === 'user' ? 'user' : 'model',
            content: m.content
          }))
        })
      });

      const data = await response.json();
      if (data.success) {
        const assistantMsg: ChatMessage = { id: `msg-${Date.now() + 1}`, role: 'assistant', content: data.response };
        setMessages(prev => [...prev, assistantMsg]);
      } else {
        throw new Error(data.error || "Failed to formulate safety reply.");
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "An issue occurred. Falling back to emergency local database advice.");
      
      // Smart offline fallback logic with highly specific answers depending on the keyword match
      let fallbackText = `⚠️ [OFFLINE DATABASE COMPLIANCE]: I am currently providing instructions from preloaded disaster guidelines because the server-side GEMINI_API_KEY is not configured in Settings.\n\n`;
      const normalized = text.toLowerCase();
      
      if (normalized.includes("cpr") || normalized.includes("compress")) {
        fallbackText += `**Emergency CPR Guidelines (Preloaded):**\n1. Ensure the area is safe. Tap the shoulder and shout 'Are you OK?'\n2. Call 911 or direct someone to get an AED.\n3. Check breathing. If absent, start compressions immediately.\n4. Push hard and fast in the center of the chest: **30 compressions** (2 inches deep, 100-120 bpm).\n5. Tilt head, lift chin, and give **2 rescue breaths**.\n6. Continue until AED arrives or paramedics take over.`;
      } else if (normalized.includes("bleed") || normalized.includes("wound") || normalized.includes("blood")) {
        fallbackText += `**Emergency Bleeding Guidelines (Preloaded):**\n1. Protect yourself: Wear gloves if available.\n2. Apply direct, firm pressure with sterile dressing or clean cloth.\n3. Elevate the wounded limb above heart level.\n4. Secure with a tight pressure bandage.\n5. If severe and limb is threatened, apply a tourniquet 2 inches above the wound and record the exact time.`;
      } else if (normalized.includes("burn") || normalized.includes("fire")) {
        fallbackText += `**Emergency Burn Guidelines (Preloaded):**\n1. Safe the environment: Eliminate heat or rinse dry chemicals.\n2. Cool the wound with **cool running tap water** for 10-15 minutes. (No ice, no freezing water).\n3. Cover loosely with non-stick sterile gauze.\n4. Do NOT pop blisters or apply ointments, butter, or oil to the skin.`;
      } else if (normalized.includes("chok") || normalized.includes("heimlich")) {
        fallbackText += `**Emergency Choking Guidelines (Preloaded):**\n1. Ask 'Are you choking?'. If they cannot talk or cough, begin immediately.\n2. Stand behind them. Give **5 firm blows** between the shoulder blades with the heel of your hand.\n3. Wrap your arms around their waist. Place a fist above the navel and deliver **5 rapid upward thrusts**.\n4. Alternate 5 blows and 5 thrusts until the airway is clear.`;
      } else if (normalized.includes("kit") || normalized.includes("fema") || normalized.includes("supply")) {
        fallbackText += `**FEMA Emergency Supply Guidelines (Preloaded):**\n- **Water**: 1 gallon per person, per day for a minimum of 3 days (drinking + sanitation).\n- **Food**: A 3-day supply of canned goods and non-perishable food.\n- **Radio**: Hand-crank or battery-operated NOAA Weather Radio.\n- **First-Aid Kit**: Bandaids, tourniquets, antiseptics, scissors, tape, and daily medications.\n- **Tools**: Whistle, flashlight, multi-tool, dust masks, and extra phone charger batteries.`;
      } else {
        fallbackText += `**General Emergency Guidance on "${text}":**\n- **Safety First**: Secure yourself before attempting to assist others.\n- **Primary Assessment**: Check responsiveness, airways, breathing, and circulation.\n- **Contact Experts**: Call 911 for all life-threatening emergencies.\n- **Earthquakes**: Drop, Cover, and Hold On. Stay clear of windows.\n- **Fires**: Crawl low under smoke. Check doors with the back of your hand before opening.`;
      }

      const fallbackMsg: ChatMessage = { 
        id: `msg-${Date.now() + 2}`, 
        role: 'assistant', 
        content: fallbackText
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, loading]);

  const handleClearChat = () => {
    setMessages([
      { 
        id: 'msg-1', 
        role: 'assistant', 
        content: "Safety systems rebooted. Expert consultant is online. Ask me about first-aid, escape steps, or disaster preparedness supplies." 
      }
    ]);
    setErrorMsg('');
  };

  // Clipboard Copier
  const copyMessage = (msgId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(msgId);
    setTimeout(() => setCopiedId(null), 1500);
  };

  // Text-To-Speech toggle
  const toggleSpeech = (msgId: string, text: string) => {
    if (!('speechSynthesis' in window)) {
      alert("Text-to-speech is not supported in this browser.");
      return;
    }

    if (isPlayingSpeech === msgId) {
      window.speechSynthesis.cancel();
      setIsPlayingSpeech(null);
    } else {
      window.speechSynthesis.cancel();
      // Remove Markdown tags for a cleaner spoken output
      const utteranceText = text
        ? text.replace(/[*#`_\-⚠️]/g, '').replace(/\[.*?\]/g, '')
        : "";
      const utterance = new SpeechSynthesisUtterance(utteranceText);
      
      utterance.onend = () => setIsPlayingSpeech(null);
      utterance.onerror = () => setIsPlayingSpeech(null);
      
      setIsPlayingSpeech(msgId);
      window.speechSynthesis.speak(utterance);
    }
  };

  // Cancel any ongoing speech on unmount
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Handle first aid manual card click
  const handleProtocolClick = (key: string) => {
    setActiveProtocolKey(activeProtocolKey === key ? null : key);
  };

  // Send quick first aid query to AI Chat
  const queryFirstAidOnAi = (title: string) => {
    sendMessage(`What is the complete first-aid and medical guidance protocol for handling: ${title}?`);
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-7xl mx-auto text-slate-800 dark:text-slate-100 transition-colors duration-300">
      
      {/* Dynamic Header Banner */}
      <div className="bg-gradient-to-r from-red-900 to-slate-900 border border-red-800/40 rounded-2xl p-6 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative overflow-hidden">
        {/* Glow backdrop decoration */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="space-y-1 z-10">
          <div className="flex items-center gap-2">
            <span className="bg-red-500 text-white text-[10px] uppercase font-extrabold tracking-widest px-2.5 py-1 rounded-full animate-pulse flex items-center gap-1">
              <ShieldAlert className="w-3 h-3" />
              Active Response Centre
            </span>
            <span className="text-xs text-slate-300 font-mono">FEMA & Red Cross Compliant</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-slate-100 tracking-tight flex items-center gap-2.5 mt-2">
            <Bot className="w-8 h-8 text-red-400" />
            AI Disaster Assistant
          </h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Ask urgent first aid instructions, escape plans, biological contamination steps, or use the interactive emergency kit & quick manuals below.
          </p>
        </div>

        <div className="flex items-center gap-3 z-10 shrink-0">
          <button 
            onClick={handleClearChat}
            className="text-slate-300 hover:text-white font-mono text-xs uppercase tracking-wider border border-slate-700 hover:border-slate-600 bg-slate-950/60 hover:bg-slate-950 px-4 py-2 rounded-lg transition-all"
          >
            Clear Console
          </button>
        </div>
      </div>

      {/* Main Responsive Grid Layout */}
      <div className="grid lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: THE INTUITIVE AI CHATROOM STAGE (lg:col-span-7) */}
        <div className="lg:col-span-7 space-y-4">
          
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden flex flex-col h-[520px] shadow-sm transition-all duration-300">
            
            {/* Header Area */}
            <div className="bg-slate-50 dark:bg-slate-950/80 px-4 py-3 border-b border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  AI Specialist Terminal
                </span>
              </div>
              <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500">
                Model: gemini-3.5-flash
              </span>
            </div>

            {/* Chat Messages Scrolling Arena */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50 dark:bg-slate-950/20">
              {messages.map((msg) => {
                const isUser = msg.role === 'user';
                return (
                  <div 
                    key={msg.id} 
                    className={`flex gap-3 max-w-[90%] ${isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
                  >
                    {/* Avatar Icon */}
                    <div className={`p-2 rounded-xl h-fit shrink-0 shadow-sm ${
                      isUser 
                        ? 'bg-red-600 text-white' 
                        : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-red-500 dark:text-red-400'
                    }`}>
                      {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                    </div>

                    {/* Chat Bubble Container */}
                    <div className="space-y-1 max-w-[85%]">
                      <div className={`p-3.5 rounded-2xl border text-xs leading-relaxed whitespace-pre-wrap transition-colors ${
                        isUser 
                          ? 'bg-red-500/10 dark:bg-red-950/20 border-red-500/20 dark:border-red-900/40 text-red-700 dark:text-red-300 font-medium' 
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 shadow-xs'
                      }`}>
                        {msg.content}
                      </div>

                      {/* Micro interaction Controls */}
                      <div className={`flex items-center gap-2 text-[10px] text-slate-400 dark:text-slate-500 ${isUser ? 'justify-end' : 'justify-start'}`}>
                        {/* Audio Read-out Speaker */}
                        <button 
                          onClick={() => toggleSpeech(msg.id, msg.content)}
                          className="flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-600 dark:hover:text-slate-300 transition-all cursor-pointer"
                          title="Read message aloud for hands-free assistance"
                        >
                          {isPlayingSpeech === msg.id ? (
                            <>
                              <VolumeX className="w-3.5 h-3.5 text-red-500 animate-pulse" />
                              <span className="font-mono text-red-500">Mute</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3.5 h-3.5" />
                              <span className="font-mono">Speak</span>
                            </>
                          )}
                        </button>

                        <span className="text-slate-300 dark:text-slate-700">|</span>

                        {/* Clipboard Copy */}
                        <button 
                          onClick={() => copyMessage(msg.id, msg.content)}
                          className="flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-600 dark:hover:text-slate-300 transition-all cursor-pointer"
                          title="Copy protocols to clipboard"
                        >
                          {copiedId === msg.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-500" />
                              <span className="font-mono text-emerald-500 font-bold">Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span className="font-mono">Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Loader response state */}
              {loading && (
                <div className="flex gap-3 max-w-[90%]">
                  <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-red-500 dark:text-red-400 h-fit shrink-0 animate-bounce">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs text-xs text-slate-500 dark:text-slate-400 font-mono flex items-center gap-2">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-red-500" />
                    <span>Searching safety compliance guidelines...</span>
                  </div>
                </div>
              )}

              {/* Error box */}
              {errorMsg && (
                <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs text-amber-600 dark:text-amber-400 max-w-md mx-auto text-center flex items-center justify-center gap-2 shadow-xs">
                  <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div ref={chatBottomRef} />
            </div>

            {/* Suggestions list & Prompt Input Form */}
            <div className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 p-4 space-y-4">
              
              {/* Hot suggestions chips */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-mono">
                  Suggested Emergency Queries
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {safetyShortcuts.map((chip, idx) => (
                    <button
                      key={idx}
                      disabled={loading}
                      onClick={() => handleShortcutClick(chip)}
                      className="px-2.5 py-1.5 bg-slate-50 hover:bg-red-500/5 dark:bg-slate-950 dark:hover:bg-red-950/20 border border-slate-200 hover:border-red-500/30 dark:border-slate-800 dark:hover:border-red-900/30 text-slate-600 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-400 rounded-lg text-[11px] font-medium transition-all cursor-pointer"
                    >
                      {chip}
                    </button>
                  ))}
                </div>
              </div>

              {/* Input box */}
              <form onSubmit={handleSubmit} className="flex gap-2">
                <input 
                  type="text"
                  required
                  disabled={loading}
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  placeholder="Ask about CPR steps, chemical hazard spills, earthquake safety..."
                  className="flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-red-500 dark:focus:border-red-500 font-medium transition-colors"
                />
                <button
                  type="submit"
                  disabled={loading || !input.trim()}
                  className={`px-5 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                    input.trim() && !loading
                      ? 'bg-red-600 hover:bg-red-700 text-white shadow-md'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-600 border border-slate-200 dark:border-slate-850'
                  }`}
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>

          </div>

          {/* Quick Informational Warning Callout */}
          <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 flex gap-3 text-xs text-amber-800 dark:text-amber-400">
            <Info className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-extrabold uppercase tracking-wide">Emergency Protocol Clarification</span>
              <p className="leading-relaxed">
                This AI tool is designed to provide reference disaster guidelines and instructional support. During an actual life-threatening medical emergency or severe hazard on campus, always **call 911 immediately** and follow instructions from campus safety marshals.
              </p>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: EMERGENCY QUICK ACCESS MANUALS & FEMA TRACKER (lg:col-span-5) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* 1. FIRST AID INTERACTIVE MANUAL */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4 transition-colors duration-300">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider font-mono flex items-center gap-2">
                <Heart className="w-5 h-5 text-red-500 animate-pulse" />
                First-Aid Quick Manual
              </h3>
              <span className="text-[10px] font-mono text-red-500 dark:text-red-400 bg-red-500/10 px-2 py-0.5 rounded-full font-bold">
                Urgent Actions
              </span>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Select any high-frequency accident or trauma scenario below to inspect preloaded step-by-step instructions.
            </p>

            <div className="space-y-2">
              {Object.entries(firstAidProtocols).map(([key, protocol]) => {
                const isActive = activeProtocolKey === key;
                return (
                  <div 
                    key={key} 
                    className={`border rounded-xl transition-all overflow-hidden ${
                      isActive 
                        ? 'border-red-500/40 bg-red-500/[0.02] dark:border-red-900/40 dark:bg-red-950/[0.05]' 
                        : 'border-slate-100 dark:border-slate-850 bg-slate-50/40 dark:bg-slate-950/20 hover:border-slate-200 dark:hover:border-slate-800'
                    }`}
                  >
                    {/* Header trigger */}
                    <button 
                      onClick={() => handleProtocolClick(key)}
                      className="w-full flex items-center justify-between p-3 text-left focus:outline-none cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-lg ${
                          protocol.severity === 'CRITICAL' 
                            ? 'bg-red-100 text-red-600 dark:bg-red-950/40 dark:text-red-400' 
                            : protocol.severity === 'HIGH'
                            ? 'bg-amber-100 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400'
                            : 'bg-blue-100 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400'
                        }`}>
                          {key === 'cpr' && <Heart className="w-4 h-4" />}
                          {key === 'bleeding' && <Droplet className="w-4 h-4" />}
                          {key === 'burns' && <Flame className="w-4 h-4" />}
                          {key === 'choking' && <Activity className="w-4 h-4" />}
                          {key === 'poison' && <ShieldAlert className="w-4 h-4" />}
                        </div>
                        <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
                          {protocol.title}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                          protocol.severity === 'CRITICAL'
                            ? 'bg-red-500/15 text-red-500'
                            : protocol.severity === 'HIGH'
                            ? 'bg-amber-500/15 text-amber-500'
                            : 'bg-blue-500/15 text-blue-500'
                        }`}>
                          {protocol.severity}
                        </span>
                        <ChevronRight className={`w-4 h-4 text-slate-400 transition-transform ${isActive ? 'rotate-90 text-red-500' : ''}`} />
                      </div>
                    </button>

                    {/* Expandable step list */}
                    {isActive && (
                      <div className="px-4 pb-4 pt-1 space-y-3.5 border-t border-slate-100 dark:border-slate-850 text-xs text-slate-600 dark:text-slate-300">
                        
                        <div className="space-y-2 mt-2">
                          {protocol.steps.map((step, idx) => (
                            <div key={idx} className="flex gap-2 items-start leading-relaxed">
                              <span className="font-mono font-bold text-red-500 dark:text-red-400 shrink-0 mt-0.5">
                                {idx + 1}.
                              </span>
                              <span>{step}</span>
                            </div>
                          ))}
                        </div>

                        {/* Pro Tip Callout */}
                        <div className="bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-850 p-2.5 rounded-lg text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                          <strong className="text-red-500 dark:text-red-400 font-mono text-[10px] uppercase block mb-0.5">Pro Tip Warning</strong>
                          {protocol.tip}
                        </div>

                        {/* Interactive Manual Action buttons */}
                        <div className="flex gap-2 pt-1">
                          <button
                            onClick={() => queryFirstAidOnAi(protocol.title)}
                            className="flex-1 bg-red-600 hover:bg-red-700 text-white text-[10px] font-bold uppercase py-2 rounded-lg text-center transition-all flex items-center justify-center gap-1.5"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            Consult AI For Details
                          </button>
                          <button
                            onClick={() => {
                              if ('speechSynthesis' in window) {
                                window.speechSynthesis.cancel();
                                const textToRead = `${protocol.title}. Steps: ` + protocol.steps.join(". ");
                                const utterance = new SpeechSynthesisUtterance(textToRead);
                                window.speechSynthesis.speak(utterance);
                              } else {
                                alert("Not supported on this browser.");
                              }
                            }}
                            className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-750 p-2 rounded-lg transition-all"
                            title="Read protocol instructions aloud"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* 2. FEMA DISASTER KIT INTERACTIVE CHECKLIST */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4 transition-colors duration-300">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider font-mono flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-amber-500" />
                FEMA Safety Kit Checklist
              </h3>
              <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase font-black">
                Personal Audit
              </span>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Prepare a physical go-bag with these essential materials. Check them off to calculate your real-life readiness score.
            </p>

            {/* Progress gauge bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono font-bold">
                <span className="text-slate-500 dark:text-slate-400">Survival Preparedness Index</span>
                <span className={`${femaProgressPercentage === 100 ? 'text-emerald-500' : 'text-amber-500'}`}>
                  {femaProgressPercentage}% Prepared
                </span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-500 ${femaProgressPercentage === 100 ? 'bg-emerald-500' : 'bg-amber-500'}`} 
                  style={{ width: `${femaProgressPercentage}%` }}
                />
              </div>
              {femaProgressPercentage === 100 && (
                <div className="text-[10px] font-mono font-bold text-emerald-500 animate-pulse bg-emerald-500/10 p-2 rounded-lg text-center mt-2">
                  🎉 Survival Go-bag Complete! You are fully prepared for local evacuations.
                </div>
              )}
            </div>

            {/* Checklist items */}
            <div className="grid grid-cols-1 gap-2 pt-2">
              {femaItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleFemaToggle(item.id)}
                  className="flex items-center gap-2.5 p-2 rounded-lg text-left text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-950 border border-slate-100/50 dark:border-slate-850/50 transition-colors w-full cursor-pointer focus:outline-none"
                >
                  <span className="shrink-0 text-slate-400 hover:text-slate-600 dark:text-slate-500">
                    {item.checked ? (
                      <CheckSquare className="w-4.5 h-4.5 text-amber-500" />
                    ) : (
                      <Square className="w-4.5 h-4.5" />
                    )}
                  </span>
                  <span className={`font-medium ${item.checked ? 'line-through text-slate-400 dark:text-slate-500' : ''}`}>
                    {item.label}
                  </span>
                </button>
              ))}
            </div>

            {/* Quick reset button */}
            <button
              onClick={() => {
                const reset = femaItems.map(item => ({ ...item, checked: false }));
                setFemaItems(reset);
                localStorage.setItem('fema_kit_progress', JSON.stringify(reset));
              }}
              className="text-[9px] font-mono font-black uppercase text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 tracking-wider text-right block w-full mt-1"
            >
              Reset Checklist
            </button>
          </div>

          {/* 3. CAMPUS HOTLINES & SOS DIRECT DIAL */}
          <div className="bg-gradient-to-br from-slate-900 to-red-950 border border-red-950 rounded-2xl p-5 shadow-lg space-y-4">
            <h3 className="text-xs font-bold font-mono tracking-widest text-red-400 uppercase flex items-center gap-1.5">
              <Phone className="w-4 h-4 text-red-500 animate-pulse" />
              Emergency SOS Hotlines
            </h3>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <a 
                href="tel:911" 
                className="bg-red-600 hover:bg-red-700 text-white font-bold p-2.5 rounded-xl text-center flex flex-col justify-center items-center gap-1 shadow-sm transition-all"
              >
                <span className="text-[10px] tracking-widest uppercase text-red-200">National Priority</span>
                <span className="text-sm">Call 911</span>
              </a>
              <a 
                href="tel:18002221222" 
                className="bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-200 font-bold p-2.5 rounded-xl text-center flex flex-col justify-center items-center gap-1 transition-all"
              >
                <span className="text-[10px] tracking-widest uppercase text-slate-400">Poison Control</span>
                <span className="text-xs font-mono">1-800-222-1222</span>
              </a>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 leading-relaxed font-mono">
              <span className="text-red-400 font-black block mb-1">💬 Urgent Campus Security:</span>
              Dial Extension **5555** from any landline in academic labs for active hazard response or building wardens.
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
