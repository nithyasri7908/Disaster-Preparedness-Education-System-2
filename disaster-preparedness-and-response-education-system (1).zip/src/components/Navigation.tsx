import React, { useState } from 'react';
import { 
  Home, BookOpen, LogIn, UserPlus, GraduationCap, Play, 
  Award, User, ClipboardList, BellRing, FolderOpen, 
  MessageSquare, ShieldAlert, FileBadge, Mail, Settings, Menu, X, LogOut,
  Sun, Moon
} from 'lucide-react';
import { UserProfile, EmergencyAlert } from '../types';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: UserProfile | null;
  onLogout: () => void;
  alerts: EmergencyAlert[];
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
}

export default function Navigation({ activeTab, setActiveTab, user, onLogout, alerts, darkMode, setDarkMode }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false);
  const activeAlertsCount = alerts.filter(a => a.isActive).length;

  const navGroups = [
    {
      title: "Core Portal",
      items: [
        { id: "home", label: "Home Portal", icon: Home },
        { id: "about", label: "About System", icon: BookOpen },
        { id: "contact", label: "Contact Hotline", icon: Mail },
      ]
    },
    {
      title: "Educational Training",
      items: [
        { id: "modules", label: "Learning Modules", icon: GraduationCap },
        { id: "simulator", label: "Disaster Simulator", icon: Play },
        { id: "quiz", label: "Safety Quizzes", icon: Award },
        { id: "chatbot", label: "AI Safety Bot", icon: MessageSquare },
      ]
    },
    {
      title: "Safety Audits & Tools",
      items: [
        { id: "alerts", label: "Emergency Alerts", icon: BellRing, badge: activeAlertsCount },
        { id: "resources", label: "Resource Center", icon: FolderOpen },
        { id: "assessment", label: "Risk Assessment", icon: ShieldAlert },
        { id: "certificate", label: "Get Certificate", icon: FileBadge },
      ]
    },
    {
      title: "Role Portals",
      items: [
        { id: "student-dash", label: "Student Dashboard", icon: User },
        { id: "teacher-dash", label: "Teacher Console", icon: ClipboardList },
        { id: "admin-dash", label: "System Admin", icon: Settings },
      ]
    }
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setIsOpen(false);
  };

  return (
    <>
      {/* Mobile Top Header */}
      <header id="mobile-header" className="lg:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 h-16 px-4 flex items-center justify-between sticky top-0 z-50 transition-colors duration-300">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-700 rounded-lg flex items-center justify-center text-white font-bold text-md shadow-sm shrink-0">
            DP
          </div>
          <div>
            <span className="font-bold text-sm tracking-tight text-blue-900 dark:text-blue-400 uppercase block">
              ResponseEd
            </span>
            <span className="text-[8px] text-slate-500 dark:text-slate-400 uppercase tracking-widest font-semibold block">
              Disaster Preparedness System
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Quick theme switcher for mobile */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Toggle dark/light mode"
          >
            {darkMode ? <Sun className="w-5 h-5 text-amber-500" /> : <Moon className="w-5 h-5 text-slate-600" />}
          </button>
          <button 
            id="menu-toggle"
            onClick={() => setIsOpen(!isOpen)} 
            className="p-2 text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 rounded hover:bg-slate-100 dark:hover:bg-slate-850 focus:outline-none"
            aria-label="Toggle navigation menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* Navigation Drawer for Mobile & Sidebar for Desktop */}
      <aside 
        id="navigation-sidebar"
        className={`fixed inset-y-0 left-0 transform ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0 lg:static transition-transform duration-300 ease-in-out z-40 w-72 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 flex flex-col h-screen overflow-y-auto shrink-0`}
      >
        {/* Brand Logo Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-700 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-sm shrink-0 animate-pulse">
              DP
            </div>
            <div>
              <h1 className="text-md font-extrabold leading-tight uppercase tracking-tight text-blue-900 dark:text-blue-400">
                ResponseEd
              </h1>
              <p className="text-[9px] text-slate-500 dark:text-slate-400 uppercase tracking-widest font-semibold">
                Disaster Prep System
              </p>
            </div>
          </div>
          {/* Theme toggle for desktop */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="hidden lg:flex p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Toggle Theme"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>
        </div>

        {/* Navigation Categories */}
        <nav className="flex-1 p-4 space-y-6">
          {/* Auth State Quick Actions if not logged in */}
          {!user && (
            <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-lg border border-slate-200 dark:border-slate-850 mb-4 space-y-2">
              <p className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-widest text-center font-bold">Authentication Required</p>
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => handleNavClick('login')}
                  className={`flex items-center justify-center gap-1.5 py-1.5 px-3 rounded text-xs font-semibold border ${
                    activeTab === 'login' 
                      ? 'bg-blue-700 text-white border-blue-700' 
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <LogIn className="w-3.5 h-3.5" /> Login
                </button>
                <button 
                  onClick={() => handleNavClick('register')}
                  className={`flex items-center justify-center gap-1.5 py-1.5 px-3 rounded text-xs font-semibold border ${
                    activeTab === 'register' 
                      ? 'bg-blue-700 text-white border-blue-700' 
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <UserPlus className="w-3.5 h-3.5" /> Sign Up
                </button>
              </div>
            </div>
          )}

          {navGroups.map((group, gIdx) => (
            <div key={gIdx} className="space-y-1.5">
              <h2 className="text-[11px] font-bold tracking-widest text-slate-400 dark:text-slate-500 uppercase pl-3">
                {group.title}
              </h2>
              <ul className="space-y-1">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  
                  // Role restricted display badges
                  let roleText = "";
                  if (item.id === "student-dash") roleText = "student";
                  if (item.id === "teacher-dash") roleText = "teacher";
                  if (item.id === "admin-dash") roleText = "admin";

                  return (
                    <li key={item.id}>
                      <button
                        onClick={() => handleNavClick(item.id)}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                          isActive
                            ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400 font-bold border-l-2 border-blue-600 pl-2.5'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-850'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400 dark:text-slate-500'}`} />
                          <span className="truncate">{item.label}</span>
                        </div>
                        
                        {/* Custom status tags & badges */}
                        {item.badge ? (
                          <span className={`px-1.5 py-0.5 rounded-full text-[9px] font-bold animate-pulse ${
                            isActive ? 'bg-blue-700 text-white' : 'bg-red-600 text-white'
                          }`}>
                            {item.badge}
                          </span>
                        ) : roleText ? (
                          <span className={`px-1.5 py-0.2 rounded text-[8px] font-mono border capitalize ${
                            isActive 
                              ? 'bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800' 
                              : user?.role === roleText 
                                ? 'bg-blue-50 dark:bg-blue-950/20 text-blue-700 dark:text-blue-400 border-blue-100 dark:border-blue-900' 
                                : 'bg-slate-50 dark:bg-slate-950 text-slate-400 dark:text-slate-500 border-slate-200 dark:border-slate-850'
                          }`}>
                            {roleText}
                          </span>
                        ) : null}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>

        {/* User Identity / Footer Module */}
        {user ? (
          <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex flex-col gap-2 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-700 flex items-center justify-center font-bold text-white shadow-sm shrink-0 uppercase">
                {user.name.split(' ').map(n => n[0]).join('')}
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">{user.name}</h4>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate capitalize">{user.role} • {user.school}</p>
              </div>
            </div>
            <button 
              onClick={onLogout}
              className="mt-2 w-full flex items-center justify-center gap-2 py-1.5 rounded bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-[11px] font-semibold text-slate-700 dark:text-slate-300 transition-all cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5 text-red-500" /> Sign Out
            </button>
          </div>
        ) : (
          <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-center">
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-semibold">Education Portal Offline</p>
            <p className="text-[9px] text-slate-400 dark:text-slate-500 mt-1">Please login to sync progress</p>
          </div>
        )}
      </aside>

      {/* Backdrop for mobile navigation drawer */}
      {isOpen && (
        <div 
          onClick={() => setIsOpen(false)} 
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-30 lg:hidden"
        />
      )}
    </>
  );
}
