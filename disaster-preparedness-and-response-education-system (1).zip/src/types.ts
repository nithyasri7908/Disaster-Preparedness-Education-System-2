export type UserRole = 'student' | 'teacher' | 'admin';

export interface UserProgress {
  completedModules: string[]; // module ids
  completedQuizzes: { [quizId: string]: number }; // score percentages
  badgesEarned: string[]; // badge ids
  riskAssessmentsCompleted: number;
}

export interface UserProfile {
  name: string;
  email: string;
  role: UserRole;
  school: string;
  gradeLevel?: string;
  studentId?: string;
  progress: UserProgress;
}

export interface LearningModule {
  id: string;
  title: string;
  icon: string;
  category: 'natural' | 'manmade' | 'health';
  description: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  timeToComplete: string; // e.g., "15 mins"
  introduction: string;
  causes: string[];
  beforeDisaster: string[];
  duringDisaster: string[];
  afterDisaster: string[];
  safetyTips: string[];
  imageUrl: string;
  sections: {
    title: string;
    content: string[];
    tips?: string[];
  }[];
  drillSteps: {
    step: number;
    action: string;
    rationale: string;
  }[];
}

export interface QuizQuestion {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number; // index of option
  explanation: string;
}

export interface Quiz {
  id: string;
  title: string;
  moduleReference: string;
  questions: QuizQuestion[];
}

export interface DisasterSimulatorStep {
  text: string;
  choices: {
    text: string;
    impactHealth: number;
    impactScore: number;
    feedback: string;
    isCorrect: boolean;
    nextStep?: number;
  }[];
}

export interface DisasterSimulator {
  id: string;
  title: string;
  description: string;
  suggestedItems: string[];
  steps: { [stepId: number]: DisasterSimulatorStep };
}

export interface EmergencyAlert {
  id: string;
  title: string;
  message: string;
  severity: 'low' | 'medium' | 'high';
  type: 'drill' | 'real_emergency' | 'advisory';
  timestamp: string;
  isActive: boolean;
  sender: string;
}

export interface RiskAssessmentItem {
  id: string;
  category: 'Structural' | 'Non-Structural' | 'Operational' | 'Environmental';
  question: string;
  hazardDescription: string;
  mitigationTip: string;
  score: number; // points deducted if unchecked
}

export interface SystemLog {
  id: string;
  timestamp: string;
  type: 'info' | 'warning' | 'alert' | 'security';
  message: string;
  user: string;
}
